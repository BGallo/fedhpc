This benchmark set consists of six classes of test instances.

In our paper, we generate different types of variable and fixed costs in order to test the performance of the designed exact algorithm in the different situations. Three and two types of parameter distributions related to variable cost and fixed cost respectively are considered. As a result, six classes of test instances are generated according to the combination of variable cost and fixed cost of using machine.

The file folder named "V1_F2" contains the test instances in which the variable and fixed costs of using each machine are generated according to the first class of parameter distributions related to variable costs and the second class of parameter distributions related to fixed costs.

Within each file folder, ten instances are generated for each combination of numbers of machines and jobs. The text document named "M2_N10_V1_F2_1" means that it is the first instance of this type of test instances, in which 2 machines and 10 jobs are considered.

The data in each text document is organized as follows (the following is an example with 2 machines and 10 jobs):

p11 p12 
p21 p22
p31 p32
p41 p42
p51 p52
p61 p62
p71 p72
p81 p82
p91 p92
p101 p102
w1 w2 w3 w4 w5 w6 w7 w8 w9 w10
U1 U2
L1 L2

where "p_jk" is the processing time of job j on machine k;
"w_j" is the weight of job j;
"U_k" is the fixed cost of using machine k;
"L_k" is the variable cost of using machine k.


