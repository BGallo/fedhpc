/**
 *
 * This file bcModelVarC.hpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef BAPCODFRAMEWORK_UTSGTEST_HPP
#define BAPCODFRAMEWORK_UTSGTEST_HPP

#include <iostream>
#include <cstdlib>

#include "bcModelingLanguageC.hpp"
#include "bcApplicationException.hpp"
#ifdef GOOGLE_TESTS
#include <gtest/gtest.h>


/*
 * This class is used to test the solvers with Google Test framework.
 */
class LpProblems : public ::testing::Test {
public:

    double _objectiveValue;
    double _primalValueX;
    double _dualValueFirstConstraint;
    double _primalValueY;
    double _dualValueSecondConstraint;
    LpProblems()=default;

    void solveFirstTestCase(const BcInitialisation & bapcodInit) {
        BcModel model(bapcodInit, "simpleLP");
        BcFormulation form(model);
        BcObjective objective(form);
        BcVarArray vars(form, "X");
        BcConstrArray constrs(form, "Cstr");
        constrs(0) >= 25;
        constrs[0] += 3 * vars(0) + 4 * vars(1);
        constrs(1) >= 40;
        constrs[1] += 4 * vars(0) + 3 * vars(1);
        objective += 1 * vars(0) + 2 * vars(1);

        BcSolution solution = form.solve();
        _objectiveValue = solution.cost();
        _primalValueX = solution.getVarVal(vars(0));
        _primalValueY = solution.getVarVal(vars(1));
        _dualValueFirstConstraint = ((BcConstr)constrs[0]).curDualVal();
        std::cout << "Objective value: " << _objectiveValue << std::endl;
        std::cout << "Primal value of X: " << _primalValueX << std::endl;
        std::cout << "Primal value of Y: " << _primalValueY << std::endl;
        std::cout << "Dual value of first constraint: " << _dualValueFirstConstraint << std::endl;
        std::cout << "Dual value of second constraint: " << _dualValueSecondConstraint << std::endl;


    }
    void SetUp() override {
    }
    void TearDown() override {
    }

};
#endif
#endif //BAPCODFRAMEWORK_UTSGTEST_HPP
