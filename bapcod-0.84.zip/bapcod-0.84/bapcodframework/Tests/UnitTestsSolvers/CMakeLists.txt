cmake_minimum_required (VERSION 3.12)
enable_testing()
if(POLICY CMP0135)
    cmake_policy(SET CMP0135 NEW)
endif()

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
    ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake
    ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake/Packages
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake ${CMAKE_CURRENT_SOURCE_DIR}/CMake/Packages)

include(BapcodApplicationProject)
include(Documentation)

include(FetchContent)
find_package(BcpRcsp)
include_directories(${LIBRCSP_INCLUDE_DIR})


set_project_version(1 0 0)
set(CMAKE_CXX_STANDARD 17)

# Build Application
try_build_bapcod_application()
