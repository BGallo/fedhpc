/**
 *
 * This file Main.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/


#ifdef GOOGLE_TESTS
#include "utsGtest.hpp"

int main(int argc, char * argv[]){
    testing::InitGoogleTest(&argc,argv);
    return RUN_ALL_TESTS();
}
#else
int main(int argc, char * argv[]){
    return 0;
}
#endif