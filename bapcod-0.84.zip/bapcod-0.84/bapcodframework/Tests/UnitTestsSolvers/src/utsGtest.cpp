/**
 *
 * This file Main.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/
#ifdef GOOGLE_TESTS
#include "utsGtest.hpp"


// Tests some simple models
TEST_F(LpProblems,gurobiSolverLpTest1){

    BcInitialisation bapcodInit;
    bapcodInit.param().masterSolMode(SolutionMethod::lpSolver);
    bapcodInit.param().solverName("GUROBI_SOLVER");

    solveFirstTestCase(bapcodInit);

    EXPECT_TRUE((_objectiveValue - 26.6667)< 0.0001);


}

TEST_F(LpProblems,gurobiSolverMipTest1){

    BcInitialisation bapcodInit;
    bapcodInit.param().masterSolMode(SolutionMethod::mipSolver);
    bapcodInit.param().solverName("GUROBI_SOLVER");

    solveFirstTestCase(bapcodInit);

    EXPECT_TRUE(_objectiveValue == 28);

}

TEST_F(LpProblems,cplexSolverMipTest1){

    BcInitialisation bapcodInit;
    bapcodInit.param().masterSolMode(SolutionMethod::mipSolver);
    bapcodInit.param().solverName("CPLEX_SOLVER");

    solveFirstTestCase(bapcodInit);

    EXPECT_TRUE(_objectiveValue == 28);

}

TEST_F(LpProblems,cplexSolverLpTest1){

    BcInitialisation bapcodInit;
    bapcodInit.param().masterSolMode(SolutionMethod::lpSolver);
    bapcodInit.param().solverName("CPLEX_SOLVER");

    solveFirstTestCase(bapcodInit);

    std::cout << "Objective value: " << _objectiveValue << std::endl;
    EXPECT_TRUE((_objectiveValue - 26.6667)< 0.0001);
}

#endif


