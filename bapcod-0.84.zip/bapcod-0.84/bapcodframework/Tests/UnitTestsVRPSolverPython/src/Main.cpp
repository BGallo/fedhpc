/**
 *
 * This file Main.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/


#if(JSON_IS_FOUND )
#include "bcModelVRPSolver.hpp"
#include "istreamwrapper.h"
#include "filewritestream.h"
#include <writer.h>
#include <cstdio>


using namespace rapidjson;
using namespace API_VRP;
using namespace std;


std::vector<std::string> ALL_TESTS{ "data/easy/instance_circle.json",
                                     "data/easy/instance_crash.json",
                                     "data/easy/instance_crash2.json",
                                     "data/easy/instance_noFeasible_error.json",
                                     "data/easy/instance_test.json",
                                     "data/easy/instance_test2.json",
                                     "data/very_easy/CVRP.json",
                                     "data/easy/instance_noFeasible.json",
                                     "data/very_easy/CVRPTW.json",
                                     "data/very_easy/CVRPTW_noFeasible.json",
                                     "data/very_easy/VRP.json",
                                     "data/solomon/C101.json",
                                     "data/solomon/R101.json",
                                     "data/solomon/RC101.json",
                                     "data/solomon/RC201.json",
                                     "data/solomon/R201.json",
                                     "data/solomon/C201.json",
                                     "data/augerat/A-n32-k5.json",
                                     "data/augerat/B-n31-k5.json",
                                     "data/augerat/E-n51-k5.json",
                                     "data/augerat/P-n40-k5.json",
                                     "data/augerat/P-n55-k10.json",
                                     "data/hfvrp/c50_13fsmd.json",
                                     "data/hfvrp/c50_13fsmf.json",
                                     "data/hfvrp/c50_13fsmfd.json",
                                     "data/hfvrp/c50_13hd.json",
                                     "data/not_complete_graph.json"
};



std::string launch_one_test_from_file(const char* fileName)
{
    std::ifstream ifs(fileName, std::ios::in);
    rapidjson::Document document;
    if (!ifs.is_open())
    {
        std::cerr << "Could not open file for reading!\n";
        return {};
    }

    rapidjson::IStreamWrapper isw{ ifs };
    document.ParseStream(isw);
    auto solutionStr = API_VRP::runModel(document);
    //debug mode
    //std::cout << solutionStr;
    return solutionStr;

}

void launch_one_test_from_string(const char* str)
{
    rapidjson::Document document;
    document.Parse(str);
    std::cout << API_VRP::runModel(document);
}

size_t launch_all_tests()
{
    bool successTests = true;
    std::string errorMsg;
    auto nbTest = ALL_TESTS.size();
    auto nbTestDone = 0;
    size_t nbTestsFailed = 0;
    size_t nbTestsSuccessful = 0;
    vector<std::string> instances_failed{};
    for (const auto& nameFile : ALL_TESTS)
    {
        auto output = launch_one_test_from_file(nameFile.c_str());
        nbTestDone++;
        std::string delimiter = ".";
        //get the last string from namefile "Data/very_easy/.."
        std::string name_result = nameFile.substr(0, nameFile.find(delimiter)) + std::string("_result.json");
        std::ifstream ifs_result{ name_result, std::ios::in };

        rapidjson::Document documentResults;
        if (!ifs_result.is_open()) ///If the file doesn't exist we create one
        {
            documentResults.Parse(output.c_str());
            FILE* fp = fopen(name_result.c_str(), "wb"); // non-Windows use "w"

            char writeBuffer[65536];
            FileWriteStream os(fp, writeBuffer, sizeof(writeBuffer));

            Writer<FileWriteStream> writer(os);
            documentResults.Accept(writer);
            fclose(fp);
            //std::cout << output;
        }
        else //If the file exists we compare the status, message and objectif function
        {
            std::cout << "BEGIN TESTS IN :" << name_result << endl;

            rapidjson::IStreamWrapper isw{ ifs_result };
            documentResults.ParseStream(isw); /// We parse the results document

            rapidjson::Document documentModelTest;
            documentModelTest.Parse(output.c_str()); /// We parse the output model test

            int codeExpected = documentResults["Status"].GetObj()["code"].GetInt();
            int codeModelTest = documentModelTest["Status"].GetObj()["code"].GetInt();
            if (codeModelTest != codeExpected) /// We compare the status code
            {
                nbTestsFailed++;
                instances_failed.push_back(name_result);
                break;
            }



            if (codeExpected > -1 && codeExpected < 4 && codeModelTest > -1 && codeModelTest < 4) /// Check solution value if there is a solution
            {
                double solutionValueExpected = documentResults["Solution"].GetObj()["bestSolutionValue"].GetDouble();
                double solutionValueModelTest = documentModelTest["Solution"].GetObj()["bestSolutionValue"].GetDouble();
                std::cout << solutionValueExpected << " " << solutionValueModelTest << endl;
                if (abs(solutionValueModelTest - solutionValueExpected) > 1e-2)
                {
                    nbTestsFailed++;
                    instances_failed.push_back(name_result);
                    break;

                }
            }

            std::string messageExpected = documentResults["Status"].GetObj()["message"].GetString();
            std::string messageModelTest = documentModelTest["Status"].GetObj()["message"].GetString();
            if (messageModelTest != messageExpected)
            {
                cout << messageModelTest << endl;
                cout << messageExpected << endl;
                nbTestsFailed++;
                instances_failed.push_back(name_result);
                break;

            }

            std::cout << name_result << " -- SUCCESS" << endl;
            nbTestsSuccessful++;
            //  cout << output.c_str();
        }
    }

    std::cout << std::endl;
    std::cout << "Run : " << nbTestDone << " tests" << endl;
    std::cout << "FAILED : " << nbTestsFailed << " << SUCCESS : " << nbTestsSuccessful <<
        " << NEW TESTS : " << nbTestDone - nbTestsFailed - nbTestsSuccessful << endl;
    if (instances_failed.size() > 0)
    {
        std::cout << "INSTANCES FAILED : ";
        for (auto name_instance : instances_failed)
        {
            cout << name_instance << " ";
        }
    }

    return nbTestsFailed;
}

int main(int argc, char** argv)
{
    //auto output = launch_one_test_from_file("data/ovrp.json");
    //std::cout << output << std::endl;
    //return 0;
    return launch_all_tests();
};
#else
#include <iostream>

int main() {
    std::cout << "JSON library not found. Unit tests cannot be run." << std::endl;
    return 0;
}
#endif