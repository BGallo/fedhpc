cmake_minimum_required (VERSION 3.12)
project(UnitTestsVRPSolverPython CXX)

# Support both source build and standalone build modes
if(DEFINED ENV{BAPCOD_ROOT} OR DEFINED BAPCOD_ROOT)
    # Standalone mode: Use installed BaPCod
    # Prefer CMake variable over environment variable
    if(DEFINED BAPCOD_ROOT)
        set(BAPCOD_ROOT_PATH ${BAPCOD_ROOT})
    else()
        set(BAPCOD_ROOT_PATH $ENV{BAPCOD_ROOT})
    endif()
    
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake/Packages)
else()
    # Source mode: Use relative paths to BaPCod source
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake/Packages)
endif()

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake 
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake/Packages)

include(BapcodApplicationProject)
include(Documentation)


find_package(BcpRcsp)
if(BcpRcsp_FOUND)
    set(USER_LIBRARIES ${BCP_RCSP_LIBRARY})
    set(USER_INCLUDE_DIR ${BCP_RCSP_INCLUDE_DIR})
else()
    message(WARNING "UnitTestsVRPSolverPython requires RCSP library but it was not found. This demo cannot be built without RCSP. Please install RCSP in Tools/rcsp/ directory.")
endif()

set_project_version(1 0 0)
set(CMAKE_CXX_STANDARD 17)

# Build Application
try_build_bapcod_application()

file(MAKE_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/bin)
execute_process(COMMAND ${CMAKE_COMMAND} -E create_symlink ${CMAKE_CURRENT_SOURCE_DIR}/data/ ${CMAKE_CURRENT_BINARY_DIR}/bin/data)

