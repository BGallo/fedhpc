cmake_minimum_required (VERSION 3.12)
project(CuttingStockDemo CXX)

# Support both source build and standalone build modes
# Source mode: Building from within BaPCod repository
# Standalone mode: Building with BAPCOD_ROOT pointing to installed BaPCod
if(DEFINED ENV{BAPCOD_ROOT} OR DEFINED BAPCOD_ROOT)
    # Standalone mode: Use installed BaPCod
    # Prefer CMake variable over environment variable
    if(DEFINED BAPCOD_ROOT)
        set(BAPCOD_ROOT_PATH ${BAPCOD_ROOT})
    else()
        set(BAPCOD_ROOT_PATH $ENV{BAPCOD_ROOT})
    endif()
    
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake/Packages)
else()
    # Source mode: Use relative paths to BaPCod source
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake/Packages)
endif()

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake 
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake/Packages)

include(BapcodApplicationProject)
include(Documentation)

# Optional: Set other libraries
# set(USER_LIBRARIES other_libraries)
# set(USER_INCLUDE_DIR other_include_libraries_dir)

set_project_version(1 0 0)

# Build Application
try_build_bapcod_application()

