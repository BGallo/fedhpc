/**
 *
 * This file model.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_MODEL_H_
#define _SDVRP_DEMO_MODEL_H_

#include "RCSPSolver.h"
#include "CutSeparation.h"

#include <bcModelPointerC.hpp>
#include "bcModelAdvancedCuts.hpp"

namespace sdvrp
{
    class Model : public BcModel, InputUser
    {
    public:
        /// Constructor(s) and Destructor(s).
        Model(const BcInitialisation & bcInitialisation);
        virtual ~Model() = default;

        ///Methods.
        void buildMultiDeliveryModel(const SdvrpData & data, const SdvrpParameters & parameters);
    };
}

#endif /// _SDVRP_DEMO_MODEL_H_
