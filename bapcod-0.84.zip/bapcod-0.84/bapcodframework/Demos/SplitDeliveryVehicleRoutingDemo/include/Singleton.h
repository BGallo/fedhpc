/**
 *
 * This file Singleton.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_SINGLETON_H_
#define _SDVRP_DEMO_SINGLETON_H_

#include <stdlib.h>

namespace sdvrp
{
    template<typename T>
    class Singleton
    {
    public:
        virtual ~Singleton() = default;

        static T & getInstance()
        {
            if (singleton == NULL)
            {
                singleton = new T();
            }
            return *singleton;
        }

        static inline const T & getBuilt() {return *singleton;}
        inline void destroy() {delete singleton;}

    protected:
        Singleton() {}
        static T *singleton;
    };

    template<typename T>
    T * Singleton<T>::singleton = NULL;
}

#endif /// _SDVRP_DEMO_SINGLETON_H_
