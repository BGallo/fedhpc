/**
 *
 * This file Loader.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_LOADER_H_
#define _SDVRP_DEMO_LOADER_H_

#include "Data.h"
#include "Parameters.h"

#include <locale>
#include <cstring>

namespace sdvrp
{
    class SdvrpData;
    class SdvrpParameters;

    class Loader
    {
    /// By default, class members are private, but we add for clarity.
    private:
        /// Members.
        SdvrpData & data;
        SdvrpParameters & parameters;

        ///Methods.
        bool loadSDVRPTWFile(const std::string & inputFileName);
        bool loadSDVRPFile(const std::string & inputFileName);

    public:
        /// Constructor(s) and Destructor(s).
        Loader();
        virtual ~Loader() = default;

        /// Methods.
        bool loadData(const std::string & fileName);
        bool loadParameters(const std::string & fileName, int argc, char * argv[]);
    };
}

#endif /// _SDVRP_DEMO_LOADER_H_
