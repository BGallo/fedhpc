/**
 *
 * This file SolutionChecker.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_SOLUTIONCHECKER_H_
#define _SDVRP_DEMO_SOLUTIONCHECKER_H_

#include "InputUser.h"
#include "Model.h"

#include <bcModelPointerC.hpp>
#include <bcModelRCSPSolver.hpp>
#include <bcNetworkFlowC.hpp>
#include <bcModelNetworkFlow.hpp>

namespace sdvrp
{
    class ColumnsInSolution
    {
    /// Only contains public members and could have been declared as a struct. We keep it as a class for homogeneity.
    public:
        /// Members.
        int _index;
        int _capacity;
        int _multiplicity;
        double _cost;
        std::vector<int> _setIds;
        std::vector<int> _vertexIds;
        std::vector<int> _arcIds;
        std::vector<int> _resConsumption;
        std::vector<int> _deliveries;

        /// Constructor(s) and destructor(s).
        ColumnsInSolution(const int & index, const int & capacity, const int & multiplicity,
                          const double & cost) : _index(index), _capacity(capacity), _multiplicity(multiplicity),
                          _cost(cost), _setIds(), _vertexIds(), _arcIds(), _resConsumption(), _deliveries()
        {}
        ~ColumnsInSolution() = default;
    };

    class SolutionChecker : public BcSolutionFoundCallback, public InputUser
    {
    public:
        /// Methods.
        bool printAndBuildSolutionAndCheckIfFeasibleGeneric(std::vector<ColumnsInSolution> & solutionColumns) const;
        bool printSolutionAndCheckIfFeasibleMultiDelivery(BcSolution & solution, const bool & bestSolution) const;
        bool operator()(BcSolution newSolution) const override;
    };
}

#endif /// _SDVRP_DEMO_SOLUTIONCHECKER_H_
