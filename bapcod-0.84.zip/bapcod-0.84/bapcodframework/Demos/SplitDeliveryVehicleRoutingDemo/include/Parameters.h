/**
 *
 * This file parameters.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_PARAMETERS_H_
#define _SDVRP_DEMO_PARAMETERS_H_

#include "Singleton.h"
#include "bcParameterParserC.hpp"

#define DISTANCES_ROUND_MODE_NO 0
#define DISTANCES_ROUND_MODE_ONE_DECIMAL 1
#define DISTANCES_ROUND_MODE_DOWN 2
#define DISTANCES_ROUND_MODE_NEAREST_INTEGER 3

namespace sdvrp
{
    class SdvrpParameters : public Singleton<SdvrpParameters>, ParameterParser
    {
        friend class Singleton<SdvrpParameters>;
    private:
        /// Members.
        ApplicationParameter<int> _nbDiffDeliveryQuantitiesPerCustomer;
        ApplicationParameter<int> _capacity;
        ApplicationParameter<bool> _unlimitedFleet;
        ApplicationParameter<int> _roundMode;
        ApplicationParameter<double> _cutOffValue;

    public:
        /// Constructor(s) and destructor(s).
        SdvrpParameters();
        virtual ~SdvrpParameters() = default;

        /// Methods.
        bool loadParameters(const std::string & parameterFileName, int argc, char* argv[],
                            std::ostream & os = std::cout);
        std::ostream & print(std::ostream & os = std::cout) const;

        /// Getters.
        inline int nbDiffDeliveryQuantitiesPerCustomer() const {return _nbDiffDeliveryQuantitiesPerCustomer();}
        inline int capacity() const {return _capacity();}
        inline bool unlimitedFleet() const {return _unlimitedFleet();}
        inline int roundMode() const {return _roundMode();}
        inline double cutOffValue() const {return _cutOffValue();}
    };

    inline std::ostream & operator<<(std::ostream & os, const SdvrpParameters & that)
    {
        return that.print(os);
    }
}

#endif /// _SDVRP_DEMO_PARAMETERS_H_
