/**
 *
 * This file inputUser.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_INPUTUSER_H_
#define _SDVRP_DEMO_INPUTUSER_H_

#include "Data.h"

namespace sdvrp
{
    class InputUser
    {
    protected:
        InputUser() : data(SdvrpData::getInstance()), parameters(SdvrpParameters::getInstance()) {}

        const SdvrpData & data;
        const SdvrpParameters & parameters;
    };
}


#endif /// _SDVRP_DEMO_INPUTUSER_H_
