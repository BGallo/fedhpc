/**
 *
 * This file CutSeparation.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_CUT_SEPARATION_H_
#define _SDVRP_DEMO_CUT_SEPARATION_H_

#include <bcModelCutConstrC.hpp>

namespace sdvrp
{
    class EdgeCutSeparationRoutine: public BcCutSeparationFunctor
    {
    private:
        /// Members.
        int _cutCount;
        std::string _varName;


    public:
        /// Constructor(s) and destructor(s).
        EdgeCutSeparationRoutine(const std::string & varName);
        virtual ~EdgeCutSeparationRoutine() = default;
        virtual int operator() (BcFormulation formPtr,
                                BcSolution & primalSol,
                                double & maxViolation,
                                std::list< BcConstr > & cutList);
    };
}

#endif /// _SDVRP_DEMO_CUT_SEPARATION_H_