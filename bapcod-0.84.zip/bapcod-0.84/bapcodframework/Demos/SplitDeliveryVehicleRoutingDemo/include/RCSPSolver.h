/**
 *
 * This file RCSPSolver.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_RCSPSOLVER_H_
#define _SDVRP_DEMO_RCSPSOLVER_H_

#include "InputUser.h"

#include <bcModelRCSPSolver.hpp>

namespace sdvrp
{
    class RCSPSolver : public InputUser
    {
    public:
        /// Constructor(s) and destructor(s).
        RCSPSolver(BcFormulation & spForm);
        virtual ~RCSPSolver() = default;

        /// Getter(s).
        BcRCSPFunctor * getOracle() {return oracle;}

    private:
        /// Members.
        BcFormulation subproblemFormulation;
        std::vector<BcVertex> vertices;
        BcRCSPFunctor * oracle;

        /// Methods.
        void buildSDVRPTWVertices(BcNetwork & network, BcNetworkResource & distanceResource,
                                  BcNetworkResource & capacityResource);
        void buildSDVRPTWArcs(BcNetwork & network, BcNetworkResource & distanceResource,
                              BcNetworkResource & capacityResource);
        void buildSDVRPVertices(BcNetwork & network, BcNetworkResource & capacityResource);
        void buildSDVRPArcs(BcNetwork & network, BcNetworkResource & capacityResource);

        /// Getter(s).
        int getArcCapacityResourceConsumption(const int & customerId, const int & arcDeliveryId);
    };
}

#endif /// _SDVRP_DEMO_RCSPSOLVER_H_
