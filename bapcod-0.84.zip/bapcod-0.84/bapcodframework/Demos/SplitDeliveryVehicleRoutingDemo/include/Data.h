/**
 *
 * This file Data.h is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#ifndef _SDVRP_DEMO_DATA_H_
#define _SDVRP_DEMO_DATA_H_

#include "Parameters.h"
#include "bcModelingLanguageC.hpp"

#include <random>
#include <iterator>
#include <set>
#include <limits>
#include <cmath>

namespace sdvrp
{
    class Vertex
    {
    /// By default, class members are private, but we add for clarity.
    private:
        /// Members.
        int _vertexId;
        double _coordX;
        double _coordY;
        std::vector<double> _explicitDistToSite;

    public:
        /// Constructor(s) and destructor(s).
        Vertex(const int & id, const double & coordX, const double & coordY);
        Vertex(const int & id, const std::vector<double> & distances);
        virtual ~Vertex() = default;

        /// Methods.
        double computeDistanceFrom(Vertex * vertex, const int & roundMode) const;
        virtual std::ostream & print(std::ostream & os) const;

        /// Getters.
        inline int getId() const {return _vertexId;};
        inline double getCoordX() const {return _coordX;}
        inline double getCoordY() const {return _coordY;}
        inline double getExplicitDistToSite(const int & siteId) const {return _explicitDistToSite[siteId];}
    };

    class Site : public Vertex
    {
    /// By default, class members are private, but we add for clarity.
    private:
        /// Members.
        int _demand;
        int _serviceTime;
        int _timeWindowBegin;
        int _timeWindowEnd;

    public:
        /// Constructor(s) and destructor(s).
        Site(const int & id, const double & coordX, const double & coordY,
             const int & demand = -1, const int & serviceTime = -1,
             const int & timeWindowBegin = -1, const int & timeWindowEnd = -1);
        Site(const int & id, const std::vector<double> & distances,
             const int & demand = -1, const int & serviceTime = -1,
             const int & timeWindowBegin = -1, const int & timeWindowEnd = -1);
        ~Site() override = default;

        /// Methods.
        std::ostream & print(std::ostream & os) const override;

        /// Getters.
        inline int getDemand() const {return _demand;}
        inline int getServiceTime() const {return _serviceTime;}
        inline int getTimeWindowBegin() const {return _timeWindowBegin;}
        inline int getTimeWindowEnd() const {return _timeWindowEnd;}

        /// Setters.
        inline void setDemand(const int & demand) {_demand = demand;}
        inline void setServiceTime(const int & serviceTime) {_serviceTime = serviceTime;}
    };

    class DepotVehTypePair : public Vertex
    {
    /// By default, class members are private, but we add for clarity.
    private:
        int _capacity;
        int _minNumVehicles;
        int _maxNumVehicles;
        double _fixedCost;
        double _costFactor;
        double _maxDistance;
        bool _canVisitAllSites;
        std::vector<bool> _canVisitSite;

    public:
        /// Constructor(s) and destructor(s).
        DepotVehTypePair(const int & id, const double & coordX, const double & coordY,
                         const int & minNumVehicles, const int & maxNumVehicles,
                         const int & capacity = -1, const double & maxDistance = -1,
                         const double & fixedCost = 0.0, const double & costFactor = 1.0);
        DepotVehTypePair(const int & id, const std::vector<double> & distances,
                         const int & minNumVehicles, const int & maxNumVehicles,
                         const int & capacity = -1, const double & maxDistance = -1,
                         const double & fixedCost = 0.0, const double & costFactor = 1.0);
        ~DepotVehTypePair() override = default;

        /// Methods.
        inline void decreaseMaxNumVehicles() {_maxNumVehicles -= 1;}
        std::ostream & print(std::ostream & os) const override;

        /// Getters.
        inline int getCapacity() const {return _capacity;}
        inline double getFixedCost() const {return _fixedCost;}
        inline double getCostFactor() const {return _costFactor;}
        inline double getMaxDistance() const {return _maxDistance;}
        inline double getTimeWindowEnd() const {return _maxDistance;}
        inline int getMaxNumVehicles() const {return _maxNumVehicles;}
        inline int getMinNumVehicles() const {return _minNumVehicles;}
        inline bool canVisitSite(const int & siteId) const {return (_canVisitAllSites ||
                                                                    _canVisitSite[siteId]);}

        /// Setters.
        inline void setMinNumVehicles(const int & value)
        {
            if (_minNumVehicles < value)
                _minNumVehicles = value;
        }
        inline void setCapacity(const int & value) {_capacity = value;}
        inline void setVisitedSites(const std::vector<bool> & canVisitSite)
        {
            _canVisitAllSites = false;
            _canVisitSite = canVisitSite;
        }
    };

    class SdvrpData : public Singleton<SdvrpData>
    {
        friend class Singleton<SdvrpData>;
    public:
        /// Members.
        std::string _fileName;
        int _roundMode;
        int _vehicleCapacity;
        bool _unlimitedFleet;
        bool _distanceIsExplicit;
        bool _instanceHasTimeWindows;
        int _kMax;
        int _nbDiffDelQuantities;
        int _greatestCommonDivisor;
        bool _setOneInstance;
        int _avgRoutesLength;
        double _maxDemand;
        double _timeWindowRatio;
        std::vector<DepotVehTypePair *> _depotVehTypePairPts;
        std::vector<Site *> _customerPts;
        std::vector<std::vector<double>> _shortestPathMatrix;

        /// Constructor(s) and destructor(s).
        SdvrpData();
        ~SdvrpData() {this->clearMemory();}

        /// Methods.
        void clearMemory();
        void calculateGreatestCommonDivisors();
        void calculateShortestPathMatrix();
        double computeInitialUpperBound();
        int getTotalDemand() const;

        static int gcd(const int & a, const int & b)
        {
            if (a == 0)
                return b;
            return gcd(b % a, a);
        }

        /// Getters.
        inline int getNbCustomers() const {return static_cast<int>(_customerPts.size());}
        inline int getServiceTime(const int & customerId) const {return _customerPts[customerId]->getServiceTime();}
        inline int getTimeWindowBegin(const int & customerId) const {return _customerPts[customerId]->getTimeWindowBegin();}
        inline int getTimeWindowEnd(const int & customerId) const {return _customerPts[customerId]->getTimeWindowEnd();}
        inline int getDemand(const int & customerId) const {return _customerPts[customerId]->getDemand();}
        inline int getGreatestCommonDivisor() const {return _greatestCommonDivisor;}

        inline bool vehCanVisitCustomer(const int & depotVehTypePairId, const int & customerId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->canVisitSite(customerId);
        }

        inline int getCapacity(const int & depotVehTypePairId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getCapacity();
        }

        inline double getMaxDistance(const int & depotVehTypePairId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getMaxDistance();
        }

        inline int getMaxNumVehicles(const int & depotVehTypePairId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getMaxNumVehicles();
        }

        inline int getMinNumVehicles(const int & depotVehTypePairId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getMinNumVehicles();
        }

        inline double getDepotToCustomerDistance(const int & depotVehTypePairId, const int & customerId) const
        {
            if (_distanceIsExplicit)
                return _depotVehTypePairPts[depotVehTypePairId]->getExplicitDistToSite(customerId);
            if (_setOneInstance)
            {
                double dist = _depotVehTypePairPts[depotVehTypePairId]->computeDistanceFrom(_customerPts[customerId],
                                                                                            0)/100;
                if (_roundMode == DISTANCES_ROUND_MODE_NO)
                    return dist;
                if (_roundMode == DISTANCES_ROUND_MODE_DOWN)
                    return floor(dist);
                else if (_roundMode == DISTANCES_ROUND_MODE_NEAREST_INTEGER)
                    return round(dist);
                return floor(dist * 10) / 10.0;
            }
            return _depotVehTypePairPts[depotVehTypePairId]->computeDistanceFrom(_customerPts[customerId],
                                                                                 _roundMode);
        }

        inline double getCustomerToCustomerDistance(const int & customerId1, const int & customerId2) const
        {
            if (_distanceIsExplicit)
                return _customerPts[customerId1]->getExplicitDistToSite(customerId2);
            if (_setOneInstance)
            {
                double dist = _customerPts[customerId1]->computeDistanceFrom(_customerPts[customerId2],
                                                                             0)/100;
                if (_roundMode == DISTANCES_ROUND_MODE_NO)
                    return dist;
                if (_roundMode == DISTANCES_ROUND_MODE_DOWN)
                    return floor(dist);
                else if (_roundMode == DISTANCES_ROUND_MODE_NEAREST_INTEGER)
                    return round(dist);
                return floor(dist * 10) / 10.0;
            }
            return _customerPts[customerId1]->computeDistanceFrom(_customerPts[customerId2],
                                                                  _roundMode);
        }

        inline double getDepotToCustomerPreprocessedDistance(const int & customerId) const
        {
            return _shortestPathMatrix[_shortestPathMatrix.size()-1][customerId];
        }

        inline double getCustomerToCustomerPreprocessedDistance(const int & customerId1, const int & customerId2) const
        {
            return _shortestPathMatrix[customerId1][customerId2];
        }

        inline double getDepotToCustomerCost(const int & depotVehTypePairId, const int & customerId) const
        {
            if (_distanceIsExplicit)
                return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()
                       *_depotVehTypePairPts[depotVehTypePairId]->getExplicitDistToSite(customerId);
            return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()
                   * _depotVehTypePairPts[depotVehTypePairId]->computeDistanceFrom(_customerPts[customerId],
                                                                                   _roundMode);
        }

        inline double getCustomerToCustomerCost(const int & depotVehTypePairId, const int & customerId1,
                                                const int & customerId2) const
        {
            if (_distanceIsExplicit)
            {
                return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()
                * _customerPts[customerId1]->getExplicitDistToSite(customerId2);
            }
            return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()
            * _customerPts[customerId1]->computeDistanceFrom(_customerPts[customerId2], _roundMode);
        }

        inline double getDepotToCustomerPreprocessedCost(const int & depotVehTypePairId, const int & customerId) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()
                   * _shortestPathMatrix[_shortestPathMatrix.size()-1][customerId];
        }

        inline double getCustomerToCustomerPreprocessedCost(const int & depotVehTypePairId, const int & customerId1,
                                                            const int & customerId2) const
        {
            return _depotVehTypePairPts[depotVehTypePairId]->getCostFactor()*_shortestPathMatrix[customerId1][customerId2];
        }

        /// Setters.
        inline void setCapacity(const int & depotVehTypePairId, const int & value)
        {
            _depotVehTypePairPts[depotVehTypePairId]->setCapacity(value);
        }
        void setParameters(const SdvrpParameters & applicationSpecificParameters);
    };
}

#endif /// _SDVRP_DEMO_DATA_H_
