/**
 *
 * This file Data.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/Data.h"


sdvrp::Vertex::Vertex(const int & id, const double & coordX, const double & coordY) : _vertexId(id), _coordX(coordX),
_coordY(coordY), _explicitDistToSite()
{}

sdvrp::Vertex::Vertex(const int & id, const std::vector<double> & distances) : _vertexId(id), _coordX(0.0),
_coordY(0.0), _explicitDistToSite(std::move(distances))
{}

double sdvrp::Vertex::computeDistanceFrom(sdvrp::Vertex * vertex, const int & roundMode) const
{
    double dist = sqrt(pow(_coordX - vertex->_coordX, 2)+pow(_coordY - vertex->_coordY, 2));
    if (roundMode == DISTANCES_ROUND_MODE_NO)
        return dist;
    if (roundMode == DISTANCES_ROUND_MODE_DOWN)
        return floor(dist);
    else if (roundMode == DISTANCES_ROUND_MODE_NEAREST_INTEGER)
        return round(dist);
    return floor(dist * 10) / 10.0;
}

std::ostream & sdvrp::Vertex::print(std::ostream & os) const
{
    os << "Vertex " << _vertexId << "( " << _coordX << " , " << _coordY << " )" << std::endl;
    return os;
}

sdvrp::Site::Site(const int & id, const double & coordX, const double & coordY, const int & demand,
                  const int & serviceTime, const int & timeWindowBegin, const int & timeWindowEnd) :
                  sdvrp::Vertex(id, coordX, coordY), _demand(demand), _serviceTime(serviceTime),
                  _timeWindowBegin(timeWindowBegin), _timeWindowEnd(timeWindowEnd)
{}

sdvrp::Site::Site(const int & id, const std::vector<double> & distances, const int & demand,
                  const int & serviceTime, const int & timeWindowBegin, const int & timeWindowEnd) :
        sdvrp::Vertex(id, distances), _demand(demand), _serviceTime(serviceTime),
        _timeWindowBegin(timeWindowBegin), _timeWindowEnd(timeWindowEnd)
{}

std::ostream & sdvrp::Site::print(std::ostream & os) const
{
    os << "Site" << std::endl;
    sdvrp::Vertex::print(os);
    os << "Customer with demand: " << _demand << std::endl;
    return os;
}

sdvrp::DepotVehTypePair::DepotVehTypePair(const int & id, const double & coordX, const double & coordY,
                                          const int & minNumVehicles, const int & maxNumVehicles, const int & capacity,
                                          const double & maxDistance, const double & fixedCost,
                                          const double & costFactor) :
                                          sdvrp::Vertex(id, coordX, coordY), _minNumVehicles(minNumVehicles),
                                          _maxNumVehicles(maxNumVehicles), _capacity(capacity),
                                          _maxDistance(maxDistance), _fixedCost(fixedCost), _costFactor(costFactor),
                                          _canVisitAllSites(true), _canVisitSite()
{}

sdvrp::DepotVehTypePair::DepotVehTypePair(const int & id, const std::vector<double> & distances,
                                          const int & minNumVehicles, const int & maxNumVehicles, const int & capacity,
                                          const double & maxDistance, const double & fixedCost,
                                          const double & costFactor) :
        sdvrp::Vertex(id, distances), _minNumVehicles(minNumVehicles),
        _maxNumVehicles(maxNumVehicles), _capacity(capacity),
        _maxDistance(maxDistance), _fixedCost(fixedCost), _costFactor(costFactor),
        _canVisitAllSites(true), _canVisitSite()
{}

std::ostream & sdvrp::DepotVehTypePair::print(std::ostream & os) const
{
    sdvrp::Vertex::print(os);
    os << "Is a depot with at most " << _maxNumVehicles << " vehicles";
    if (_minNumVehicles >= 0)
        os << "With lower bound on the num. of vehicles " << _minNumVehicles << std::endl;
    if (_capacity >= 0)
        os << "With capacity " << _capacity << std::endl;
    if (_maxDistance >= 0)
        os << "With maximum distance " << _maxDistance << std::endl;
    if (_costFactor != 1.0)
        os << "With cost factor " << _costFactor << std::endl;
    if (_fixedCost != 0.0)
        os << "With fixedCost " << _fixedCost << std::endl;
    return os;
}

template<typename Iter, typename RandomGenerator>
Iter select_randomly(Iter start, Iter end, RandomGenerator& g)
{
    std::uniform_int_distribution<> dis(0, std::distance(start, end) - 1);
    std::advance(start, dis(g));
    return start;
}

template<typename Iter>
Iter select_randomly(Iter start, Iter end)
{
    static std::random_device rd;
    static std::mt19937 gen(rd());
    return select_randomly(start, end, gen);
}

sdvrp::SdvrpData::SdvrpData() : _fileName(), _depotVehTypePairPts(), _customerPts(),
_roundMode(), _distanceIsExplicit(false), _instanceHasTimeWindows(false), _vehicleCapacity(),
_unlimitedFleet(), _setOneInstance(false), _nbDiffDelQuantities(), _kMax(),
_avgRoutesLength(), _maxDemand(0.0f), _timeWindowRatio()
{}

void sdvrp::SdvrpData::setParameters(const SdvrpParameters & applicationSpecificParameters)
{
    _roundMode = applicationSpecificParameters.roundMode();
    _vehicleCapacity = applicationSpecificParameters.capacity();
    _unlimitedFleet = applicationSpecificParameters.unlimitedFleet();
    _nbDiffDelQuantities = applicationSpecificParameters.nbDiffDeliveryQuantitiesPerCustomer();
}

void sdvrp::SdvrpData::clearMemory()
{
    for (auto depPtrIt = _depotVehTypePairPts.begin(); depPtrIt != _depotVehTypePairPts.end(); ++depPtrIt)
        delete *depPtrIt;
    _depotVehTypePairPts.clear();

    for (auto custPtrIt = _customerPts.begin(); custPtrIt != _customerPts.end(); ++custPtrIt)
        delete *custPtrIt;
    _customerPts.clear();
}

double sdvrp::SdvrpData::computeInitialUpperBound()
{
    double costUpperBound = 0;
    int nbCustomers = _customerPts.size();
    int nbDepots = _depotVehTypePairPts.size();
    for (int customerId = 0; customerId < nbCustomers; ++customerId)
    {
        for (int customerId2 = customerId + 1; customerId2 < nbCustomers; ++customerId2)
            costUpperBound += getCustomerToCustomerDistance(customerId, customerId2);
        for (int depotId = 0; depotId < nbDepots; ++depotId)
            costUpperBound += 2 * getDepotToCustomerDistance(depotId, customerId);
    }
    return costUpperBound;
}

int sdvrp::SdvrpData::getTotalDemand() const
{
    int nbCustomers = _customerPts.size();
    int totalDemand = 0;
    for (int customerId = 0; customerId < nbCustomers; ++customerId)
        totalDemand += getDemand(customerId);
    return totalDemand;
}

void sdvrp::SdvrpData::calculateGreatestCommonDivisors()
{
    int result;
    for (int vehicleType = 0; vehicleType < _depotVehTypePairPts.size(); ++vehicleType)
    {
        result = _depotVehTypePairPts[vehicleType]->getCapacity();
        for (int customerId = 0; customerId < _customerPts.size(); ++customerId)
        {
            result = gcd(result, _customerPts[customerId]->getDemand());
        }
    }
    _greatestCommonDivisor = result;
    std::cout << "Instance greatest common divisor is equal to " << result << std::endl;
}

void sdvrp::SdvrpData::calculateShortestPathMatrix()
{
    double distance;

    _shortestPathMatrix.resize( (int)_customerPts.size()+1, std::vector<double>((int)_customerPts.size()+1, 0.0));
    for (int i = 0; i < (int)_customerPts.size(); ++i)
    {
        for (int j = i+1; j < (int)_customerPts.size(); ++j)
        {
            distance = getCustomerToCustomerDistance(i, j);
            _shortestPathMatrix[i][j] = distance;
            _shortestPathMatrix[j][i] = distance;
        }
    }
    for (int i = 0; i < (int)_customerPts.size(); ++i)
    {
        distance = getDepotToCustomerDistance(0, i);
        _shortestPathMatrix[(int)_customerPts.size()][i] = distance;
        _shortestPathMatrix[i][(int)_customerPts.size()] = distance;
    }

    if (_instanceHasTimeWindows || _roundMode == DISTANCES_ROUND_MODE_NEAREST_INTEGER)
    {
        for (int k = 0; k < (int)_shortestPathMatrix.size(); ++k)
        {
            for (int i = 0; i < (int)_shortestPathMatrix.size(); ++i)
            {
                for (int j = 0; j < (int)_shortestPathMatrix.size(); ++j)
                {
                    if (_shortestPathMatrix[i][j] > _shortestPathMatrix[i][k] + _shortestPathMatrix[k][j])
                    {
                        _shortestPathMatrix[i][j] = _shortestPathMatrix[i][k] + _shortestPathMatrix[k][j];
                    }
                }
            }
        }
    }
}