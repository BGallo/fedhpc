/**
 *
 * This file RCSPSolver.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/RCSPSolver.h"

sdvrp::RCSPSolver::RCSPSolver(BcFormulation & spForm) :
subproblemFormulation(spForm), vertices(), oracle(nullptr)
{
    /// At first we set the network through BcNetwork class.
    BcNetwork network(subproblemFormulation, PathAttrMask, data.getNbCustomers(),
                      data.getNbCustomers(), data.getNbCustomers());

    /// If the instance has time windows, we set two resources: distance (i.e. time, as main resource) and capacity,
    /// and build vertices and arcs for the SDVRPTW instance.
    if (data._instanceHasTimeWindows)
    {
        BcNetworkResource distanceResource(network, 0);
        distanceResource.setAsMainResource();
        BcNetworkResource capacityResource(network, 1);

        buildSDVRPTWVertices(network, distanceResource, capacityResource);
        buildSDVRPTWArcs(network, distanceResource, capacityResource);
    }
    else /// else we just have the capacity resource, which is the main one.
    {
        BcNetworkResource capacityResource(network, 0);
        capacityResource.setAsMainResource();

        buildSDVRPVertices(network, capacityResource);
        buildSDVRPArcs(network, capacityResource);
    }
    oracle = new BcRCSPFunctor(subproblemFormulation);
}

int sdvrp::RCSPSolver::getArcCapacityResourceConsumption(const int & customerId, const int & arcDeliveryId)
{
    /// The first arc delivery representation always has capacity resource consumption
    /// equal to the greatest common divisor.
    if (arcDeliveryId == 0)
    {
        return data.getGreatestCommonDivisor();
    }

    /// For the other delivery representation arcs, the capacity resource consumption is the smallest multiple of
    /// the greatest common divisor that fits within each of the (nbArcsPerCustomer - 1) intervals of demand $d_{i}$,
    /// each interval corresponding to one delivery representation.
    int nbArcsPerCustomer = parameters.nbDiffDeliveryQuantitiesPerCustomer();
    int instanceGCD = data.getGreatestCommonDivisor();
    int resourceConsumption = instanceGCD;

    double arcDemand = (double) data.getDemand(customerId) / (nbArcsPerCustomer - 1) * arcDeliveryId;
    int roundedUpDemand = (int) ceil(arcDemand - 1e-6);
    if (roundedUpDemand > instanceGCD)
    {
        if (data.gcd(roundedUpDemand, instanceGCD) == instanceGCD)
            resourceConsumption = roundedUpDemand;
        else
            resourceConsumption = (roundedUpDemand / instanceGCD + 1) * instanceGCD;
    }
    return resourceConsumption;
}

void sdvrp::RCSPSolver::buildSDVRPTWVertices(BcNetwork & network, BcNetworkResource & distanceResource,
                                             BcNetworkResource & capacityResource)
{
    /// The source vertex has id zero, then for every customer we have two node representations:
    /// - first one for smaller or equal the half delivery with odd id's = 2 * customerId - 1, and,
    /// - second one for strictly more than half delivery (packing set) with even id's = 2 * customerId,
    /// at last, the sink vertex has id = nbCustomers * 2 + 1.
    int sourceVertId = 0;
    int sinkVertId = data.getNbCustomers() * 2 + 1;

    for (int vertexId = 0; vertexId <= sinkVertId; ++vertexId)
    {
        int customerId = (vertexId - 1) / 2;
        BcVertex bcVertex = network.createVertex();
        vertices.push_back(bcVertex);

        /// First the bounds on the consumption of the distance resource are set.
        /// LB's.
        if ((vertexId == sinkVertId) || (vertexId == sourceVertId))
            distanceResource.setVertexConsumptionLB(bcVertex, 0);
        else
            distanceResource.setVertexConsumptionLB(bcVertex, data.getTimeWindowBegin(customerId));
        /// UB's.
        if ((vertexId == sinkVertId) || (vertexId == sourceVertId))
            distanceResource.setVertexConsumptionUB(bcVertex, data.getMaxDistance(0));
        else
            distanceResource.setVertexConsumptionUB(bcVertex, data.getTimeWindowEnd(customerId));

        /// Then the bounds on the consumption of the capacity resource are set.
        capacityResource.setVertexConsumptionLB(bcVertex, 0);
        capacityResource.setVertexConsumptionUB(bcVertex, data.getCapacity(0));

        /// At last, vertices are named, source and sink nodes and elementarity, covering and packing sets are set.
        if (vertexId == sourceVertId)
        {
            network.setPathSource(bcVertex);
            bcVertex.setName(std::to_string(0));
        }
        else if (vertexId == sinkVertId)
        {
            network.setPathSink(bcVertex);
            bcVertex.setName(std::to_string(data.getNbCustomers() + 1));
        }
        else
        {
            bcVertex.setElementaritySet(customerId);
            bcVertex.setCoveringSet(customerId);
            if (vertexId % 2 == 0)
                bcVertex.setPackingSet(customerId);
            bcVertex.setName(std::to_string(customerId) + (vertexId % 2 == 0 ? "l" : "s"));
        }
    }
}

void sdvrp::RCSPSolver::buildSDVRPVertices(BcNetwork & network, BcNetworkResource & capacityResource)
{
    /// The source vertex has id zero, then for every customer we have two node representations:
    /// - first one for smaller or equal the half delivery with odd id's = 2 * customerId - 1, and,
    /// - second one for strictly more than half delivery (packing set) with even id's = 2 * customerId,
    /// at last, the sink vertex has id = nbCustomers * 2 + 1.
    int sourceVertId = 0;
    int sinkVertId = data.getNbCustomers() * 2 + 1;

    for (int vertexId = 0; vertexId <= sinkVertId; ++vertexId)
    {
        int customerId = (vertexId - 1) / 2;
        BcVertex bcVertex = network.createVertex();
        vertices.push_back(bcVertex);

        /// The bounds on the consumption of the capacity resource are set.
        capacityResource.setVertexConsumptionLB(bcVertex, 0);
        capacityResource.setVertexConsumptionUB(bcVertex, data.getCapacity(0));

        /// Vertices are named, source and sink nodes and elementarity, covering and packing sets are set.
        if (vertexId == sourceVertId)
        {
            network.setPathSource(bcVertex);
            bcVertex.setName(std::to_string(0));
        }
        else if (vertexId == sinkVertId)
        {
            network.setPathSink(bcVertex);
            bcVertex.setName(std::to_string(data.getNbCustomers() + 1));
        }
        else
        {
            bcVertex.setElementaritySet(customerId);
            bcVertex.setCoveringSet(customerId);
            if (vertexId % 2 == 0)
                bcVertex.setPackingSet(customerId);
            bcVertex.setName(std::to_string(customerId) + (vertexId % 2 == 0 ? "l" : "s"));
        }
    }
}

void sdvrp::RCSPSolver::buildSDVRPTWArcs(BcNetwork & network, BcNetworkResource & distanceResource,
                                         BcNetworkResource & capacityResource)
{
    /// Setting useful local variables.
    int nbCustomers = data.getNbCustomers();
    int sourceVertexId = 0;
    int sinkVertexId = 2 * nbCustomers + 1;
    int nbArcsPerCustomer = parameters.nbDiffDeliveryQuantitiesPerCustomer();
    int instanceGCD = data.getGreatestCommonDivisor();

    BcVarArray eVar(subproblemFormulation, "E");
    BcVarArray xVar(subproblemFormulation, "X");
    BcVarArray x2Var(subproblemFormulation, "X2");

    /// We load the preprocessed customer to customer distances matrix in variable distanceMatrix.
    std::vector<std::vector<double>> distanceMatrix(nbCustomers, std::vector<double>(nbCustomers, 10e15));
    for (int customerId1 = 0; customerId1 < nbCustomers; ++customerId1)
    {
        distanceMatrix[customerId1][customerId1] = 0;
        for (int customerId2 = customerId1 + 1; customerId2 < nbCustomers; ++customerId2)
        {
            double distance = data.getCustomerToCustomerPreprocessedDistance(customerId1, customerId2);
            distanceMatrix[customerId2][customerId1] = distanceMatrix[customerId1][customerId2] = distance;
        }
    }
    /// We load distanceMatrix in the network. This function is valid for covering sets too.
    network.setElemSetsDistanceMatrix(distanceMatrix);

    /// For each customer node representation, i.e. "less than half delivery" and "strictly more than half delivery"
    /// ones, we add one arc for each delivery representation from pairs of customer node representation (tailVertexId)
    /// to customer node representation (headVertexId) such that tailCustomerId != headCustomerId.
    for (int tailVertexId = sourceVertexId; tailVertexId < sinkVertexId; ++tailVertexId)
    {
        int tailCustomerId = (tailVertexId == sourceVertexId) ? -1 : (tailVertexId - 1) / 2;

        /// Creating multiple delivery arcs from source to customer and from customer to customer nodes.
        for (int headCustomerId = 0; headCustomerId < nbCustomers; ++headCustomerId)
        {
            if (headCustomerId != tailCustomerId)
                for (int deliveryId = 0; deliveryId < nbArcsPerCustomer; ++deliveryId)
                {
                    double capResCons = getArcCapacityResourceConsumption(headCustomerId,
                                                                          deliveryId);
                    if ((deliveryId < nbArcsPerCustomer - 1)
                        && (capResCons >= getArcCapacityResourceConsumption(headCustomerId,
                                                                            deliveryId + 1)))
                        continue;

                    /// headVertexId would have the same Id for the two node representations.
                    int headVertexId = headCustomerId * 2 + 1;
                    /// We correct headVertexId += 1 for the "strictly more than half delivery" node, i.e. packing set.
                    if (capResCons > (double) data.getDemand(headCustomerId) / 2.0 + 1e-6)
                        headVertexId += 1; /// node belonging to a packing set

                    /// We define the arc name where the suffix "l" stands for large (strictly more than half delivery)
                    /// and "s" stands for small (less than half delivery).
                    /// Example for arcName in format customerId1l,customerId2s,capacityResourceConsumption: 2l,5s,5.
                    BcArc bcArc = network.createArc(tailVertexId, headVertexId, 0);
                    std::string arcName = std::to_string(tailCustomerId + 1)
                                          + (tailVertexId == sourceVertexId ? "" : (tailVertexId % 2 == 0 ? "l" : "s"))
                                          + "," + std::to_string(headCustomerId+1)
                                          + (headVertexId % 2 == 0 ? "l" : "s") + ","
                                          + std::to_string((int)capResCons);
                    bcArc.setName(arcName);
                    /// We set the capacity resource consumption of the arc.
                    capacityResource.setArcConsumption(bcArc, capResCons);

                    /// We set the distance resource of the arc and embed the service time at it.
                    double distance = (tailCustomerId == -1) /* depot */
                                      ? data.getDepotToCustomerDistance(0, headCustomerId)
                                      : data.getCustomerToCustomerDistance(tailCustomerId,
                                                                           headCustomerId);
                    double serviceTime = (tailCustomerId == -1) ? 0.0 : (double) (data.getServiceTime(tailCustomerId));
                    distanceResource.setArcConsumption(bcArc, floor(distance * 10) / 10 + serviceTime);

                    /// Mapping arc variables to edge variable.
                    BcVar bcVar;
                    if (tailCustomerId < headCustomerId)
                        bcVar = BcVar(eVar[tailCustomerId + 1][headCustomerId + 1]);
                    else
                        bcVar = BcVar(eVar[headCustomerId + 1][tailCustomerId + 1]);
                    bcArc.arcVar(bcVar);


                    int customerNecessaryNumberOfDeliveryRepresentations = data.getDemand(headCustomerId) / instanceGCD;
                    /// If customer is partially discretised, coefficients are 1,2,...,K = nbArcsPerCustomer.
                    if (customerNecessaryNumberOfDeliveryRepresentations > nbArcsPerCustomer)
                        bcArc.addVarAssociation((BcVar) xVar[headCustomerId], deliveryId + 1);
                    /// If customer is fully discretised, coefficients are $\frac{q}{\bar{q}}, \forall q\in D_{i}$.
                    else
                        bcArc.addVarAssociation((BcVar) xVar[headCustomerId], capResCons / instanceGCD);
                    /// If nbArcsPerCustomer is strictly greater than 2, coefficients in constraints DCC2 are equal to
                    /// one for partial deliveries and two only for full delivery.
                    if (nbArcsPerCustomer > 2)
                    {
                        int x2Coefficient = (capResCons > (double) data.getDemand(headCustomerId) - 1e-6) ? 2 : 1;
                        bcArc.addVarAssociation((BcVar) x2Var[headCustomerId], x2Coefficient);
                    }
                }
        }

        /// From each customer node representation having odd and even tailVerTexId's, arcs to the sink are added.
        /// These arcs have no capacity resource consumption
        if (tailCustomerId >= 0)
        {
            BcArc bcArc = network.createArc(tailVertexId, sinkVertexId, 0);
            bcArc.setName(std::to_string(tailCustomerId + 1) + (tailVertexId % 2 == 0 ? "l" : "s")
                          + "," + std::to_string(nbCustomers + 1) + ",0");

            capacityResource.setArcConsumption(bcArc, 0.0);

            double distance = data.getDepotToCustomerDistance(0, tailCustomerId);
            double serviceTime = (double) (data.getServiceTime(tailCustomerId));
            distanceResource.setArcConsumption(bcArc, floor(distance * 10) / 10 + serviceTime);

            /// Mapping arc variables to edge variable.
            BcVar bcVar = BcVar(eVar[0][tailCustomerId + 1]);
            bcArc.arcVar(bcVar);
        }
    }
}

void sdvrp::RCSPSolver::buildSDVRPArcs(BcNetwork & network, BcNetworkResource & capacityResource)
{
    /// Setting useful local variables.
    int nbCustomers = data.getNbCustomers();
    int sourceVertexId = 0;
    int sinkVertexId = 2 * nbCustomers + 1;
    int nbArcsPerCustomer = parameters.nbDiffDeliveryQuantitiesPerCustomer();
    int instanceGCD = data.getGreatestCommonDivisor();

    BcVarArray eVar(subproblemFormulation, "E");
    BcVarArray xVar(subproblemFormulation, "X");
    BcVarArray x2Var(subproblemFormulation, "X2");

    /// We load the preprocessed customer to customer distances matrix in variable distanceMatrix.
    std::vector<std::vector<double>> distanceMatrix(nbCustomers, std::vector<double>(nbCustomers, 10e15));
    for (int customerId1 = 0; customerId1 < nbCustomers; ++customerId1)
    {
        distanceMatrix[customerId1][customerId1] = 0;
        for (int customerId2 = customerId1 + 1; customerId2 < nbCustomers; ++customerId2)
        {
            double distance = data.getCustomerToCustomerPreprocessedDistance(customerId1, customerId2);
            distanceMatrix[customerId2][customerId1] = distanceMatrix[customerId1][customerId2] = distance;
        }
    }
    /// We load distanceMatrix in the network. This function is valid for covering sets too.
    network.setElemSetsDistanceMatrix(distanceMatrix);

    /// For each customer node representation, i.e. "less than half delivery" and "strictly more than half delivery"
    /// ones, we add one arc for each delivery representation from pairs of customer node representation (tailVertexId)
    /// to customer node representation (headVertexId) such that tailCustomerId != headCustomerId.
    for (int tailVertexId = sourceVertexId; tailVertexId < sinkVertexId; ++tailVertexId)
    {
        int tailCustomerId = (tailVertexId == sourceVertexId) ? -1 : (tailVertexId - 1) / 2;

        /// Creating multiple delivery arcs from source to customer and from customer to customer nodes.
        for (int headCustomerId = 0; headCustomerId < nbCustomers; ++headCustomerId)
        {
            if (headCustomerId != tailCustomerId)
                for (int deliveryId = 0; deliveryId < nbArcsPerCustomer; ++deliveryId)
                {
                    double capResCons = getArcCapacityResourceConsumption(headCustomerId,
                                                                          deliveryId);
                    if ((deliveryId < nbArcsPerCustomer - 1)
                        && (capResCons >= getArcCapacityResourceConsumption(headCustomerId,
                                                                            deliveryId + 1)))
                        continue;

                    /// headVertexId would have the same Id for the two node representations.
                    int headVertexId = headCustomerId * 2 + 1;
                    /// We correct headVertexId += 1 for the "strictly more than half delivery" node, i.e. packing set.
                    if (capResCons > (double) data.getDemand(headCustomerId) / 2.0 + 1e-6)
                        headVertexId += 1; /// node belonging to a packing set

                    /// We define the arc name where the suffix "l" stands for large (strictly more than half delivery)
                    /// and "s" stands for small (less than half delivery).
                    /// Example for arcName in format customerId1l,customerId2s,capacityResourceConsumption: 2l,5s,5.
                    BcArc bcArc = network.createArc(tailVertexId, headVertexId, 0);
                    std::string arcName = std::to_string(tailCustomerId + 1)
                                          + (tailVertexId == sourceVertexId ? "" : (tailVertexId % 2 == 0 ? "l" : "s"))
                                          + "," + std::to_string(headCustomerId+1)
                                          + (headVertexId % 2 == 0 ? "l" : "s") + ","
                                          + std::to_string((int)capResCons);
                    bcArc.setName(arcName);
                    /// We set the capacity resource consumption of the arc.
                    capacityResource.setArcConsumption(bcArc, capResCons);

                    /// Mapping arc variables to edge variable.
                    BcVar bcVar;
                    if (tailCustomerId < headCustomerId)
                        bcVar = BcVar(eVar[tailCustomerId + 1][headCustomerId + 1]);
                    else
                        bcVar = BcVar(eVar[headCustomerId + 1][tailCustomerId + 1]);
                    bcArc.arcVar(bcVar);


                    int customerNecessaryNumberOfDeliveryRepresentations = data.getDemand(headCustomerId) / instanceGCD;
                    /// If customer is partially discretised, coefficients are 1,2,...,K = nbArcsPerCustomer.
                    if (customerNecessaryNumberOfDeliveryRepresentations > nbArcsPerCustomer)
                        bcArc.addVarAssociation((BcVar) xVar[headCustomerId], deliveryId + 1);
                        /// If customer is fully discretised, coefficients are $\frac{q}{\bar{q}}, \forall q\in D_{i}$.
                    else
                        bcArc.addVarAssociation((BcVar) xVar[headCustomerId], capResCons / instanceGCD);
                    /// If nbArcsPerCustomer is strictly greater than 2, coefficients in constraints DCC2 are equal to
                    /// one for partial deliveries and two only for full delivery.
                    if (nbArcsPerCustomer > 2)
                    {
                        int x2Coefficient = (capResCons > (double) data.getDemand(headCustomerId) - 1e-6) ? 2 : 1;
                        bcArc.addVarAssociation((BcVar) x2Var[headCustomerId], x2Coefficient);
                    }
                }
        }

        /// From each customer node representation having odd and even tailVerTexId's, arcs to the sink are added.
        /// These arcs have no capacity resource consumption
        if (tailCustomerId >= 0)
        {
            BcArc bcArc = network.createArc(tailVertexId, sinkVertexId, 0);
            bcArc.setName(std::to_string(tailCustomerId + 1) + (tailVertexId % 2 == 0 ? "l" : "s")
                          + "," + std::to_string(nbCustomers + 1) + ",0");

            capacityResource.setArcConsumption(bcArc, 0.0);

            /// Mapping arc variables to edge variable.
            BcVar bcVar = BcVar(eVar[0][tailCustomerId + 1]);
            bcArc.arcVar(bcVar);
        }
    }
}
