/**
 *
 * This file CutSeparation.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/CutSeparation.h"

sdvrp::EdgeCutSeparationRoutine::EdgeCutSeparationRoutine(const std::string & varName) : _varName(varName),
_cutCount(0)
{}

int sdvrp::EdgeCutSeparationRoutine::operator()(BcFormulation formPtr,
                                                BcSolution & primalSol,
                                                double & maxViolation,
                                                std::list< BcConstr > & cutList)
{
    std::set<BcVar> varSet;
    primalSol.extractVar(_varName, varSet);

    BcCutConstrArray edgeCutConstr(formPtr, "EDC");

    int numCutsAdded = 0;
    for (auto & bcVar : varSet)
    {
        if ((bcVar.id().first() > 0) && (bcVar.solVal() > 1 + 1e-6))
        {
            BcConstr edgeCut = edgeCutConstr(_cutCount++);
            edgeCut <= 1.0;
            edgeCut += bcVar;
            cutList.push_back(edgeCut);
            numCutsAdded += 1;
        }
    }
    return numCutsAdded;
}
