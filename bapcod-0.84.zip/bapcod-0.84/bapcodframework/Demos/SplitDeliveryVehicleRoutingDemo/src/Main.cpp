/**
 *
 * This file Main.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/Loader.h"
#include "../include/Model.h"
#include "../include/SolutionChecker.h"

#include <iostream>
#include <bcModelPointerC.hpp>

#define APPLICATION_VERSION "6.1"   /// this should be increased every commit.
/// also, we should put this number in the commit message
#define APPLICATION_DATE "17/11/2021"

int main(int argc, char* argv[])
{
    /// BaPCod parameters are read here (-b option in the command line)
    BcInitialisation bapcodInit(argc, argv);

    std::cout << "Application version is " << APPLICATION_VERSION << ", " << APPLICATION_DATE << std::endl;
    std::cout << "command line:";
    for (int i = 0; i < argc; i++)
        printf("%s ", argv[i]);
    printf("\n");

    /// Loading parameters and data through the loader class and checking if reading/loading was successful.
    sdvrp::Loader loader;
    if (!loader.loadParameters(bapcodInit.configFile(), argc, argv) ||
        !loader.loadData(bapcodInit.instanceFile()))
    {
        return -1;
    }

    sdvrp::SolutionChecker * solutionChecker = new sdvrp::SolutionChecker;

    sdvrp::Model model(bapcodInit);
    model.attach(solutionChecker);

    BcSolution solution = model.solve();
    bool isSolutionFeasible = solution.defined() ?
            solutionChecker->printSolutionAndCheckIfFeasibleMultiDelivery(solution, false) : false;

    bapcodInit.outputBaPCodStatistics(bapcodInit.instanceFile());

    return 0;
}
