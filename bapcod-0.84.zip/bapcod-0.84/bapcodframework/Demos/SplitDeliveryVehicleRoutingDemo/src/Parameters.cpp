/**
 *
 * This file Parameters.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/Parameters.h"

sdvrp::SdvrpParameters::SdvrpParameters() :
        ParameterParser("toDiscardParameterFileName_"),
        _cutOffValue("cutOffValue", -1),
        _unlimitedFleet("unlimitedFleet", false),
        _capacity("capacity", 100),
        _nbDiffDeliveryQuantitiesPerCustomer("nbDiffDeliveryQuantitiesPerCustomer", 2),
        _roundMode("roundMode", DISTANCES_ROUND_MODE_ONE_DECIMAL)
{}

bool sdvrp::SdvrpParameters::loadParameters(const std::string & parameterFileName, int argc, char *argv[],
                                            std::ostream & os)
{
    setParameterFileName(parameterFileName);

    addApplicationParameter(_cutOffValue);
    addApplicationParameter(_unlimitedFleet);
    addApplicationParameter(_capacity);
    addApplicationParameter(_nbDiffDeliveryQuantitiesPerCustomer);
    addApplicationParameter(_roundMode);

    parse(argc, argv);
    print(os);

    return true;
}

std::ostream & sdvrp::SdvrpParameters::print(std::ostream & os) const
{
    os << "Split-delivery Vehicle Routing Parameters  " << std::endl;
    os << "Subproblem solver: resource constrained shortest path solver" << std::endl;
    os << _nbDiffDeliveryQuantitiesPerCustomer << std::endl;
    os << _capacity << std::endl;
    os << _unlimitedFleet << std::endl;
    switch (_roundMode())
    {
        case DISTANCES_ROUND_MODE_NO:
            os << "Distances rounding mode : no" << std::endl;
            break;
        case DISTANCES_ROUND_MODE_ONE_DECIMAL:
            os << "Distances rounding mode : to one decimal place" << std::endl;
            break;
        case DISTANCES_ROUND_MODE_DOWN:
            os << "Distances rounding mode : round down" << std::endl;
            break;
        case DISTANCES_ROUND_MODE_NEAREST_INTEGER:
            os << "Distances rounding mode : to the nearest integer" << std::endl;
            break;
    }
    os << _cutOffValue << std::endl;

    return (os);
}


