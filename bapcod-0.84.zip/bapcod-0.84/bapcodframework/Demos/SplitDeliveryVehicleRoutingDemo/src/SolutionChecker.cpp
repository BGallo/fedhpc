/**
 *
 * This file SolutionChecker.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/SolutionChecker.h"

bool sdvrp::SolutionChecker::operator()(BcSolution newSolution) const
{
    return printSolutionAndCheckIfFeasibleMultiDelivery(newSolution, false);
}

bool sdvrp::SolutionChecker::printAndBuildSolutionAndCheckIfFeasibleGeneric(
        std::vector<ColumnsInSolution> & solutionColumns) const
{
    std::cout << std::endl
              << "<<<----------     Flow graph based generic solution checker and builder     ---------->>>"
              << std::endl << std::endl;
    bool solutionIsCapacityFeasible = false;

    int numCols = static_cast<int>(solutionColumns.size());
    int numElemSets = static_cast<int>(data._customerPts.size());

    double totalDemand = 0.0f;
    double totalCost = 0.0f;

    for (int elemSet = 0; elemSet < numElemSets; ++elemSet)
        totalDemand += data._customerPts[elemSet]->getDemand();

    double edgeBigM = ceil(2*totalDemand);

    std::vector<std::vector<double>> flowGraph( numCols+numElemSets+2,
                                                std::vector<double> ( numCols+numElemSets+2, 0.0f ) );

    int sourceIdx = numCols+numElemSets;
    int sinkIdx = numCols+numElemSets+1;

    for (int i = 0; i < numCols; ++i)
    {
        flowGraph[sourceIdx][i] = solutionColumns[i]._capacity * solutionColumns[i]._multiplicity;
    }

    for (int i = 0; i < numElemSets; ++i)
    {
        flowGraph[numCols+i][sinkIdx] = data._customerPts[i]->getDemand();
    }

    for (const auto & col : solutionColumns)
    {
        for (const auto & setId : col._setIds)
        {
            flowGraph[col._index][numCols+setId] = edgeBigM;
        }
    }

    //std::cout << "(int)flowGraph.size(): " << (int)flowGraph.size() << std::endl;
    //for (auto line : flowGraph)
    //{
    //    for (auto col : line)
    //    {
    //        std::cout << col << " ";
    //    }
    //    std::cout << std::endl;
    //}

    bcp_rcsp::MinCutDigraph sepGraph( flowGraph );

    sepGraph.findMinCut(sourceIdx, sinkIdx);

    //std::cout << "sepGraph.getMaxFlow() = " << sepGraph.getMaxFlow() << std::endl;
    //std::cout << "totalDemand = " << totalDemand << std::endl;

    /// Method MinCutDigraph.getMaxFlow() provides the maximum flow value but does not calculates the optimal flow.
    /// Thus, the graph is saturated and some customers may display a demand overflow. Nevertheless, MaxFlow is valid!
    /// TO-DO: Implement MinCutDigraph.findOptimalFlow().
    if (sepGraph.getMaxFlow() > totalDemand - TOLERANCE)
    {
        //std::cout << "The flow graph is covered and the solution is feasible!" << std::endl;
        solutionIsCapacityFeasible = true;
        int vehicleUsage = 0;
        int arcFlow;
        int delivery;

        /// As the maximum flow algorithm terminates with a preflow, i.e. the flow is not optimal, we need to
        /// post-process the solution build to output a coherent solution file in columns format.
        /// TO-DO: Implement MinCutDigraph.findOptimalFlow().
        std::vector<int> residualDemands((int)data._customerPts.size());
        for(int customerId = 0; customerId < (int)data._customerPts.size(); ++ customerId)
        {
            residualDemands[customerId] = data._customerPts[customerId]->getDemand();
        }

        for (auto & col : solutionColumns)
        {
            for (const auto & setId : col._setIds)
            {
                arcFlow = (int)sepGraph.getArcFlow(col._index, numCols+setId);
                delivery = std::min(arcFlow, residualDemands[setId]);
                residualDemands[setId] -= delivery;
                vehicleUsage += delivery;
                col._deliveries.push_back(delivery);
            }
            printf("Vehicle %.2d (%d/%d), cost %.1f : depot -> ",
                   col._index+1,
                   vehicleUsage,
                    //(int)sepGraph.getArcFlow(sourceIdx, col._index),
                   col._capacity,
                   col._cost);

            totalCost += col._cost;

            for (const auto & setId : col._setIds)
            {
                printf("%d (%d/%d) -> ", setId+1, std::min((int)sepGraph.getArcFlow(col._index, numCols+setId),
                                                           static_cast<int>(data.getDemand(setId))),
                       data.getDemand(setId));
            }
            printf("depot\n");
            vehicleUsage = 0;
        }
    }

    if (solutionIsCapacityFeasible)
    {
        std::cout << std::endl << "<<<----------     Solution is capacity feasible and has cost equal to "
                  << totalCost << "     ---------->>>" << std::endl << std::endl;
    }
    else
    {
        std::cout << std::endl << "<<<----------     Solution is not capacity feasible !     ---------->>>"
                  << std::endl << std::endl;
    }

    std::vector<int> nonNullDeliveriesSetIds;
    std::vector<int> nbDeliveriesSetIds((int)data._customerPts.size(), 0);
    //std::vector<int> nbSplits(_maxDemand, 0);
    for (auto & col : solutionColumns)
    {
        for (int setIdIndex = 0; setIdIndex < (int)col._setIds.size(); ++setIdIndex)
        {
            if (col._deliveries[setIdIndex] > 0.0f+TOLERANCE)
            {
                nonNullDeliveriesSetIds.push_back(setIdIndex);
                nbDeliveriesSetIds[col._setIds[setIdIndex]] += 1;
            }
        }
        if ((int)nonNullDeliveriesSetIds.size() == 1)
        {
            if(col._deliveries[nonNullDeliveriesSetIds[0]] >
               ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[0]]]->getDemand()/2.0)+TOLERANCE)
            {
                std::cout << "AN 0 0," << col._setIds[nonNullDeliveriesSetIds[0]]+1 << "l,"
                          << col._deliveries[nonNullDeliveriesSetIds[0]] << " "
                          << col._setIds[nonNullDeliveriesSetIds[0]]+1
                          << "l," << data.getNbCustomers()+1 << ",0" << std::endl;
            }
            else
            {
                std::cout << "AN 0 0," << col._setIds[nonNullDeliveriesSetIds[0]]+1 << "s,"
                          << col._deliveries[nonNullDeliveriesSetIds[0]] << " "
                          << col._setIds[nonNullDeliveriesSetIds[0]]+1
                          << "s," << data.getNbCustomers()+1 << ",0" << std::endl;
            }
        }
        else if ((int)nonNullDeliveriesSetIds.size() > 1)
        {
            std::cout << "AN 0 ";
            for (int setIdIndex = 0; setIdIndex < (int)nonNullDeliveriesSetIds.size(); ++setIdIndex)
            {
                if (setIdIndex == 0)
                {
                    if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] >
                       ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex]]]->getDemand()/2.0)+TOLERANCE)
                    {
                        std::cout << "0," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "l,"
                                  << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                    }
                    else
                    {
                        std::cout << "0," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "s,"
                                  << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                    }
                }
                else if (setIdIndex == (int)nonNullDeliveriesSetIds.size()-1)
                {
                    if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex-1]] >
                       ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]]->getDemand()/2.0)+TOLERANCE)
                    {
                        if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] >
                           ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex]]]->getDemand()/2.0)+TOLERANCE)
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1
                                      << "l," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "l,"
                                      << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]]
                                      << " " << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "l,"
                                      << data.getNbCustomers()+1 << ",0" << std::endl;
                        }
                        else
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1
                                      << "l," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "s,"
                                      << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]]
                                      << " " << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "s,"
                                      << data.getNbCustomers()+1 << ",0" << std::endl;
                        }
                    }
                    else
                    {
                        if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] >
                           ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex]]]->getDemand()/2.0)+TOLERANCE)
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1
                                      << "s," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "l,"
                                      << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]]
                                      << " " << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "l,"
                                      << data.getNbCustomers()+1 << ",0" << std::endl;
                        }
                        else
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1
                                      << "s," << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "s,"
                                      << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]]
                                      << " " << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1 << "s,"
                                      << data.getNbCustomers()+1 << ",0" << std::endl;
                        }
                    }
                }
                else
                {
                    if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex-1]] >
                       ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]]->getDemand()/2.0)+TOLERANCE)
                    {
                        if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] >
                           ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex]]]->getDemand()/2.0)+TOLERANCE)
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1 << "l,"
                                      << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1
                                      << "l," << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                        }
                        else
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1 << "l,"
                                      << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1
                                      << "s," << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                        }
                    }
                    else
                    {
                        if(col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] >
                           ((double)data._customerPts[col._setIds[nonNullDeliveriesSetIds[setIdIndex]]]->getDemand()/2.0)+TOLERANCE)
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1 << "s,"
                                      << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1
                                      << "l," << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                        }
                        else
                        {
                            std::cout << col._setIds[nonNullDeliveriesSetIds[setIdIndex-1]]+1 << "s,"
                                      << col._setIds[nonNullDeliveriesSetIds[setIdIndex]]+1
                                      << "s," << col._deliveries[nonNullDeliveriesSetIds[setIdIndex]] << " ";
                        }
                    }
                }
            }
        }
        nonNullDeliveriesSetIds.clear();
    }
    std::cout << std::endl << "<<<----------     End of printing solution columns in \"tailCustId,headCustId,"
              << "resComsumption\" triple format     ---------->>>" << std::endl << std::endl;

    int nbDeliveries = 0;
    int nbSplitCustomers = 0;
    for (int i = 0; i < (int)nbDeliveriesSetIds.size(); ++i)
    {
        nbDeliveries += nbDeliveriesSetIds[i];
    }
    for (int i = 0; i < (int)nbDeliveriesSetIds.size(); ++i)
    {
        if (nbDeliveriesSetIds[i] > 1)
        {
            nbSplitCustomers += 1;
        }
    }
    std::cout << "The solution has a total of " << nbDeliveries << " deliveries and "
              << nbDeliveries-(int)data._customerPts.size() << " splits shared between " << nbSplitCustomers
              << " split customers" << std::endl;
    int totalCustomers = 0;
    int customersCounter = 0;
    int nbDeliverySweeper = 1;
    while (totalCustomers < (int)data._customerPts.size())
    {
        for (int i = 0; i < (int)nbDeliveriesSetIds.size(); ++i)
        {
            if (nbDeliveriesSetIds[i] == nbDeliverySweeper)
            {
                totalCustomers += 1;
                customersCounter += 1;
            }
        }
        if (nbDeliverySweeper == 1)
            std::cout << "The number of customers with no splits is " << customersCounter << std::endl;
        else if (customersCounter > 0)
            std::cout << "The number of customers with " << nbDeliverySweeper-1 << " split(s) is " << customersCounter << std::endl;

        nbDeliverySweeper += 1;
        customersCounter = 0;
    }
    if (nbDeliveries-(int)data._customerPts.size() > 0)
    {
        std::cout << "The following customers have split deliveries:";
        for (int i = 0; i < (int)nbDeliveriesSetIds.size(); ++i)
        {
            if (nbDeliveriesSetIds[i] > 1)
            {
                std::cout << " " << i+1 << "(" << nbDeliveriesSetIds[i] << ")";
            }
        }
        std::cout << std::endl;
    }

    /// ArcId's print solution format.
    //for (auto & col : solutionColumns)
    //{
    //    for (int arcIndex = 0; arcIndex < (int)col._arcIds.size(); ++arcIndex)
    //    {
    //        std::cout << col._arcIds[arcIndex] << " " << col._deliveries[arcIndex] << " ";
    //    }
    //    std::cout << std::endl;
    //}
    //std::cout << std::endl << "<<<----------     End of printing solution columns in \"arcId resComsumption\" "
    //          <<  "tuple format     ---------->>>"
    //          << std::endl << std::endl;

    return solutionIsCapacityFeasible;
}

bool sdvrp::SolutionChecker::printSolutionAndCheckIfFeasibleMultiDelivery(BcSolution & solution,
                                                                          const bool & bestSolution) const
{
    bool solutionIsFeasible = true;
    int nbCustomers = static_cast<int>(data._customerPts.size());
    std::vector< std::vector<int> > splits;
    splits.resize(nbCustomers + 1);

    int sourceVertId = 0;
    int sinkVertId = 2 * nbCustomers + 1;

    std::cout << "------------------------------------------ " << std::endl;
    if (!solution.defined())
    {
        std::cout << "Solution is not defined!" << std::endl;
        std::cout << "------------------------------------------ " << std::endl;
        return false;
    }
    if (bestSolution)
        std::cout << "Best found solution of value " << solution.cost() << " : " << std::endl;
    else
        std::cout << "New solution of value " << solution.cost() << " : " << std::endl;

    solution = solution.next();   /// skip master solution, go straight to the subproblem solutions

    std::vector<std::vector<BcSolution> > solsByVehType(data._depotVehTypePairPts.size());

    while (solution.defined())
    {
        int vehicleType = solution.formulation().id().first();
        solsByVehType[vehicleType].push_back(solution);
        solution = solution.next();
    }

    int numCols = 0;
    bool vertexIsDepot;

    int columnsListIndexer = 0;
    std::vector<ColumnsInSolution> columnsList;

    for (int vehType = 0; vehType < data._depotVehTypePairPts.size(); ++vehType)
    {
        if (solsByVehType[vehType].empty())
            continue;

        BcFormulation spForm(solsByVehType[vehType].front().formulation());
        const BcNetwork network(spForm.network());

        int vehicleNumber = 0;
        DepotVehTypePair * depVehTypePairPtr = data._depotVehTypePairPts[vehType];
        std::vector<BcSolution>::iterator solIt;

        //numCols += (int)solsByVehType[vehType].size();

        for (solIt = solsByVehType[vehType].begin(); solIt != solsByVehType[vehType].end(); ++solIt)
        {
            numCols += solIt->getMultiplicity();

            for (int routeIndex = 0; routeIndex < solIt->getMultiplicity(); ++routeIndex)
            {
                std::cout << "Vehicle " << ++vehicleNumber << " of type " << vehType+1 <<  " (" << solIt->cost() << ") : ";
                if (solIt->orderedIds().empty())
                {
                    std::cout << "\n";
                    continue;
                }

                columnsList.emplace_back(columnsListIndexer + routeIndex,
                                         data._depotVehTypePairPts[vehType]->getCapacity(),
                                         1,//solIt->getMultiplicity(),
                                         solIt->cost());

                int prevVertId = network.getArc(solIt->orderedIds().front()).tail().ref();
                int prevCustId = -1;

                if (prevVertId != sourceVertId)
                {
                    solutionIsFeasible = false; /// first vertex is not depot
                    std::cout << prevVertId;
                }
                else
                {
                    std::cout << "depot";
                }

                double cumTime = 0;
                int cumDemand = 0;
                int vertexPos = 1;
                vertexIsDepot = false;
                for (auto arcId : solIt->orderedIds())
                {
                    if (columnsList[columnsListIndexer + routeIndex]._vertexIds.empty())
                    {
                        columnsList[columnsListIndexer + routeIndex]._vertexIds.push_back(network.getArc(arcId).tail().ref());
                    }
                    int vertexId = network.getArc(arcId).head().ref();
                    vertexIsDepot = vertexId == sinkVertId;
                    int custId = (vertexIsDepot) ? -1 /// -1 means depot
                                                 : (vertexId - 1) / 2;
                    bool prevVertexIsDepot = (prevVertId == sourceVertId);
                    std::cout << " -> ";

                    double distance = 0;
                    if (vertexIsDepot)
                        distance = data.getDepotToCustomerDistance(vehType, prevCustId);
                    else if (prevVertexIsDepot)
                        distance = data.getDepotToCustomerDistance(vehType, custId);
                    else
                        distance = data.getCustomerToCustomerDistance(prevCustId, custId);

                    cumTime += floor(distance * 10) / 10;
                    if (data._instanceHasTimeWindows)
                    {
                        if (!vertexIsDepot && (cumTime < data.getTimeWindowBegin(custId)))
                            cumTime = data.getTimeWindowBegin(custId);

                        if (!vertexIsDepot && (cumTime > data.getTimeWindowEnd(custId)))
                        {
                            solutionIsFeasible = false;
                            //std::cout << " !!!!!!! ";
                        }

                        if (vertexIsDepot && (cumTime > data.getMaxDistance(0)))
                        {
                            //std::cout << " !!!!!!! ";
                            solutionIsFeasible = false;
                        }
                    }

                    if (!vertexIsDepot)
                    {
                        double serviceTime = data.getServiceTime(custId);
                        if (serviceTime > 0)
                            cumTime += serviceTime;
                        const BcArcInfo * arcInfoPtr = ((NetworkFlow *)network)->getArcInfoPtr(arcId);
                        int resId = (data._instanceHasTimeWindows) ? 1 : 0;
                        cumDemand += arcInfoPtr->resConsumption[resId];

                        std::cout << custId + 1;
                        columnsList[columnsListIndexer + routeIndex]._setIds.push_back(custId);
                        columnsList[columnsListIndexer + routeIndex]._vertexIds.push_back(vertexId);
                        columnsList[columnsListIndexer + routeIndex]._arcIds.push_back(arcId);
                        columnsList[columnsListIndexer + routeIndex]._resConsumption.push_back(arcInfoPtr->resConsumption[resId]);

                    }
                    if (vertexIsDepot){
                        std::cout << "depot";
                        columnsList[columnsListIndexer + routeIndex]._vertexIds.push_back(network.getArc(arcId).head().ref());
                        columnsList[columnsListIndexer + routeIndex]._arcIds.push_back(arcId);
                        columnsList[columnsListIndexer + routeIndex]._resConsumption.push_back(0);
                    }

                    prevVertId = vertexId;
                    prevCustId = custId;
                }
                if ((prevVertId > 0) && (prevVertId <= data._customerPts.size()))
                    solutionIsFeasible = false; /// last vertex is not depot
                std::cout << ", demand = " << cumDemand << ", time = " << cumTime << std::endl;
            }
            columnsListIndexer += solIt->getMultiplicity();
        }
    }

    if (numCols != (int)columnsList.size())
    {
        std::cout << "Something weird is happening!" << std::endl;
        std::cout << "------------------------------------------ " << std::endl;
        return false;
    }

    if (solutionIsFeasible)
        solutionIsFeasible = printAndBuildSolutionAndCheckIfFeasibleGeneric(columnsList);

    std::cout << "Solution is " << ((solutionIsFeasible) ? "" : "NOT ") << "feasible" << std::endl;
    std::cout << "------------------------------------------ " << std::endl;

    return solutionIsFeasible;
}