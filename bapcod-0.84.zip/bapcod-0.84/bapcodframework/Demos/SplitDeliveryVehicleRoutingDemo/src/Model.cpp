/**
 *
 * This file Model.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/Model.h"

sdvrp::Model::Model(const BcInitialisation & bcInitialisation) : BcModel(bcInitialisation,
                                                                         bcInitialisation.instanceFile())
{
    buildMultiDeliveryModel(data, parameters);
}

void sdvrp::Model::buildMultiDeliveryModel(const sdvrp::SdvrpData & data, const sdvrp::SdvrpParameters & parameters)
{
    /// Master problem formulation BcMaster, which inherits from BcFormulation, is instantiated with the current model.
    BcMaster master(*this);

    /// The array of subproblem formulations BcColGenSpArray is instantiated with the current model.
    BcColGenSpArray vehicleTypeSubproblemFormulation(*this);
    /// We provide support only for homogeneous fleet case, thus one vehicle type and one subproblem formulation.
    BcFormulation subproblemFormulation = vehicleTypeSubproblemFormulation(0);

    /// We calculate a lower bound on the minimum number of vehicles necessary in a valid solution and
    /// pass this value, as well as a known upper bound on the maximum number of vehicles.
    int minNbVehicles = (data.getTotalDemand()-1)/data._vehicleCapacity + 1;
    subproblemFormulation >= minNbVehicles;
    subproblemFormulation <= data.getMaxNumVehicles(0);

    /// Instantiating arrays of subproblem variables through BcVarArray class constructor.
    /// Edge variables array.
    BcVarArray eVar(subproblemFormulation, "E");
    eVar.type('I');
    eVar.defineIndexName(MultiIndexNames('i', 'j'));
    eVar.priorityForMasterBranching(1.0);
    eVar.priorityForSubproblemBranching(-1);

    /// Arc variables X array.
    BcVarArray xVar(subproblemFormulation, "X");
    xVar.type('C');
    xVar.defineIndexName(MultiIndexNames('i'));
    xVar.priorityForMasterBranching(-1);
    xVar.priorityForSubproblemBranching(-1);

    ///Arc variables X2 array.
    BcVarArray x2Var(subproblemFormulation, "X2");
    x2Var.type('C');
    x2Var.defineIndexName(MultiIndexNames('i'));
    x2Var.priorityForMasterBranching(-1);
    x2Var.priorityForSubproblemBranching(-1);

    /// BcObjective class is instantiated and receives the attribute corresponding to the rounding mode.
    BcObjective objective(*this);
    if ((parameters.roundMode() == DISTANCES_ROUND_MODE_NEAREST_INTEGER)
        || (parameters.roundMode() == DISTANCES_ROUND_MODE_DOWN))
        objective.setMinMaxStatus(BcObjStatus::minInt);
    else
        objective.setMinMaxStatus(BcObjStatus::minFloat);

    /// cutOffValue receives the initial upper bound provided in the command line parameters.
    double cutOffValue = parameters.cutOffValue();
    objective <= cutOffValue;
    objective.setArtCostValue(cutOffValue);

    /// We instantiate branching constraints through BcBranchingConstrArray.
    BcBranchingConstrArray nbVehiclesBranching(master, "NBV",
                                               SelectionStrategy::MostFractional, 1.0);
    nbVehiclesBranching(0);

    BcBranchingConstrArray nbSplitsBranching(master, "NBS",
                                             SelectionStrategy::MostFractional, 0.5);
    for (int customerId = 0; customerId <= static_cast<int>(data.getNbCustomers()); ++customerId)
    {
        nbSplitsBranching(customerId);
    }

    /// First we instantiate edge variables.
    for (int customerId1 = 0; customerId1 < static_cast<int>(data.getNbCustomers()); ++customerId1)
    {
        for (int customerId2 = customerId1+1; customerId2 < static_cast<int>(data.getNbCustomers()); ++customerId2)
        {
            BcVar bcVar = eVar(customerId1+1, customerId2+1);

            double distance = data.getCustomerToCustomerPreprocessedCost(0, customerId1, customerId2);
            double reverseDistance = data.getCustomerToCustomerPreprocessedCost(0,
                                                                                customerId2,
                                                                                customerId1);
            if (distance != reverseDistance)
            {
                std::cout << "Warning: distance " << distance << " from " << customerId1 + 1 << " to "
                          << customerId2 + 1 << " is not equal to the backward distance " << reverseDistance << " !"
                          << std::endl;
            }

            objective += distance * bcVar;

            nbSplitsBranching[customerId1+1] += 0.5 * bcVar;
            nbSplitsBranching[customerId2+1] += 0.5 * bcVar;
            nbSplitsBranching[0] += 0.5 * bcVar;
            nbSplitsBranching[0] += 0.5 * bcVar;
        }

        BcVar bcVar = eVar(0, customerId1 + 1);
        double distance = data.getDepotToCustomerPreprocessedCost(0, customerId1);
        objective += distance * bcVar;
        nbVehiclesBranching[0] += 0.5 * bcVar;
        nbSplitsBranching[customerId1+1] += 0.5 * bcVar;
        nbSplitsBranching[0] += 0.5 * bcVar;
    }

    /// We add degree constraints as demand covering constraints for each customer.
    ///
    /// Recall that we write demand covering constraints in two ways:
    /// - For partially discretised customers, $i\in\mathscr{C}(K)$, we write:
    /// (1) $\sum_{r\in\mathscr{R}}\sum_{q\in D_{i}}\sum_{k=1}^{K}b_{iq}^{r}g_{iq}^{k}k\theta_{r}\geq K$
    /// - For fully discretised customers, we have full information on the deliveries and we write:
    /// (2) $\sum_{r\in\mathscr{R}}\sum_{q\in D_{i}}qb_{iq}^{r}\theta_{r}\geq d_{i}$
    ///
    /// In practice, we divide (2) by $\bar{q}$ reaching to:
    /// (3) $\sum_{r\in\mathscr{R}}\sum_{q\in D_{i}}\frac{q}{\bar{q}}b_{iq}^{r}\theta_{r}\geq d_{i}/\bar{q}$
    ///
    /// Demand covering constraints with BcConstrArray type are instantiated with master formulation
    /// and its given alias, DCC. xVar variables are instantiated and added to its corresponding demand
    /// covering constraints.
    BcConstrArray demandCoveringConstraints(master, "DCC");
    for (int customerId = 0; customerId < static_cast<int>(data.getNbCustomers()); ++customerId)
    {
        /// Each customer $i$ has a number of deliveries to be represented equal to $d_{i}/\bar{q}$.
        int nbNecessaryDeliveryRepresentations = data.getDemand(customerId)/data.getGreatestCommonDivisor();
        /// If this given number is strictly greater than the general maximum number of delivery
        /// representations chosen, which stands for $K$, the customer is partially discretised and we
        /// write its demand covering constraint in format (1). Else, there are as many representations as
        /// necessary to fully discretise the customer. Thus, it is fully discretised and we write (3).
        if (nbNecessaryDeliveryRepresentations > parameters.nbDiffDeliveryQuantitiesPerCustomer())
        {
            /// Here the customer is partially discretised.
            demandCoveringConstraints(customerId) >= parameters.nbDiffDeliveryQuantitiesPerCustomer();
        }
        else
        {
            /// Here the customer is fully discretised.
            demandCoveringConstraints(customerId) >= nbNecessaryDeliveryRepresentations;
        }
        demandCoveringConstraints[customerId] += 1 * xVar(customerId);
    }
    /// In addition, if nbDiffDeliveryQuantitiesPerCustomer() is strictly greater than 2,
    /// we add constraints (alias DCC2):
    /// (4) $\sum_{r\in\mathscr{R}}(2*b_{iF}^{r}+b_{iP}^{r})\theta_{r}\geq 2$
    /// for all customers, fully and partially discretised ones, as it strengthens the formulation.
    ///
    /// DCC2 constraints are instantiated with master formulation.
    /// x2Var variables are instantiated and added to its corresponding demand covering constraints.
    if (parameters.nbDiffDeliveryQuantitiesPerCustomer() > 2)
    {
        BcConstrArray demandCoveringConstraints2(master, "DCC2");
        for (int customerId = 0; customerId < static_cast<int>(data.getNbCustomers()); ++customerId)
        {
            demandCoveringConstraints2(customerId) >= 2;
            demandCoveringConstraints2[customerId] += 1 * x2Var(customerId);
        }
    }

    RCSPSolver rcspSolver(subproblemFormulation);
    subproblemFormulation.attach(rcspSolver.getOracle());

    /// We generate the vector of demands for passing to cut separation oracles.
    std::vector<int> demands(data.getNbCustomers(), 0);
    for (int customerId = 0; customerId < data.getNbCustomers(); ++customerId)
    {
        demands[customerId] = data.getDemand(customerId);
    }

    /// Rounded capacity cuts constructor.
    BcCapacityCutConstrArray capacityCuts(master, data._vehicleCapacity, demands,
                                          false, false, -1,
                                          3.0, 1.0);

    /// Strong k-path cuts constructor.
    BcStrongKPathCutConstrArray strongKPathCuts(master, data._vehicleCapacity, demands,
                                                false, false, -1,
                                                1.0, 1.0);

    /// Limited memory rank-1 cuts constructor.
    BcLimMemRankOneCutConstrArray limMemRank1Cuts(master, 1.0, 1.0,
                                                  false);

    /// false means using covering sets instead of packing ones
    BcPackSetRyanFosterBranching(master, 0.5, true);

    BcCutConstrArray edgeCutConstr(master, "EDC", 'F', 3.0, 1.0);
    edgeCutConstr.attach(new EdgeCutSeparationRoutine("E"));

}
