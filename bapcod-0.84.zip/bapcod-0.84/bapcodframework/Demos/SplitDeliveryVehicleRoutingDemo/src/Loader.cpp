/**
 *
 * This file Loader.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved.
 * See License.pdf file for license terms.
 *
 * Created by Isaac Balster on 28/11/2022.
 *
 * This file is available only for academic use.
 * For other uses, please contact stip-bso@inria.fr.
 *
 **/

#include "../include/Loader.h"

sdvrp::Loader::Loader() : data(SdvrpData::getInstance()), parameters(SdvrpParameters::getInstance()) {}

bool sdvrp::Loader::loadParameters(const std::string & fileName, int argc, char * argv[])
{
    bool success = parameters.loadParameters(fileName, argc, argv);
    if (success)
    {
        data.setParameters(parameters);
    }
    return success;
}

bool sdvrp::Loader::loadData(const std::string & fileName)
{
    /// First we stream the file to ifs and check if it is not possible to open it or if it is empty.
    std::ifstream ifs(fileName.c_str(), std::ios::in);
    if (!ifs)
    {
        std::cerr << "Instance reading error: cannot open file " << fileName << "." << std::endl;
    }
    if (ifs.eof())
    {
        std::cout << "Instance reading error: file " << fileName << " is empty." << std::endl;
        ifs.close();
        return false;
    }

    /// Then if no error condition is met, we proceed by reading the instance file.
    data._fileName = fileName;

    bool success = false;
    success = loadSDVRPFile(fileName);
    ifs.close();

    if (success)
    {
        data._kMax = ((int)data._maxDemand)/data.getGreatestCommonDivisor();

        std::cout << "The value of K_{max} is " << data._kMax << std::endl;
        std::cout << "The value of the maximum demand d_{i} is " << (int)data._maxDemand << std::endl;

        data._avgRoutesLength = ceil((double)data.getCapacity(0) /
                                     ((double)data.getTotalDemand()/(double)data.getNbCustomers()));

        int execTime = 8*(int)ceil(pow(4,log2((double)data.getNbCustomers()/16.0)));
        std::cout << "The benchmark tests heuristic execution time for instance " << data._fileName
                  << " having size / number of customers n = "
                  << data.getNbCustomers() << " is " << execTime << " seconds." << std::endl;

        unsigned lastSlashPosition = data._fileName.find_last_of("/");
        unsigned pointPosition = data._fileName.find(".");

        /// Copy name of the instance without path and file extension.
        std::string shortInstanceName = data._fileName.substr(lastSlashPosition+1,
                                                              pointPosition-(lastSlashPosition+1));

        std::cout << "shortInstanceName: " << shortInstanceName << std::endl;
    }

    return success;
}

bool sdvrp::Loader::loadSDVRPFile(const std::string & inputFileName)
{
    if (loadSDVRPTWFile(inputFileName))
    {
        data._instanceHasTimeWindows = true;
        data.calculateShortestPathMatrix();

        double sumTWSpan = 0.0f;

        for (const auto & customer : data._customerPts)
        {
            sumTWSpan += (double)(customer->getTimeWindowEnd()-customer->getTimeWindowBegin());

            if (data._maxDemand < customer->getDemand())
                data._maxDemand = customer->getDemand();
        }

        data._timeWindowRatio = (sumTWSpan/(double)data._customerPts.size())/data._depotVehTypePairPts[0]->getMaxDistance();

        int nbPartiallyDiscretisedCustomers = 0;
        for (int i = 0; i < (int)data._customerPts.size(); ++i)
        {
            if (data._nbDiffDelQuantities < (data._customerPts[i]->getDemand())/data._greatestCommonDivisor)
            {
                nbPartiallyDiscretisedCustomers += 1;
            }
        }
        std::cout << "A total of " << nbPartiallyDiscretisedCustomers << " out of " << (int)data._customerPts.size()
                  << " customers is partially discretised" << std::endl;
        double partiallyDiscretisedPercentage = double((double)nbPartiallyDiscretisedCustomers/(double)data._customerPts.size());
        printf("The percentage of partially discretised customers is %.4f\n", partiallyDiscretisedPercentage*100);

        return true;
    }
    else
        data.clearMemory();

    data._fileName = inputFileName;

    int slashPos = (int)(data._fileName.size() -1 );

    while (data._fileName[slashPos] != '/')
    {
        slashPos -= 1;
    }

    if (data._fileName[slashPos+1] == 'S' && data._fileName[slashPos+2] == 'D')
        data._setOneInstance = true;

    FILE *f = fopen(data._fileName.c_str(), "r");
    if (f == NULL) {
        std::cout << "Instance reading error: cannot open file " << inputFileName << "." << std::endl;
        exit(1);
    }

    unsigned int dimension = 0;
    unsigned int temp;
    int capacity(0);
    char *lineBuf = new char [500];

    bool isCoordinateData = false;
    bool isFullMatrix = false;
    bool isLowerDiagRow = false;
    bool isUpperDiagRow = false;
    bool isUpperRow = false;
    bool isLowerRow = false;

    while (fgets(lineBuf, 500, f))
    {
        if (strncmp(lineBuf, "DIMENSION",strlen("DIMENSION")) == 0)
        {
            if ((sscanf(lineBuf, "DIMENSION : %d", &dimension) != 1)
                && (sscanf(lineBuf, "DIMENSION: %d", &dimension) != 1))
            {
                std::cerr << "Error : cannot read DIMENSION" << std::endl;
                exit(1);
            }
        }
        if (strncmp(lineBuf, "CAPACITY",strlen("CAPACITY")) == 0)
        {
            if ((sscanf(lineBuf, "CAPACITY : %d", &capacity) != 1)
                && (sscanf(lineBuf, "CAPACITY: %d", &capacity) != 1))
            {
                std::cerr << "Error : cannot read CAPACITY" << std::endl;
                exit(1);
            }
        }
        /// If data._instanceHasTimeWindows == false, command line --capacity parameter is overwritten by instance value.
        data._vehicleCapacity = capacity;

        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT: LOWER_ROW", strlen("EDGE_WEIGHT_FORMAT: LOWER_ROW")) == 0 )
            isLowerRow = true;
        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT : LOWER_ROW", strlen("EDGE_WEIGHT_FORMAT : LOWER_ROW")) == 0 )
            isLowerRow = true;

        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT: UPPER_ROW", strlen("EDGE_WEIGHT_FORMAT: UPPER_ROW")) == 0 )
            isUpperRow = true;
        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT : UPPER_ROW", strlen("EDGE_WEIGHT_FORMAT : UPPER_ROW")) == 0 )
            isUpperRow = true;

        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT: FULL_MATRIX", strlen("EDGE_WEIGHT_FORMAT: FULL_MATRIX")) == 0 )
            isFullMatrix = true;
        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT : FULL_MATRIX", strlen("EDGE_WEIGHT_FORMAT : FULL_MATRIX")) == 0 )
            isFullMatrix = true;

        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT: LOWER_DIAG_ROW", strlen("EDGE_WEIGHT_FORMAT: LOWER_DIAG_ROW")) == 0 )
            isLowerDiagRow = true;
        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT : LOWER_DIAG_ROW", strlen("EDGE_WEIGHT_FORMAT : LOWER_DIAG_ROW")) == 0 )
            isLowerDiagRow = true;

        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT: UPPER_DIAG_ROW", strlen("EDGE_WEIGHT_FORMAT: UPPER_DIAG_ROW")) == 0 )
            isUpperDiagRow = true;
        if (strncmp(lineBuf, "EDGE_WEIGHT_FORMAT : UPPER_DIAG_ROW", strlen("EDGE_WEIGHT_FORMAT : UPPER_DIAG_ROW")) == 0 )
            isUpperDiagRow = true;

        if (strncmp(lineBuf, "NODE_COORD_SECTION", strlen("NODE_COORD_SECTION")) == 0 )
        {
            isCoordinateData = true;
            break;
        }

        if (strncmp(lineBuf, "EDGE_WEIGHT_SECTION", strlen("EDGE_WEIGHT_SECTION")) == 0 )
            break;
    }

    if (dimension == 0)
    {
        std::cout << "Error : no DIMENSION specified" << std::endl;
        exit(1);
    }

    if (capacity == 0)
    {
        std::cout << "Error : no CAPACITY specified" << std::endl;
        exit(1);
    }

    data._depotVehTypePairPts.resize(1, NULL);
    data._customerPts.resize(dimension - 1, NULL);
    int n, d;
    double x, y;
    double x_depot = -1, y_depot = -1;
    std::vector<double> depot_dists;

    if(isCoordinateData)
    {
        while (fgets(lineBuf, 500, f))
        {
            if (sscanf(lineBuf,"%d %lf %lf",&n,&x,&y) == 3)
            {
                if (n == 1)
                {
                    x_depot = x;
                    y_depot = y;
                }
                else if ((n > 0) && (n <= dimension))
                {
                    data._customerPts[n-2] = new Site(n-2, x, y);
                }
            }
            if (strncmp(lineBuf, "DEMAND_SECTION", strlen("DEMAND_SECTION")) == 0 )
                break;
        }
    }
    else
    {
        std::vector<std::vector<double> > distVectors(dimension, std::vector<double>(dimension, 0));

        if(isFullMatrix)
        {
            for (int i = 0; i < dimension; ++i)
            {
                double valueRead;
                for (int j = 0; j < dimension; ++j)
                    if(fscanf(f, "%lf", &valueRead))
                        distVectors[i][j] = valueRead;
            }
        }

        if(isLowerRow)
        {
            for (int i = 0; i < dimension; ++i)
            {
                double valueRead;
                for (int j = 0; j < i; ++j)
                    if(fscanf(f, "%lf", &valueRead))
                        distVectors[i][j] = distVectors[j][i] = valueRead;
            }
        }
        else if(isUpperRow)
        {
            for (int i = 0; i < dimension; ++i)
            {
                double valueRead;
                for (int j = i+1; j < dimension; ++j)
                    if(fscanf(f, "%lf", &valueRead))
                        distVectors[i][j] = distVectors[j][i] = valueRead;
            }
        }
        else if(isLowerDiagRow)
        {
            for (int i = 0; i < dimension; ++i)
            {
                double valueRead;
                for (int j = 0; j <= i; ++j)
                    if(fscanf(f, "%lf", &valueRead))
                        distVectors[i][j] = distVectors[j][i] = valueRead;
            }
        }
        else if(isUpperDiagRow)
        {
            for (int i = 0; i < dimension; ++i)
            {
                double valueRead;
                for (int j = i; j < dimension; ++j)
                    if(fscanf(f, "%lf", &valueRead))
                        distVectors[i][j] = distVectors[j][i] = valueRead;
            }
        }

        for (int i = 0; i < dimension; ++i)
        {
            std::vector<double> dists(distVectors[i].begin()+1, distVectors[i].end());
            if (i == 0)
            {
                depot_dists = dists;
            }
            else
            {
                data._customerPts[i-1] = new Site(i-1, dists);
            }
        }

        while(fgets(lineBuf, 500, f))
        {
            if (strncmp(lineBuf, "DEMAND_SECTION", strlen("DEMAND_SECTION")) == 0 )
            {
                break;
            }
        }
    }

    std::cout << "Number of vertices read : " << dimension << std::endl;

    double totalDemand = 0;
    while (fgets(lineBuf, 500, f))
    {
        if (sscanf(lineBuf,"%d %d",&n,&d) == 2)
        {
            if (n == 1)
                continue;
            if ((n > 0) && (n <= dimension))
            {
                data._customerPts[n-2]->setDemand(d);
                totalDemand += d;

                if (data._maxDemand < d)
                    data._maxDemand = d;
            }
        }
        if (strncmp(lineBuf, "DEPOT_SECTION", strlen("DEPOT_SECTION")) == 0 )
            break;
    }

    int minNumberOfVehicles = (int)std::ceil(totalDemand/capacity);

    int dimvehicle = minNumberOfVehicles;
    if(data._unlimitedFleet)
        dimvehicle = (int)dimension; //dimvehicle *= 2;
    if(isCoordinateData)
    {
        data._depotVehTypePairPts[0]
                = new DepotVehTypePair(0, x_depot, y_depot, 0, dimvehicle, capacity, -1);
    }
    else
    {
        data._depotVehTypePairPts[0]
                = new DepotVehTypePair(0, depot_dists, 0, dimvehicle, capacity, -1);
    }

    fgets(lineBuf, 500, f);
    std::cout << "vehicle created : number = " << dimvehicle << "; capacity = " << capacity << std::endl;

    if (data._depotVehTypePairPts[0] == NULL)
    {
        std::cerr << "Error : depot is not defined" << std::endl;
        exit(1);
    }
    for (int custId = 0; custId < dimension - 1; ++custId)
        if (data._customerPts[custId] == NULL)
        {
            std::cerr << "Error : customer " << custId + 2 << " is not defined" << std::endl;
            exit(1);
        }
        else if (data.getDemand(custId) < 0)
        {
            std::cerr << "Demand of customer " << custId + 2 << " is negative or not defined" << std::endl;
            exit(1);
        }

    fclose(f);

    delete [] lineBuf;

    data._distanceIsExplicit = !isCoordinateData;

    if (!data._instanceHasTimeWindows)
    {
        data.calculateGreatestCommonDivisors();
        data.calculateShortestPathMatrix();
    }

    int nbPartiallyDiscretisedCustomers = 0;
    for (int i = 0; i < (int)data._customerPts.size(); ++i)
    {
        if (data._nbDiffDelQuantities < (data._customerPts[i]->getDemand())/data._greatestCommonDivisor)
        {
            nbPartiallyDiscretisedCustomers += 1;
        }
    }
    std::cout << "A total of " << nbPartiallyDiscretisedCustomers << " out of " << (int)data._customerPts.size()
              << " customers is partially discretised" << std::endl;
    double partiallyDiscretisedPercentage = ((double)nbPartiallyDiscretisedCustomers/(double)data._customerPts.size());
    printf("The percentage of partially discretised customers is %.4f\n", partiallyDiscretisedPercentage*100);

    std::cout << "End of reading." << std::endl;
    return true;
}

bool sdvrp::Loader::loadSDVRPTWFile(const std::string & inputFileName)
{
    int minDemand = 9999;
    int maxDemand = 0;
    int totalDemand = 0;
    std::vector<int> nextDemands;

    std::ifstream ifs(inputFileName.c_str(), std::ios::in);
    if (!ifs) {
        std::cout << "cannot find input file: " << inputFileName << std::endl;
        exit(1);
    }
    if (ifs.eof()) {
        std::cout << "empty input file" << std::endl;
        exit(1);
    }

    std::string line;
    std::getline(ifs, line);

    switch (line.at(0)) {
        case 'r':
        case 'R':
        case 'c':
        case 'C':
            break;
        default:
            return false;
    }
    std::getline(ifs, line);
    std::getline(ifs, line);
    std::getline(ifs, line);
    int maxNbVehicles, capacity;
    ifs >> maxNbVehicles >> capacity;

    if ((maxNbVehicles <= 0) || (capacity <= 0) || ifs.eof() || ifs.bad())
        return false;

    std::getline(ifs, line);
    std::getline(ifs, line);
    std::getline(ifs, line);
    std::getline(ifs, line);

    while (true) {
        int customerId = -1, demand, readyTime, dueDate, serviceTime;
        double xCoord, yCoord;
        ifs >> customerId >> xCoord >> yCoord >> demand >> readyTime >> dueDate >> serviceTime;
        if ((customerId < 0) || ifs.eof() || ifs.bad())
            break;
        if (customerId == 0)
        {
            int minNbVehicles = 0;
            data._depotVehTypePairPts.push_back(new DepotVehTypePair(0, xCoord, yCoord,
                                                                minNbVehicles, maxNbVehicles,
                                                                data._vehicleCapacity, dueDate));
        }
        else
        {
            if (demand < minDemand)
                minDemand = demand;
            if (demand > maxDemand)
                maxDemand = demand;
            totalDemand += demand;
            nextDemands.push_back(demand);

            data._customerPts.push_back(new Site(customerId - 1, xCoord, yCoord, demand, serviceTime,
                                            readyTime, dueDate));
        }
    }
    if (data._depotVehTypePairPts.empty() || data._customerPts.empty())
        return false;

    data.calculateGreatestCommonDivisors();

    std::cout << "SDVRPTW data file detected" << std::endl;

    return true;
}


