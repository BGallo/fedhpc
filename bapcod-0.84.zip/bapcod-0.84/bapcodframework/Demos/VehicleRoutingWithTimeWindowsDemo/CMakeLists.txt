cmake_minimum_required (VERSION 3.12)
project(VehicleRoutingWithTimeWindowsDemo CXX)

# Support both source build and standalone build modes
if(DEFINED ENV{BAPCOD_ROOT} OR DEFINED BAPCOD_ROOT)
    # Standalone mode: Use installed BaPCod
    # Prefer CMake variable over environment variable
    if(DEFINED BAPCOD_ROOT)
        set(BAPCOD_ROOT_PATH ${BAPCOD_ROOT})
    else()
        set(BAPCOD_ROOT_PATH $ENV{BAPCOD_ROOT})
    endif()
    
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake
        ${BAPCOD_ROOT_PATH}/BaPCod/CMake/Packages)
else()
    # Source mode: Use relative paths to BaPCod source
    set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake
        ${CMAKE_CURRENT_SOURCE_DIR}/../../Bapcod/CMake/Packages)
endif()

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH}
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake 
    ${CMAKE_CURRENT_SOURCE_DIR}/CMake/Packages)

# this is needed as the demo uses the VRPSolver extension
find_package(BcpRcsp)

include(BapcodApplicationProject)
include(Documentation)

# Optional: Set other libraries
# we include BcpRcsp library as the demo uses the VRPSolver extension
# Only set these if RCSP was found
if(BcpRcsp_FOUND)
    set(USER_LIBRARIES ${BCP_RCSP_LIBRARY})
    set(USER_INCLUDE_DIR ${BCP_RCSP_INCLUDE_DIR})
else()
    message(WARNING "VehicleRoutingWithTimeWindowsDemo requires RCSP library but it was not found. This demo cannot be built without RCSP. Please install RCSP in Tools/rcsp/ directory.")
endif()


# Execute the build
set_project_version(1 0 0)

# Build Application
try_build_bapcod_application()
