cmake_minimum_required (VERSION 3.12)

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} ${CMAKE_CURRENT_SOURCE_DIR}/CMake $ENV{BAPCOD_ROOT}/CMake/Packages ${CMAKE_CURRENT_SOURCE_DIR}/CMake/Packages ${CMAKE_CURRENT_SOURCE_DIR}/../Tools/lemon-1.3.1/lemon)
#message(CMAKE_MODULE_PATH = ${CMAKE_MODULE_PATH})

# Try to get version from Git tag, fallback to hardcoded default
find_package(Git)
if(GIT_FOUND)
    execute_process(
        COMMAND git describe --tags --abbrev=0
        OUTPUT_VARIABLE GIT_TAG_VERSION
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
        RESULT_VARIABLE GIT_TAG_RESULT
    )
    
    # Get tag date
    if(GIT_TAG_RESULT EQUAL 0)
        execute_process(
            COMMAND git log -1 --format=%cd --date=format:%d/%m/%Y ${GIT_TAG_VERSION}
            OUTPUT_VARIABLE GIT_TAG_DATE
            OUTPUT_STRIP_TRAILING_WHITESPACE
            ERROR_QUIET
        )
        
        # Remove 'v' prefix if present (e.g., v0.83.1 -> 0.83.1)
        string(REGEX REPLACE "^v" "" BAPCOD_VERSION_FROM_GIT "${GIT_TAG_VERSION}")
        set(BAPCOD_VERSION ${BAPCOD_VERSION_FROM_GIT} CACHE INTERNAL "")
        set(BAPCOD_VERSION_DATE ${GIT_TAG_DATE} CACHE INTERNAL "")
        message("-- Version from Git tag: ${BAPCOD_VERSION} (${BAPCOD_VERSION_DATE})")
    else()
        # Fallback to default version if no tag found
        set(BAPCOD_VERSION 0.84 CACHE INTERNAL "")
        set(BAPCOD_VERSION_DATE 10/11/2025 CACHE INTERNAL "")
        message("-- Using default version: ${BAPCOD_VERSION} (no Git tag found)")
    endif()
else()
    # No Git available, use default
    set(BAPCOD_VERSION 0.84 CACHE INTERNAL "")
    set(BAPCOD_VERSION_DATE 10/11/2025 CACHE INTERNAL "")
    message("-- Using default version: ${BAPCOD_VERSION} (Git not found)")
endif()

#Project Name
project(bapcod VERSION ${BAPCOD_VERSION} LANGUAGES CXX)
message("-----------------------")
message("-- Bapcod version: ${BAPCOD_VERSION} (${BAPCOD_VERSION_DATE})")
#Get the current git version and branch name
find_package(Git)
if(GIT_FOUND)
    ##### Check if we are in a git repository
    execute_process(
            COMMAND git rev-parse --is-inside-work-tree
            OUTPUT_VARIABLE is_git_repo
            ERROR_VARIABLE git_error
            OUTPUT_STRIP_TRAILING_WHITESPACE
            RESULT_VARIABLE git_result
    )

    if(git_result EQUAL 0)
        execute_process(
                COMMAND git rev-parse HEAD
                OUTPUT_VARIABLE git_version
                OUTPUT_STRIP_TRAILING_WHITESPACE
        )

        execute_process(
                COMMAND git rev-parse --abbrev-ref HEAD
                OUTPUT_VARIABLE git_branch
                OUTPUT_STRIP_TRAILING_WHITESPACE
        )

        message("-- Current git version Bapcod: ${git_version}")
        message("-- Current git branch: ${git_branch}")

        set(GIT_VERSION_BAPCOD ${git_version} CACHE STRING "Current git version ")
        set(GIT_BRANCH_BAPCOD ${git_branch} CACHE STRING "Current git branch")

        add_compile_definitions(
                GIT_VERSION_BAPCOD="${git_version}"
                GIT_BRANCH_BAPCOD="${git_branch}"
        )

    else()
        set(GIT_VERSION_BAPCOD "unknown" CACHE STRING "Current git version")
        set(GIT_BRANCH_BAPCOD "unknown" CACHE STRING "Current git branch")

        add_compile_definitions(
                GIT_VERSION_BAPCOD="unknown"
                GIT_BRANCH_BAPCOD="unknown"
                DISTRIBUTION_BAPCOD=ON
        )
    endif()
endif()

set(CLANG_LIB_STD OFF CACHE BOOL "clang needs to use libstd")
if(CLANG_LIB_STD)
  message( "CLANG_LIB_STD set to : " ${CLANG_LIB_STD} )
endif()


if (WIN32)
    if(CMAKE_BUILD_TYPE STREQUAL "Debug")
        set(LEMON_LIBRARY "${CMAKE_CURRENT_SOURCE_DIR}/../Tools/lemon-1.3.1/build/lemon/Debug/lemon.lib" CACHE FILEPATH "LEMON library" FORCE )
    endif()   
endif()

include(BapcodProject)
include(Documentation)
include(BapcodTest)

# Build Bapcod
try_build_bapcod()

# Build Documentation
# set(${PROJECT_OUTPUT_NAME}_DOC_EXCLUDE_PATTERNS "*/include_dev/* */include_utils/*")
try_build_documentation()

# Make unit test with cxxTest
try_build_bapcod_test()
