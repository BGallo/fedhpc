/**
 *
 * This file bcGRBSolverC.hpp is a part of BaPCod - a generic Branch-And-Price Code.
 *
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved. 
 * See License.pdf
 * file for license terms.
 * 
 * This file is available only for academic use. 
 * For other uses,
 * please contact stip-bso@inria.fr.
 *
 **/

#ifndef bcGRBInterfaceC_h
#define bcGRBInterfaceC_h

#if _GUROBI_FOUND

#include "bcMathProgSolverInterfaceC.hpp"

/// Include the full path
extern "C"
{
#include "gurobi_c.h"
}
#include <sstream>

class LpGRBInterface : public MathProgSolverInterface
{
 protected:

  GRBenv* env = nullptr;
  GRBmodel* model = nullptr;
  GRBmodel * relaxedModel = nullptr;
  std::vector<int> colStat;
  std::vector<int> rowStat;
  const double grbPrecision = 10e-8;
  int statusMIP = 1;
  bool _isMaster;
  bool _lastSolveIsLp;


 public:


    LpGRBInterface(BapcodInit* bapcodInit, const int & ref, const std::string & name);

    ~LpGRBInterface() override;
    const int & ref() const override
      {
        return _ref;
      }

    void setPresolve(const bool& flag) override;
    void setTimeLimit(const double& seconds) override;
    void setMultiThread(const int& maxNbThread) override;
    void setRelativeMipGapLimit(const double& relativeGap) override;
    void setSearchPriority(const int& flag) override;
    void setWorkingMemorySpace(const double& sizeInMB ) override;
    void setLPoptimalityTolerance(const double& tolerance) override;
    void setLPfeasibilityTolerance(const double& tolerance) override;
    void setScreenOutput(const bool& flag) override;
    void setMaxBBNodes(const int& maxBBNodes) override;

    void loadFormulation(const std::string& name,
      const int& minmaxStatus,
      const int& ncol,
      const int& nrow,
      const std::map < int, std::string >& mapSeqnb2Cname,
      const std::map < int, std::string >& mapSeqnb2Rname,
      const ProbCoefContainer& objectRow,
      ProbColMatrixContainer& colMatrix,
      const ProbRhsContainer& rhsv,
      const ProbBoundContainer& bounds,
      const std::set<ProbType>& types,
      const std::set<ProbIntC>& directs,
      const std::set<ProbSetCoef>& sets) override;

    void unLoadFormulation() override;

    void addCols(const ProbCoefContainer& objectiveRow,
      ProbColMatrixContainer& colMatrix,
      const ProbBoundContainer& bounds,
      const std::map < int, std::string >& mapSeqnb2Cname) override;

    void delCols(const std::set<int>& indexSetOfCol2Delete) override;

    void addRows(const ProbRhsContainer& rhsv,
      const ProbRowMatrixContainer& _rowMatrix,
      const std::map < int, std::string >& mapSeqnb2Rname) override;

    void delRows(const std::set<int>& indexSetOfRow2Delete) override;
    void addDirectives(const std::set<ProbIntC>& varBrDirection) override ;
    void getObjCoef(ProbCoef& pc) override;
    void chgObjCoef(const ProbCoef& pc) override;
    void chgBds(const ProbBoundContainer& newBounds) override;
    void chgMatCoef(const ProbCoef& pc) override;
    void chgRhs(const ProbBound& pb) override;
    void chgRhs(const ProbRhsContainer& newRhs) override;
    void chgColType(const std::set<ProbType>& newTypes) override ;
    void getObjVal(Double& objV) override;
    void getObjValLp(Double& objV) override { getObjVal(objV); } ;
    void getDualBound(Double& val) override;
    void getPrimalBound(Double& val) override;
    bool getOptimStatus(BcSolutionStatus& lpStatus, BcSolutionStatus& mipStatus);
    void getSol(std::map<int, Double>& primSol, const bool& ifPrint = false);
    void getSol(std::map<int, Double>& primSol, std::map<int, Double>& dualSol,
      const int& minmaxStatus, const bool& ifPrint = false);

  void getSolPool(std::vector< std::map<int, Double> >& primSolPool, const bool& ifPrint = false);

  void getReducedCost(std::map<int, Double>& redCost, const bool& ifPrint = false);


  void setLazyConstraintsCallback(MasterConf* mastConfPtr) {}; //TODO
  void removeLazyConstraintsCallback() {} //TODO;
  void resetUpperCutOffValue() override;
  void setUpperCutOffValue(const Double& cutOff) override;
  void setSolveFromScratch(const bool exactSolution = true) { }; //DONE
  void resetSolveFromScratch() {}; //DONE


    void getBasis(std::vector<int>&
      , std::vector<int>& rowStatus) ;
    void setBasis(std::vector<int>& colStatus, std::vector<int>& rowStatus) ;


  // Makes the solver stops once the primal bound computed by the solver becomes equal to the given value)
  void setAbortValue(const Double& abortValue) {};


  void LPwrite(const int& minmaxStatus, std::ostream& os = std::cout) ;
    void MPSwrite(); //DONE
    void printRow(int irow,
      const int& readNcol,
      int* readMclind,
      double* readDmatval,
      char* readCnames); //TODO

 virtual void optimise(const int& minmaxStatus,
      const double& BarrierConvergenceTolerance,
      const double& rightHAndSideZeroTol,
      const double& reducedCostTolerance,
      const bool& preprocessorOn,
      const bool& probingOn,
      const bool& automaticCuttingPlanesOn,
      const char& solverSelection); //DONE

    void optimiseLp(const int& minmaxStatus,
      const double& BarrierConvergenceTolerance,
      const double& rightHAndSideZeroTol,
      const double& reducedCostTolerance,
      const bool& preprocessorOn = true,
      const bool& probingOn = true,
      const bool& automaticCuttingPlanesOn = false,
      const char& solverSelection = 'p')
  {
      LpGRBInterface::optimise(minmaxStatus, BarrierConvergenceTolerance, rightHAndSideZeroTol, reducedCostTolerance,
          preprocessorOn, probingOn, automaticCuttingPlanesOn, solverSelection);
  };

  void reset() ;
    void makeSpaceForLoadingForm();
  void saveCopyOfCurForm() ;
  void load();
  void unload(const bool& deleteMat);
};






class MipGRBInterface : public LpGRBInterface
{
struct LazyCallbackStruct
{
    MasterConf* mastConfPtr;
    int numCols;

    LazyCallbackStruct(MasterConf* mastConfPtr_, int numCols_) :
        mastConfPtr(mastConfPtr_), numCols(numCols_)
    {}
};
protected:
    LazyCallbackStruct _lazyCallbackStruct;
public:

    MipGRBInterface(BapcodInit* bapcodInit, const int& ref, const std::string& name);
    ~MipGRBInterface();

    void loadFormulation(const std::string& name,
        const int& minmaxStatus,
        const int& ncol,
        const int& nrow,
        const std::map < int, std::string >& mapSeqnb2Cname,
        const std::map < int, std::string >& mapSeqnb2Rname,
        const ProbCoefContainer& objectRow,
        ProbColMatrixContainer& colMatrix,
        const ProbRhsContainer& rhsv,
        const ProbBoundContainer& bounds,
        const std::set<ProbType>& types,
        const std::set<ProbIntC>& directs,
        const std::set<ProbSetCoef>& sets);

    // by Ruslan
    void setLazyConstraintsCallback(MasterConf* mastConfPtr);
    void removeLazyConstraintsCallback();
    void resetUpperCutOffValue();
    //void setUpperCutOffValue(const Double& cutOff) override;
    void setSolveFromScratch(const bool exactSolution = true);
    void resetSolveFromScratch();

    void addDirectives(const std::set<ProbIntC>& varBrDirection);
    void chgColType(const std::set<ProbType>& newTypes);
    void getObjVal(Double& objV);
    void getDualBound(Double& val);
    void getPrimalBound(Double& val);
    bool getOptimStatus(BcSolutionStatus &lpStatus, BcSolutionStatus& mipStatus);
    void optimise(const int& minmaxStatus,
        const double& BarrierConvergenceTolerance,
        const double& rightHAndSideZeroTol,
        const double& reducedCostTolerance,
        const bool& preprocessorOn = true,
        const bool& probingOn = true,
        const bool& automaticCuttingPlanesOn = true,
        const char& solverSelection = 'p')  ;

    void optimiseLp(const int& minmaxStatus,
        const double& BarrierConvergenceTolerance,
        const double& rightHAndSideZeroTol,
        const double& reducedCostTolerance,
        const bool& preprocessorOn = true,
        const bool& probingOn = true,
        const bool& automaticCuttingPlanesOn = false,
        const char& solverSelection = 'p');


    void getSol(std::map<int, Double>& primSov, const bool& ifPrint = false);

    void getSolPool(std::vector< std::map<int, Double> >& primSolPool, const bool& ifPrint = false) {};

    //TODO
    void reset();

    // by Aur�lien
    void setAbortValue(const Double& abortValue) {};
};

#endif // _GRB_FOUND
#endif // bcGRBInterfaceC_h
