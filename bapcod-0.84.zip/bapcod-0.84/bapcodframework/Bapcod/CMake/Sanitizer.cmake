option(ENABLE_ADDRESS_SANITIZER "Enable AddressSanitizer" OFF)
option(ENABLE_MEMORY_SANITIZER "Enable MemorySanitizer" OFF)

if(ENABLE_ADDRESS_SANITIZER AND ENABLE_MEMORY_SANITIZER)
    message(FATAL_ERROR "ASan et MSan cannot be enabled at the same time. Please choose one.")
endif()

if(ENABLE_MEMORY_SANITIZER)
    message(STATUS "[Sanitizers] MemorySanitizer enabled")
    find_program(CLANG_CXX_COMPILER clang++)
    if(CLANG_CXX_COMPILER)
        message(STATUS "Clang C++ compiler found: ${CLANG_CXX_COMPILER}")
        set(CMAKE_CXX_COMPILER "${CLANG_CXX_COMPILER}")
    else()
        message(FATAL_ERROR "Clang is required for MemorySanitizer, but it was not found.")
    endif()
endif()

if(ENABLE_ADDRESS_SANITIZER)
    message(STATUS "[Sanitizers] AddressSanitizer enabled")
    if(NOT CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
        message(FATAL_ERROR "AddressSanitizer is only fully supported with Clang and GCC. Current compiler: ${CMAKE_CXX_COMPILER_ID}")
    endif()
endif()

function(enable_sanitizer target_name)
    if(ENABLE_ADDRESS_SANITIZER)
        if (CMAKE_CXX_COMPILER_ID MATCHES "Clang|GNU")
            target_compile_options(${target_name} PRIVATE
                    -fsanitize=address
                    -fno-omit-frame-pointer
                    -g
                    $<$<CONFIG:Release>:-O1>
            )
            target_link_options(${target_name} PRIVATE -fsanitize=address -static-libasan -Wl,--no-as-needed)
            target_compile_definitions(${target_name} PRIVATE ASAN_ENABLED=1)
        endif()
    elseif(ENABLE_MEMORY_SANITIZER)
        if (CMAKE_CXX_COMPILER_ID MATCHES "Clang")
            target_compile_options(${target_name} PRIVATE
                    -fsanitize=memory
                    -fno-omit-frame-pointer
                    -g
                    $<$<CONFIG:Release>:-O1>
            )
            target_link_options(${target_name} PRIVATE -fsanitize=memory -fsanitize-memory-track-origins=2 -static-libsan -Wl,--no-as-needed)
            target_compile_definitions(${target_name} PRIVATE MSAN_ENABLED=1)
        endif()
    endif()
endfunction()