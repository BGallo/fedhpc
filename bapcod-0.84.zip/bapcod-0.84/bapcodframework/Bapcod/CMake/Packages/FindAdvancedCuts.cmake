# try to find installed version

find_path(ADVANCED_CUTS_INCLUDE_DIR
	  NAMES bcModelAdvancedCuts.hpp
	  PATHS "${CMAKE_SOURCE_DIR}/Bapcod/include"
	  )

if (NOT "${ADVANCED_CUTS_INCLUDE_DIR}" STREQUAL "ADVANCED_CUTS_INCLUDE_DIR-NOTFOUND")
    add_definitions(-DUSE_ADVANCED_CUTS)
    message("-- Found optional advanced cuts sources")
endif()
