# - Try to find Cplex 12.8, 12.9, 12.10, 20.0, 20.1, 22.1

# If CPLEX was found in a previous run, re-populate the solver lists and return
if(DEFINED CPLEX_FOUND)
	if(${CPLEX_FOUND})
		if(NOT "${CPLEX_LIBRARY}" STREQUAL "CPLEX_LIBRARY-NOTFOUND" AND NOT "${CPLEX_LIBRARY}" STREQUAL "")
			append_solver_libraries(${CPLEX_LIBRARY})
			append_solver_definitions("-D_CPLEX_FOUND")
		endif()
		if(NOT "${CPLEX_INCLUDE_DIR}" STREQUAL "CPLEX_INCLUDE_DIR-NOTFOUND" AND NOT "${CPLEX_INCLUDE_DIR}" STREQUAL "")
			append_solver_include_dirs(${CPLEX_INCLUDE_DIR})
		endif()
	endif()
	return()
endif()

if("${CPLEX_INCLUDE_DIR}" STREQUAL "" OR "${CPLEX_INCLUDE_DIR}" STREQUAL "CPLEX_INCLUDE_DIR-NOTFOUND")
	include(Solver)

	if(NOT DEFINED ENV{CPLEX_ROOT})
		if(NOT CPLEX_FIND_QUIETLY)
			message(STATUS "CPLEX_ROOT not defined - skipping CPLEX search")
		endif()
		set(CPLEX_INCLUDE_DIR "CPLEX_INCLUDE_DIR-NOTFOUND")
		set(CPLEX_LIBRARY "CPLEX_LIBRARY-NOTFOUND")
		set(CPLEX_FOUND FALSE CACHE BOOL "CPLEX solver was found")
		return()
	endif()

	if(APPLE)
		set(Extension ".dylib")
	elseif(UNIX)
		set(Extension ".so")
	else()
		set(Extension ".lib")
	endif()

	if(EXISTS "$ENV{CPLEX_ROOT}/cplex/include/ilcplex")
		SET(CPLEX_INCLUDE_DIR "$ENV{CPLEX_ROOT}/cplex/include/ilcplex")
	endif()

	if(UNIX OR APPLE)
		if(EXISTS "$ENV{CPLEX_ROOT}/cplex/bin/")
			file(GLOB CPLEX_LIBRARY "$ENV{CPLEX_ROOT}/cplex/bin/*/libcplex*${Extension}")
		endif()
	else()
		if(EXISTS "$ENV{CPLEX_ROOT}/cplex/lib/")
			if(${CMAKE_BUILD_TYPE} STREQUAL "Debug")
				file(GLOB CPLEX_LIBRARY "$ENV{CPLEX_ROOT}/cplex/lib/*/stat_mdd/cplex*${Extension}")
			else()
				file(GLOB CPLEX_LIBRARY "$ENV{CPLEX_ROOT}/cplex/lib/*/stat_mda/cplex*${Extension}")
			endif()
		endif()
	endif ()

	include(FindPackageHandleStandardArgs)
	# This automatically sets CPLEX_FOUND to TRUE or FALSE
	find_package_handle_standard_args(CPLEX DEFAULT_MSG CPLEX_INCLUDE_DIR CPLEX_LIBRARY)
	
	# Cache the result with description (makes it visible in CMake GUI)
	set(CPLEX_FOUND ${CPLEX_FOUND} CACHE BOOL "CPLEX solver was found")
	
	# Cache the library and include directory so they persist across CMake runs
	set(CPLEX_LIBRARY ${CPLEX_LIBRARY} CACHE FILEPATH "CPLEX library path")
	set(CPLEX_INCLUDE_DIR ${CPLEX_INCLUDE_DIR} CACHE PATH "CPLEX include directory")

	mark_as_advanced(CPLEX_LIBRARY CPLEX_INCLUDE_DIR)

	# Populate solver lists when CPLEX is found
	if(CPLEX_FOUND)
		if(NOT "${CPLEX_LIBRARY}" STREQUAL "CPLEX_LIBRARY-NOTFOUND" AND NOT "${CPLEX_LIBRARY}" STREQUAL "")
			append_solver_libraries(${CPLEX_LIBRARY})
			append_solver_definitions("-D_CPLEX_FOUND")
		endif()
		if(NOT "${CPLEX_INCLUDE_DIR}" STREQUAL "CPLEX_INCLUDE_DIR-NOTFOUND" AND NOT "${CPLEX_INCLUDE_DIR}" STREQUAL "")
			append_solver_include_dirs(${CPLEX_INCLUDE_DIR})
		endif()
	endif()
endif()