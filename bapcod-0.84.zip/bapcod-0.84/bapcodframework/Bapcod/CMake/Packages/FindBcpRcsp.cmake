# FindBcpRcsp.cmake - Find RCSP library (optional dependency)
if(DEFINED BcpRcsp_FOUND)
  if(${BcpRcsp_FOUND})
    # If already found, add the definition
    if ((NOT "${BCP_RCSP_INCLUDE_DIR}" STREQUAL "BCP_RCSP_INCLUDE_DIR-NOTFOUND") AND (NOT "${BCP_RCSP_LIBRARY}" STREQUAL "BCP_RCSP_LIBRARY-NOTFOUND"))
      add_definitions(-DBCP_RCSP_IS_FOUND)
    endif()
  endif()
  return()
endif()

# try to find installed version

find_path(BCP_RCSP_INCLUDE_DIR
	  NAMES rcsp_interface.hpp
	  PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/include"
	  PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/build/include"
	  PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/include"
	  PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/include"
	  PATHS "$ENV{RCSP_ROOT}/rcsp/include"
	  PATHS "${RCSP_ROOT}/rcsp/include"
	  PATHS "$ENV{BAPCOD_ROOT}/Tools/rcsp/include"
	  PATHS "${BAPCOD_ROOT}/Tools/rcsp/include"
	  PATHS "/opt/BaPCodFramework/Tools/rcsp/include"
	  )

if(WIN32)
    find_library(BCP_RCSP_LIBRARY
            NAMES rcsp rcspwindows
            PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/lib"
            PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/build/lib"
            PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/lib"
            PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/lib"
            PATHS "$ENV{RCSP_ROOT}/rcsp/lib"
            PATHS "${RCSP_ROOT}/rcsp/lib"
            PATHS "$ENV{BAPCOD_ROOT}/Tools/rcsp/lib"
            PATHS "${BAPCOD_ROOT}/Tools/rcsp/lib"
            PATHS "/opt/BaPCodFramework/Tools/rcsp/lib"
            )
elseif(APPLE)
    if(NOT CMAKE_HOST_SYSTEM_PROCESSOR MATCHES "arm*")
        find_library(BCP_RCSP_LIBRARY
                NAMES rcsp rcspmacos
                PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/lib"
                PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/build/lib"
                PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/lib"
                PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/lib"
                PATHS "$ENV{RCSP_ROOT}/rcsp/lib"
                PATHS "${RCSP_ROOT}/rcsp/lib"
                PATHS "$ENV{BAPCOD_ROOT}/Tools/rcsp/lib"
                PATHS "${BAPCOD_ROOT}/Tools/rcsp/lib"
                PATHS "/opt/BaPCodFramework/Tools/rcsp/lib"
        )
    else()
        find_library(BCP_RCSP_LIBRARY
                NAMES rcsp rcsparm
                PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/lib"
                PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/build/lib"
                PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/lib"
                PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/lib"
                PATHS "$ENV{RCSP_ROOT}/rcsp/lib"
                PATHS "${RCSP_ROOT}/rcsp/lib"
                PATHS "$ENV{BAPCOD_ROOT}/Tools/rcsp/lib"
                PATHS "${BAPCOD_ROOT}/Tools/rcsp/lib"
                PATHS "/opt/BaPCodFramework/Tools/rcsp/lib"
        )
    endif()
elseif(UNIX)
    find_library(BCP_RCSP_LIBRARY
            NAMES rcsp rcsplinux
            PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/lib"
            PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../../Tools/rcsp/build/lib"
            PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/lib"
            PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/lib"
            PATHS "$ENV{RCSP_ROOT}/rcsp/lib"
            PATHS "${RCSP_ROOT}/rcsp/lib"
            PATHS "$ENV{BAPCOD_ROOT}/Tools/rcsp/lib"
            PATHS "${BAPCOD_ROOT}/Tools/rcsp/lib"
            PATHS "/opt/BaPCodFramework/Tools/rcsp/lib"
            )
endif()

if ((NOT "${BCP_RCSP_INCLUDE_DIR}" STREQUAL "BCP_RCSP_INCLUDE_DIR-NOTFOUND")
    AND (NOT "${BCP_RCSP_LIBRARY}" STREQUAL "BCP_RCSP_LIBRARY-NOTFOUND"))
    set(RCSP_VERSION "" CACHE INTERNAL "")
    file(STRINGS "${BCP_RCSP_INCLUDE_DIR}/rcsp_version.hpp" BCP_RCSP_VERSION_LINE REGEX "BCP_RCSP_VERSION \"")
    string(REGEX MATCH "\"[0-9]+\\.[0-9]+\\.[0-9]+\"" BCP_RCSP_VERSION ${BCP_RCSP_VERSION_LINE})
    string(REGEX REPLACE "\"" "" BCP_RCSP_VERSION ${BCP_RCSP_VERSION})
    if (DEFINED BCP_RCSP_MIN_REQUIRED_VERSION AND BCP_RCSP_VERSION)
      if (${BCP_RCSP_VERSION} VERSION_LESS ${BCP_RCSP_MIN_REQUIRED_VERSION})
        message(FATAL_ERROR "RCSP lib version ${BCP_RCSP_VERSION} is lower than min required ${BCP_RCSP_MIN_REQUIRED_VERSION}")
      endif()
    endif()
    message("-- Found optional BCP_RCSP library version ${BCP_RCSP_VERSION}")
    add_definitions(-DBCP_RCSP_IS_FOUND)
    add_definitions(-DGIT_VERSION_RCSP="${GIT_VERSION_RCSP}")
    add_definitions(-DGIT_BRANCH_RCSP="${GIT_BRANCH_RCSP}")
    get_filename_component(BCP_RCSP_LIBRARY_DIRS "${BCP_RCSP_LIBRARY}" PATH)
    
else()
    # use sources ?
    find_path(BCP_RCSP_INCLUDE_DIR
              NAMES rcsp_interface.hpp
              PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../Tools/rcsp/include_dev"
	      PATHS "${CMAKE_CURRENT_SOURCE_DIR}/../Tools/rcsp/build/include_dev"
	      PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/include_dev"
	      PATHS "${CMAKE_SOURCE_DIR}/Tools/rcsp/build/include_dev"
	      )

    if (NOT "${BCP_RCSP_INCLUDE_DIR}" STREQUAL "BCP_RCSP_INCLUDE_DIR-NOTFOUND")
       add_definitions(-DBCP_RCSP_IS_FOUND)
       add_definitions(-DGIT_VERSION_RCSP="${GIT_VERSION_RCSP}")
       add_definitions(-DGIT_BRANCH_RCSP="${GIT_BRANCH_RCSP}")
       set(BCP_RCSP_LIBRARY_DIRS "")
       # Check if the rcsp target exists (should be created by Tools/CMakeLists.txt)
       if(TARGET rcsp)
           set(BCP_RCSP_LIBRARY "rcsp" CACHE INTERNAL "RCSP library target")
           #message("-- Found sources of optional BCP_RCSP library and rcsp target exists")
       else()
           # Target doesn't exist yet, just set to empty and let it be resolved later
           set(BCP_RCSP_LIBRARY "rcsp" CACHE INTERNAL "RCSP library target")
           #message("-- Found sources of optional BCP_RCSP library")
       endif()
     else()
	# not found
    	 set(BCP_RCSP_LIBRARY_DIRS "")
	     set(BCP_RCSP_LIBRARY     "")
	     set(BCP_RCSP_INCLUDE_DIR "")
    endif()
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(BcpRcsp DEFAULT_MSG BCP_RCSP_INCLUDE_DIR BCP_RCSP_LIBRARY)
set(BcpRcsp_FOUND ${BcpRcsp_FOUND} CACHE BOOL "BCP_RCSP solver was found")

mark_as_advanced(BCP_RCSP_INCLUDE_DIR BCP_RCSP_LIBRARY_DIRS BCP_RCSP_LIBRARY) 

#message("BcpRcsp search results : " ${BCP_RCSP_INCLUDE_DIR} " _ " ${BCP_RCSP_LIBRARY} " _ " ${BCP_RCSP_LIBRARY_DIRS})