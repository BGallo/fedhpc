
# - Try to find Gurobi

# If GUROBI was found in a previous run, re-populate the solver lists and return
if(DEFINED GUROBI_FOUND)
  if(${GUROBI_FOUND})
    if(NOT ("${GUROBI_LIBRARY}" STREQUAL "GUROBI_LIBRARY-NOTFOUND") AND NOT ("${GUROBI_LIBRARY}" STREQUAL ""))
      get_filename_component(GUROBI_LIBRARY_DIR "${GUROBI_LIBRARY}" PATH)
      append_solver_libraries(${GUROBI_LIBRARY})
      append_solver_library_dirs(${GUROBI_LIBRARY_DIR})
      append_solver_definitions("-D_GUROBI_FOUND")
    endif()
    if(NOT "${GUROBI_INCLUDE_DIR}" STREQUAL "GUROBI_INCLUDE_DIR-NOTFOUND" AND NOT "${GUROBI_INCLUDE_DIR}" STREQUAL "")
      append_solver_include_dirs(${GUROBI_INCLUDE_DIR})
    endif()
  endif()
  return()
endif()

if("${GUROBI_INCLUDE_DIR}" STREQUAL "" OR "${GUROBI_INCLUDE_DIR}" STREQUAL "GUROBI_INCLUDE_DIR-NOTFOUND")
	include(Solver)

	# Only search if GUROBI_ROOT is defined
	if(NOT DEFINED ENV{GUROBI_ROOT})
		if(NOT GUROBI_FIND_QUIETLY)
			message(STATUS "GUROBI_ROOT not defined - skipping Gurobi search")
		endif()
		set(GUROBI_INCLUDE_DIR "GUROBI_INCLUDE_DIR-NOTFOUND")
		set(GUROBI_LIBRARY "GUROBI_LIBRARY-NOTFOUND")
		set(GUROBI_FOUND FALSE CACHE BOOL "Gurobi solver was found")
		return()
	endif()

	if (WIN32)
		if (CMAKE_CL_64)
			find_path(GUROBI_INCLUDE_DIR gurobi_c.h
				PATHS "$ENV{GUROBI_ROOT}/win64/include"
				NO_DEFAULT_PATH)
		else()
			find_path(GUROBI_INCLUDE_DIR gurobi_c.h
				PATHS "$ENV{GUROBI_ROOT}/win32/include"
				NO_DEFAULT_PATH)
		endif()
	else()
		find_path(GUROBI_INCLUDE_DIR gurobi_c.h
			PATHS "$ENV{GUROBI_ROOT}/mac64/include"
			"$ENV{GUROBI_ROOT}/linux64/include"
			NO_DEFAULT_PATH)
	endif()

	if (WIN32)
		if (CMAKE_CL_64)
			find_library(GUROBI_LIBRARY
				NAMES gurobi120 gurobi110 gurobi100
				PATHS "$ENV{GUROBI_ROOT}/win64/lib"
				NO_DEFAULT_PATH)
		else()
			find_library(GUROBI_LIBRARY
				NAMES gurobi120 gurobi110 gurobi100
				PATHS "$ENV{GUROBI_ROOT}/win32/lib"
				NO_DEFAULT_PATH)
		endif()
	else()
		find_library(GUROBI_LIBRARY
			NAMES gurobi120 gurobi110 gurobi100
			PATHS "$ENV{GUROBI_ROOT}/mac64/lib"
			"$ENV{GUROBI_ROOT}/linux64/lib"
			NO_DEFAULT_PATH)
	endif()

	mark_as_advanced(GUROBI_LIBRARY GUROBI_INCLUDE_DIR GUROBI_LIBRARY_DIR)

	# Cache the library and include directory so they persist across CMake runs
	set(GUROBI_LIBRARY ${GUROBI_LIBRARY} CACHE FILEPATH "Gurobi library path")
	set(GUROBI_INCLUDE_DIR ${GUROBI_INCLUDE_DIR} CACHE PATH "Gurobi include directory")

	# Determine if GUROBI was found and cache the result
	include(FindPackageHandleStandardArgs)
	find_package_handle_standard_args(GUROBI DEFAULT_MSG
			GUROBI_LIBRARY GUROBI_INCLUDE_DIR)

	# Cache the result with description (makes it visible in CMake GUI)
	set(GUROBI_FOUND ${GUROBI_FOUND} CACHE BOOL "Gurobi solver was found")

	# Populate solver lists when GUROBI is found
	if(GUROBI_FOUND)
		if(NOT ("${GUROBI_LIBRARY}" STREQUAL "GUROBI_LIBRARY-NOTFOUND") AND NOT ("${GUROBI_LIBRARY}" STREQUAL ""))
			get_filename_component(GUROBI_LIBRARY_DIR "${GUROBI_LIBRARY}" PATH)
			append_solver_libraries(${GUROBI_LIBRARY})
			append_solver_library_dirs(${GUROBI_LIBRARY_DIR})
			append_solver_definitions("-D_GUROBI_FOUND")
		endif()
		if(NOT "${GUROBI_INCLUDE_DIR}" STREQUAL "GUROBI_INCLUDE_DIR-NOTFOUND" AND NOT "${GUROBI_INCLUDE_DIR}" STREQUAL "")
			append_solver_include_dirs(${GUROBI_INCLUDE_DIR})
		endif()
	endif()

endif()