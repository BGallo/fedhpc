# - Try to find CLP solver
# Avoid running multiple times - check cache variable
if(DEFINED CLP_FOUND)
  if(${CLP_FOUND})
    if (NOT "${CLP_LIBRARY}" STREQUAL "CLP_LIBRARY-NOTFOUND" AND NOT "${COIN_LIBRARY}" STREQUAL "COIN_LIBRARY-NOTFOUND"
            AND  NOT "${COIN_INCLUDE_DIR}" STREQUAL "COIN_INCLUDE_DIR-NOTFOUND"
            AND  NOT "${CLP_INCLUDE_DIR}" STREQUAL "CLP_INCLUDE_DIR-NOTFOUND")
      get_filename_component(CLP_LIBRARY_DIR "${CLP_LIBRARY}" PATH)
      get_filename_component(COIN_LIBRARY_DIR "${COIN_LIBRARY}" PATH)
      append_solver_include_dirs(${CLP_INCLUDE_DIR} ${COIN_INCLUDE_DIR})
      append_solver_libraries( ${OSICLP_LIBRARY} ${CLP_LIBRARY} ${COIN_LIBRARY})
      append_solver_library_dirs(${CLP_LIBRARY_DIR} ${COIN_LIBRARY_DIR})
      append_solver_definitions("-D_CLP_FOUND")
    endif()
  endif()
  return()
endif()

include(Solver)

if(NOT EXISTS $ENV{CLP_ROOT} )
  set(CLP_ROOT $ENV{COINOR_ROOT})
else()
  set(CLP_ROOT $ENV{CLP_ROOT})
endif ()

# Check if CLP_ROOT is defined
if(NOT CLP_ROOT OR CLP_ROOT STREQUAL "")
  if(NOT CLP_FIND_QUIETLY)
    message(STATUS "CLP_ROOT/COINOR_ROOT not defined - skipping CLP search")
  endif()
  set(CLP_FOUND FALSE CACHE BOOL "CLP solver was found")
  return()
endif()

if(MSVC)
  if(${MSVC_TOOLSET_VERSION} EQUAL 143)
    set(CLP_WIN_VERSION "v17")
  elseif(${MSVC_TOOLSET_VERSION} EQUAL 142)
    set(CLP_WIN_VERSION "v16")
  endif()
endif ()

if("${CLP_INCLUDE_DIR}" STREQUAL "" OR "${CLP_INCLUDE_DIR}" STREQUAL "CLP_INCLUDE_DIR-NOTFOUND")

  SET (CLP_FOUND "NOT-FOUND" CACHE STRING "Found CLP Solver" FORCE)

  find_path(CLP_INCLUDE_DIR
          NAMES ClpSolve.hpp
          PATHS "${CLP_ROOT}/include/*"
          PATHS "${CLP_ROOT}/src/")

  find_library(CLP_LIBRARY
          NAMES libClp.lib libClp.a libClp.so libClp.dylib
          PATHS "$ENV{CLP_ROOT}/lib"
          PATHS "C:/Program Files/CoinCLP/MSVisualStudio/${CLP_WIN_VERSION}/x64/${CMAKE_BUILD_TYPE}")

  find_library(OSICLP_LIBRARY
          NAMES libOsiClp.lib libOsiClp.a libOsiClp.so libOsiClp.dylib
          PATHS "$ENV{CLP_ROOT}/lib"
          PATHS "C:/Program Files/CoinCLP/MSVisualStudio/${CLP_WIN_VERSION}/x64/${CMAKE_BUILD_TYPE}")

  find_path(COIN_INCLUDE_DIR
          NAMES CoinPragma.hpp
          PATHS "${CLP_ROOT}/include/*"
          PATHS "C:/Program Files/CoinUtils/src")

  find_library(COIN_LIBRARY
          NAMES libCoinUtils.lib libCoinUtils.a libCoinUtils.so libCoinUtils.dylib
          PATHS "$ENV{CLP_ROOT}/lib"
          PATHS "C:/Program Files/CoinCLP/MSVisualStudio/${CLP_WIN_VERSION}/x64/${CMAKE_BUILD_TYPE}")



  #include(FindPackageHandleStandardArgs)
  #find_package_handle_standard_args(CLP DEFAULT_MSG CLP_LIBRARY CLP_INCLUDE_DIR COIN_LIBRARY COIN_INCLUDE_DIR)

  if (NOT "${CLP_LIBRARY}" STREQUAL "CLP_LIBRARY-NOTFOUND" AND NOT "${COIN_LIBRARY}" STREQUAL "COIN_LIBRARY-NOTFOUND"
          AND  NOT "${COIN_INCLUDE_DIR}" STREQUAL "COIN_INCLUDE_DIR-NOTFOUND"
          AND  NOT "${CLP_INCLUDE_DIR}" STREQUAL "CLP_INCLUDE_DIR-NOTFOUND")
    # Check if found libraries are static (.a or .lib extensions)
    if (CLP_LIBRARY MATCHES "\\.(a|lib)$" AND COIN_LIBRARY MATCHES "\\.(a|lib)$"
            AND (OSICLP_LIBRARY MATCHES "\\.(a|lib)$" OR "${OSICLP_LIBRARY}" STREQUAL "OSICLP_LIBRARY-NOTFOUND"))

      SET (CLP_STATIC_FOUND "FOUND" CACHE STRING "Found CLP Solver" FORCE)
      message(STATUS "Found CLP static libraries")
    else()
        message(STATUS "Found CLP libraries")
    endif()
    message(STATUS "Found CLP library: ${CLP_LIBRARY}")
    message(STATUS "Found COIN library: ${COIN_LIBRARY}")
    message(STATUS "Found OSICLP library: ${OSICLP_LIBRARY}")


  endif()

  mark_as_advanced(CLP_FOUND CLP_INCLUDE_DIR CLP_LIBRARY CLP_LIBRARY_DIR COIN_INCLUDE_DIR COIN_LIBRARY COIN_LIBRARY_DIR)
  
  # Cache the libraries and include directories so they persist across CMake runs
  set(CLP_LIBRARY ${CLP_LIBRARY} CACHE FILEPATH "CLP library path")
  set(CLP_INCLUDE_DIR ${CLP_INCLUDE_DIR} CACHE PATH "CLP include directory")
  set(COIN_LIBRARY ${COIN_LIBRARY} CACHE FILEPATH "COIN library path")
  set(COIN_INCLUDE_DIR ${COIN_INCLUDE_DIR} CACHE PATH "COIN include directory")
  set(OSICLP_LIBRARY ${OSICLP_LIBRARY} CACHE FILEPATH "OSICLP library path")
  
  if (NOT "${CLP_LIBRARY}" STREQUAL "CLP_LIBRARY-NOTFOUND" AND NOT "${COIN_LIBRARY}" STREQUAL "COIN_LIBRARY-NOTFOUND"
          AND  NOT "${COIN_INCLUDE_DIR}" STREQUAL "COIN_INCLUDE_DIR-NOTFOUND"
          AND  NOT "${CLP_INCLUDE_DIR}" STREQUAL "CLP_INCLUDE_DIR-NOTFOUND")
    set(CLP_FOUND TRUE CACHE BOOL "CLP solver was found" FORCE)
    get_filename_component(CLP_LIBRARY_DIR "${CLP_LIBRARY}" PATH)
    get_filename_component(COIN_LIBRARY_DIR "${COIN_LIBRARY}" PATH)
    append_solver_include_dirs(${CLP_INCLUDE_DIR} ${COIN_INCLUDE_DIR})
    append_solver_libraries( ${OSICLP_LIBRARY} ${CLP_LIBRARY} ${COIN_LIBRARY})
    append_solver_library_dirs(${CLP_LIBRARY_DIR} ${COIN_LIBRARY_DIR})
    append_solver_definitions("-D_CLP_FOUND")

  endif()

endif()
