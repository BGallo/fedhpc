/**
 *
 * This file bcGRBSolverC.cpp is a part of BaPCod - a generic Branch-And-Price Code.
 *
 * https://bapcod.math.u-bordeaux.fr
 *
 * Inria Bordeaux, All Rights Reserved. 
 * See License.pdf
 * file for license terms.
 * 
 * This file is available only for academic use. 
 * For other uses,
 * please contact stip-bso@inria.fr.
 *
 **/

#if _GUROBI_FOUND

#include "bcUsefulHeadFil.hpp"
#include "bcDoubleC.hpp"
#include "bcGRBSolverC.hpp"
#include "bcPrintC.hpp"
#include "bcModelC.hpp"
#include "bcMasterConfC.hpp"
#include "bcFormC.hpp"

#include "bcMathProgSolverException.hpp"

/// Fixed length of names given to sub-solvers
const int wordSize = 16;
const char endOfWord = '\0';
const std::string filling = "________________";

/// WordSize + a space for the end of word character
const int placeSize = wordSize + 1;

using namespace std;

LpGRBInterface::LpGRBInterface(BapcodInit *bapcodInit, const int &ref, const std::string &name)
        : MathProgSolverInterface(bapcodInit, ref, name)
{
    _isMaster = name.find("master") != std::string::npos;
    GRBloadenv(&env, NULL);
}

LpGRBInterface::~LpGRBInterface()
{
    GRBfreemodel(model);
    GRBfreemodel(relaxedModel);
    GRBfreeenv(env);
}


void LpGRBInterface::loadFormulation(const std::string& name,
                                     const int& minmaxStatus,
                                     const int& ncol,
                                     const int& nrow,
                                     const std::map < int, std::string >& mapSeqnb2Cname,
                                     const std::map < int, std::string >& mapSeqnb2Rname,
                                     const ProbCoefContainer& objectRow,
                                     ProbColMatrixContainer& colMatrix,
                                     const ProbRhsContainer& rhsv,
                                     const ProbBoundContainer& bounds,
                                     const std::set<ProbType>& types,
                                     const std::set<ProbIntC>& directs,
                                     const std::set<ProbSetCoef>& sets)
{
    _isMaster = name.find("master") != std::string::npos;

    if (printL(3))
        std::cout << "LpGRBInterface::loadFormulation() ncol = " << ncol << " , nrow = " << nrow
                  << std::endl;

    _ncol = ncol;
    _nrow = nrow;

    /// Free space for loading problem
    makeSpaceForLoadingForm();
    /// Assumes sorted colMatrix
    auto *obj = new double[ncol];
    fill_n(obj, ncol, 0);

    for (const auto & oPtr : objectRow)
        obj[oPtr.colRef] = zero(oPtr.coef);

    auto *rhs = new double[nrow];
    fill_n(rhs, nrow, 0);
    auto *rsense = new char[nrow];
    fill_n(rsense, nrow, ' ');
    for (const auto & rvPtr : rhsv)
    {
        rhs[rvPtr.ref] = zero(rvPtr.bound);
        if (rvPtr.sense == 'E')
            rsense[rvPtr.ref] = '=';
        else if (rvPtr.sense == 'L')
            rsense[rvPtr.ref] = '<';
        else if (rvPtr.sense == 'G')
            rsense[rvPtr.ref] = '>';
        else
        {
            printf("ERROR: %s\n", "the sense of constraint should be one of 'E','L' and 'G'");
            exit(0);
        }
    }


    auto *matbeg = new int[ncol + 1];
    fill_n(matbeg, ncol + 1, 0);
    auto *matcnt = new int[ncol + 1];
    fill_n(matcnt, ncol + 1, 0);
    auto nnze = colMatrix.size();
    auto *matind = new int[nnze];
    fill_n(matind, nnze, -1);
    auto *matval = new double[nnze];
    fill_n(matval, nnze, 0);
    int cntNbNz(0);
    auto mPtr = colMatrix.begin();
    int curCol(0);
    for(;curCol<ncol;curCol++)
    {
        matbeg[curCol] = cntNbNz;
        matcnt[curCol] = 0;

        while ((mPtr != colMatrix.end()) && (mPtr->colRef == curCol))
        {
            matind[cntNbNz] = mPtr->rowRef;
            matval[cntNbNz] = zero(mPtr->coef);
            cntNbNz++;
            matcnt[curCol]++;
            mPtr++;
        }
    }

    /// For dummy  element ncol + 1
    matbeg[curCol] = cntNbNz;
    matcnt[curCol] = 0;

    auto *dlb = new double[ncol];
    fill_n(dlb, ncol, 0);
    auto *dub = new double[ncol];
    fill_n(dub, ncol, BapcodInfinity);
    for (const auto & bound : bounds)
    {
        if (bound.sense == 'U')
            dub[bound.ref] = zero(bound.bound);
        else if (bound.sense == 'L')
            dlb[bound.ref] = zero(bound.bound);
        else if (bound.sense == 'F')
        {
            dlb[bound.ref] = zero(bound.bound);
            dub[bound.ref] = dlb[bound.ref];
        }
    }


    auto *vtype = new char[ncol];
    fill_n(vtype, ncol, GRB_CONTINUOUS);


    std::string curName;
    auto *colnamestore = new char[ncol * placeSize];
    fill_n(colnamestore, ncol * placeSize, endOfWord);
    auto **colnames = new char*[ncol];
    fill_n(colnames, ncol, static_cast<char*>(nullptr));
    for(int ic = 0; ic < ncol; ic++)
    {
        auto it = mapSeqnb2Cname.find(ic);
        if(it != mapSeqnb2Cname .end())
            curName = (it->second) + filling;
        else
            curName = filling;
        strncpy(&(colnamestore[ic * placeSize]), curName.c_str(), wordSize);
        colnamestore[(ic +1) * placeSize - 1] = endOfWord;
        colnames[ic]= &(colnamestore[ic*placeSize]);
    }

    auto *rownamestore = new char[nrow * placeSize];
    fill_n(rownamestore, nrow * placeSize, endOfWord);
    char **rownames = new char *[nrow];
    fill_n(rownames, nrow, static_cast<char *>(nullptr));
    for (int ir = 0; ir < nrow; ir++)
    {
        auto it = mapSeqnb2Rname.find(ir);
        if (it != mapSeqnb2Rname .end())
            curName = (it->second) + filling;
        else
            curName = filling;

        strncpy(&(rownamestore[ir * placeSize]), curName.c_str(), wordSize);
        rownamestore[(ir + 1) * placeSize - 1] = endOfWord;
        rownames[ir] = &(rownamestore[ir * placeSize]);
    }

    if (GRBloadmodel(env, &model, "", ncol, nrow, minmaxStatus, 0.0, obj, rsense, rhs, matbeg,
                     matcnt, matind, matval, dlb, dub, vtype, colnames, rownames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBloadmodel(env, &relaxedModel, "", ncol, nrow, minmaxStatus, 0.0, obj, rsense, rhs, matbeg,
                     matcnt, matind, matval, dlb, dub, vtype, colnames, rownames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }



    delete [] obj;
    obj = nullptr;
    delete [] rhs;
    rhs = nullptr;
    delete [] rsense;
    rsense = nullptr;
    delete [] matbeg;
    matbeg = nullptr;
    delete [] matcnt;
    matcnt = nullptr;
    delete [] matind;
    matind = nullptr;
    delete [] matval;
    matval = nullptr;
    delete [] dlb;
    dlb = nullptr;
    delete [] dub;
    dub = nullptr;
    delete [] vtype;
    vtype = nullptr;
    delete [] colnamestore;
    colnamestore = nullptr;
    delete [] colnames;
    colnames = nullptr;
    delete [] rownamestore;
    rownamestore = nullptr;
    delete [] rownames;
    rownames = nullptr;

}

void LpGRBInterface::unLoadFormulation()
{
    _ncol = 0;
    _nrow = 0;
    return;
}



void LpGRBInterface::addCols(const ProbCoefContainer& objectiveRow,
                             ProbColMatrixContainer& colMatrix,
                             const ProbBoundContainer& bounds,
                             const std::map < int, std::string >& mapSeqnb2Cname)
{
    auto newcol = objectiveRow.size();
    if (newcol <= 0) return;

    int readNcol(0);
    if (GRBgetintattr(model, "NumVars", &readNcol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    bapcodInit().require(readNcol == _ncol, "LpGRBInterface::addCols: readNcol != _ncol");

    if (printL(7)) std::cout << "_ncol = " << _ncol << "newcol = " << newcol << std::endl;

    int newnzInCols = colMatrix.size();

    double *eobjx = new double[newcol];
    fill_n(eobjx, newcol, 0);

    for (set<ProbCoef>::const_iterator oPtr = objectiveRow.begin(); oPtr != objectiveRow.end();
         oPtr++)
    {
        if (printL(7))
            std::cout << "eobjx mPtr->colRef  = " << oPtr->colRef
                      << ", oPtr->colRef - _ncol = " << oPtr->colRef - _ncol
                      << ", oPtr->coef= " << oPtr->coef << std::endl;

        eobjx[oPtr->colRef - _ncol] = zero(oPtr->coef);
    }

    int *ematbeg = new int[newcol + 1];
    fill_n(ematbeg, newcol + 1, 0);

    int *ematind = new int[newnzInCols];
    fill_n(ematind, newnzInCols, 0);

    double *ematval = new double[newnzInCols];
    fill_n(ematval, newnzInCols, 0);

    int cnt(0);
    set<ProbCoef, ProbCoefColSmallerThan>::const_iterator mPtr = colMatrix.begin();
    int newColRef(0);
    for (newColRef = 0; newColRef < newcol; newColRef++)
    {
        ematbeg[newColRef] = cnt;

        if (printL(7))
            std::cout << " newColRef = " << newColRef << " cnt = " << cnt
                      << " ematbeg[newColRef] = " << ematbeg[newColRef] << std::endl;

        if (mPtr == colMatrix.end()) continue;

        if (newColRef < (mPtr->colRef - _ncol)) continue;

        if (printL(7))
            std::cout << "ColMatrix = " << *mPtr << " newColRef = " << newColRef
                      << " mPtr->colRef = " << mPtr->colRef << " _ncol = " << _ncol
                      << " newcol = " << newcol
                      << " mPtr->colRef - _ncol = " << mPtr->colRef - _ncol << std::endl;

        while (newColRef == (mPtr->colRef - _ncol))
        {
            ematind[cnt] = mPtr->rowRef;
            ematval[cnt] = zero(mPtr->coef);

            if (printL(7))
                std::cout << " cnt = " << cnt << " ematind[cnt] = " << ematind[cnt]
                          << " ematval[cnt] = " << ematval[cnt] << std::endl;

            cnt++;
            mPtr++;
            if (mPtr == colMatrix.end()) break;
        }
    }

    /// For dummy element newcol + 1
    ematbeg[newColRef] = cnt;

    auto *ebdl = new double[newcol];
    fill_n(ebdl, newcol, 0);

    auto *ebdu = new double[newcol];
    fill_n(ebdu, newcol, BapcodInfinity);

    if (bounds.size() > 0)
    {
        for (const auto & bound : bounds)
        {
            if (bound.sense == 'U')
                ebdu[bound.ref - _ncol] = zero(bound.bound);
            else if (bound.sense == 'L')
                ebdl[bound.ref - _ncol] = zero(bound.bound);
            else if (bound.sense == 'F')
            {
                ebdl[bound.ref - _ncol] = zero(bound.bound);
                ebdu[bound.ref - _ncol] = zero(bound.bound);
            }
        }
    }

    char *vtype = new char[newcol];
    fill_n(vtype, newcol, GRB_CONTINUOUS);

    std::string curName;
    char *colnamestore = new char[newcol * placeSize];
    fill_n(colnamestore, newcol * placeSize, endOfWord);

    char **colnames = new char *[newcol];
    fill_n(colnames, newcol, static_cast<char *>(nullptr));

    for (int ic = 0; ic < newcol; ic++)
    {
        int colRefNb = ic + _ncol;
        auto it = mapSeqnb2Cname.find(colRefNb);

        if (it != mapSeqnb2Cname .end())
            curName = (it->second) + filling;
        else
            curName = filling;

        strncpy(&(colnamestore[ic * placeSize]), curName.c_str(), wordSize);
        colnamestore[(ic + 1) * placeSize - 1] = endOfWord;
        colnames[ic] = &(colnamestore[ic * placeSize]);
    }

    if (GRBaddvars(model, newcol, newnzInCols, ematbeg, ematind, ematval, eobjx, ebdl, ebdu, vtype,
                   colnames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBaddvars(relaxedModel, newcol, newnzInCols, ematbeg, ematind, ematval, eobjx, ebdl, ebdu, vtype,
                   colnames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    delete[] vtype;
    vtype = nullptr;
    delete[] colnamestore;
    colnamestore = nullptr;
    delete[] colnames;
    colnames = nullptr;
    delete[] eobjx;
    eobjx = nullptr;
    delete[] ematbeg;
    ematbeg = nullptr;
    delete[] ematind;
    ematind = nullptr;
    delete[] ematval;
    ematval = nullptr;
    delete[] ebdl;
    ebdl = nullptr;
    delete[] ebdu;
    ebdu = nullptr;
    _ncol += newcol;

}

void LpGRBInterface::delCols(const std::set<int> &indexSetOfCol2Delete)
{
    size_t nbCol2Delete = indexSetOfCol2Delete.size();
    if (nbCol2Delete <= 0) return;

    int readNcol;
    if (GRBgetintattr(model, "NumVars", &readNcol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    bapcodInit().require(readNcol <= _ncol, "LpGRBInterface::delCols: readNcol > _ncol");
    bapcodInit().require(nbCol2Delete <= readNcol,
                         "LpGRBInterface::delCols: nbCol2Delete > readNcol");

    int *dindex = new int[nbCol2Delete];
    fill_n(dindex, nbCol2Delete, -1);

    int cnt(0);
    for (auto& iPtr : indexSetOfCol2Delete)
        dindex[cnt++] = iPtr;

    if (GRBdelvars(model, cnt, dindex))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBdelvars(relaxedModel, cnt, dindex))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    delete[] dindex;
    dindex = nullptr;
    _ncol -= nbCol2Delete;
}


void LpGRBInterface::addRows(const ProbRhsContainer& rhsv,
                             const ProbRowMatrixContainer& _rowMatrix,
                             const std::map < int, std::string >& mapSeqnb2Rname)
{
    int newrows = rhsv.size();
    if (newrows <= 0) return;

    int newnzInNewRows = _rowMatrix.size();
    int readNrow;
    if (GRBgetintattr(model, "NumConstrs", &readNrow))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (printL(7))
        std::cout << "newrows = " << newrows << "  newnzInNewRows = " << newnzInNewRows
                  << "  readNrow = " << readNrow << "  _nrow = " << _nrow << std::endl;

    bapcodInit().require(readNrow == _nrow, "LpGRBInterface::addRows: readNrow != _nrow");

    auto *erhs = new double[newrows];
    fill_n(erhs, newrows, 0);

    auto *esense = new char[newrows];
    fill_n(esense, newrows, ' ');

    for (const auto & rvPtr : rhsv)
    {
        if (printL(7)) std::cout << "rhsv = " << rvPtr;
        erhs[rvPtr.ref - _nrow] = zero(rvPtr.bound);

        if (rvPtr.sense == 'E')
            esense[rvPtr.ref - _nrow] = 'E';
        else if (rvPtr.sense == 'L')
            esense[rvPtr.ref - _nrow] = 'L';
        else if (rvPtr.sense == 'G')
            esense[rvPtr.ref - _nrow] = 'G';
        else
        {
            printf("ERROR: %s\n", "the sense of constraint should be one of 'E','L' and 'G'");
            exit(0);
        }
    }

    auto *ematbeg = new int[newrows + 1];
    fill_n(ematbeg, newrows + 1, 0);

    auto *ematind = new int[newnzInNewRows];
    fill_n(ematind, newnzInNewRows, 0);

    auto *ematval = new double[newnzInNewRows];
    fill_n(ematval, newnzInNewRows, 0);

    int cnt(0);
    auto mPtr = _rowMatrix.begin();
    int newRowRef(0);
    for (newRowRef = 0; newRowRef < newrows; newRowRef++)
    {
        ematbeg[newRowRef] = cnt;
        if (printL(7))
            std::cout << "rowMatrix = " << *mPtr << " newRowRef = " << newRowRef
                      << " mPtr->rowRef - _nrow = " << mPtr->rowRef - _nrow
                      << " ematbeg[newRowRef] = " << ematbeg[newRowRef] << std::endl;

        if (mPtr == _rowMatrix.end()) continue;

        if (newRowRef < (mPtr->rowRef - _nrow)) continue;

        while (newRowRef == (mPtr->rowRef - _nrow))
        {
            ematind[cnt] = mPtr->colRef;
            ematval[cnt] = zero(mPtr->coef);
            if (printL(7))
                std::cout << "rowMatrix = " << *mPtr << " cnt = " << cnt
                          << " ematind[cnt] = " << ematind[cnt]
                          << " ematval[cnt] = " << ematval[cnt] << std::endl;
            cnt++;
            mPtr++;
            if (mPtr == _rowMatrix.end()) break;
        }
    }

    /// For dummy element newrows + 1
    ematbeg[newRowRef] = cnt;

    std::string curName;

    auto *emptyName = new char[newrows * placeSize];
    fill_n(emptyName, newrows * placeSize, endOfWord);

    auto **rownames = new char *[newrows];
    fill_n(rownames, newrows, static_cast<char *>(nullptr));

    for (int ir = 0; ir < newrows; ir++)
    {
        int newRowRef = ir + _nrow;
        // rownames[ir] =  new char[placeSize];
        auto it = mapSeqnb2Rname.find(newRowRef);
        if (it != mapSeqnb2Rname.end())
            curName = (it->second) + filling;
        else
            curName = filling;

        strncpy(&(emptyName[ir * placeSize]), curName.c_str(), wordSize);
        emptyName[(ir + 1) * placeSize - 1] = endOfWord;
        rownames[ir] = &(emptyName[ir * placeSize]);
    }

    if (GRBaddconstrs(model, newrows, newnzInNewRows, ematbeg, ematind, ematval, esense, erhs,
                      rownames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBaddconstrs(relaxedModel, newrows, newnzInNewRows, ematbeg, ematind, ematval, esense, erhs,
                      rownames))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    delete[] rownames;
    rownames = nullptr;
    delete[] emptyName;
    emptyName = nullptr;
    delete[] esense;
    esense = nullptr;
    delete[] erhs;
    erhs = nullptr;
    delete[] ematbeg;
    ematbeg = nullptr;
    delete[] ematind;
    ematind = nullptr;
    delete[] ematval;
    ematval = nullptr;
    _nrow += newrows;

    return;
}

void LpGRBInterface::delRows(const std::set<int> &indexSetOfRow2Delete)
{
    int nbRow2Delete = indexSetOfRow2Delete.size();
    if (nbRow2Delete <= 0) return;

    int readNrow;
    if (GRBgetintattr(model, "NumConstrs", &readNrow))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    bapcodInit().require(readNrow <= _nrow, "LpGRBInterface::delRowss: readNrow > _nrow");
    bapcodInit().require(nbRow2Delete <= readNrow,
                         "LpGRBInterface::delRows: nbRow2Delete > readNrow");

    auto *dindex = new int[nbRow2Delete];
    std::copy(indexSetOfRow2Delete.begin(), indexSetOfRow2Delete.end(), dindex);

    if (GRBdelconstrs(model, nbRow2Delete, dindex))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBdelconstrs(relaxedModel, nbRow2Delete, dindex))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    delete[] dindex;
    dindex = nullptr;
    _nrow -= nbRow2Delete;


}

// OK
void LpGRBInterface::addDirectives(const std::set<ProbIntC> &newDirects)
{
    bapcodInit().check(1, "LP can not have directives");

}

void LpGRBInterface::getObjCoef(ProbCoef &pc)
{
    double *coef = new double[1];

    if (GRBgetdblattrelement(model, "Obj", pc.colRef, coef))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    pc.coef = *coef;
    delete[] coef;

}

void LpGRBInterface::chgObjCoef(const ProbCoef &pc)
{
    if (GRBsetdblattrelement(model, "Obj", pc.colRef, pc.coef) ||
        GRBsetdblattrelement(relaxedModel, "Obj", pc.colRef, pc.coef))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model) ||
        GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::chgMatCoef(const ProbCoef &pc)
{
    int *cind = new int[1];
    int *vind = new int[1];
    double *val = new double[1];
    cind[0] = pc.rowRef;
    vind[0] = pc.colRef;
    val[0] = double(pc.coef);

    if (GRBchgcoeffs(model, 1, cind, vind, val) ||
        GRBchgcoeffs(relaxedModel, 1, cind, vind, val))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model) || GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::chgRhs(const ProbBound &pb)
{
    if (GRBsetdblattrelement(model, "RHS", pb.ref, zero(pb.bound)) ||
        GRBsetdblattrelement(relaxedModel, "RHS", pb.ref, zero(pb.bound)))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model) ||
        GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::chgRhs(const std::set<ProbBound> &newRhs)
{
    if (newRhs.empty()) return;
    int nrhs(0);
    int *index = new int[newRhs.size()];
    fill_n(index, newRhs.size(), -1);

    double *rhs = new double[newRhs.size()];
    fill_n(rhs, newRhs.size(), 0);

    for (set<ProbBound>::const_iterator bPtr = newRhs.begin(); bPtr != newRhs.end(); bPtr++)
    {
        index[nrhs] = bPtr->ref;
        rhs[nrhs] = zero(bPtr->bound);
        nrhs++;
    }

    if (GRBsetdblattrlist(model, "RHS", nrhs, index, rhs) ||
        GRBsetdblattrlist(relaxedModel, "RHS", nrhs, index, rhs))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBupdatemodel(model) ||
        GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    delete[] index;
    index = nullptr;
    delete[] rhs;
    rhs = nullptr;
    return;
}

void LpGRBInterface::chgBds(const std::set<ProbBound> &newBounds)
{
    for (const auto & newBound : newBounds)
    {
        if (newBound.sense == 'L')
        {
            GRBsetdblattrelement(model, "LB", newBound.ref, zero(newBound.bound));
            GRBsetdblattrelement(relaxedModel, "LB", newBound.ref, zero(newBound.bound));
        }
        else if ((newBound.sense == 'U') || (newBound.sense == 'I') || (newBound.sense == 'B'))
        {
            GRBsetdblattrelement(model, "UB", newBound.ref, zero(newBound.bound));
            GRBsetdblattrelement(relaxedModel, "UB", newBound.ref, zero(newBound.bound));
        }
        else if (newBound.sense == 'F')
        {
            GRBsetdblattrelement(model, "LB", newBound.ref, zero(newBound.bound));
            GRBsetdblattrelement(model, "UB", newBound.ref, zero(newBound.bound));
            GRBsetdblattrelement(relaxedModel, "LB", newBound.ref, zero(newBound.bound));
            GRBsetdblattrelement(relaxedModel, "UB", newBound.ref, zero(newBound.bound));
        }
    }

    if (GRBupdatemodel(model) || GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::chgColType(const std::set<ProbType> &newTypes)
{
    bapcodInit().check(1, "LP Form cannot have ColType");

}

void LpGRBInterface::getObjVal(Double &objV)
{
    double objVal;
    if (GRBgetdblattr(model, "ObjVal", &objVal))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    objV = zero(objVal, grbPrecision);

}

void LpGRBInterface::getDualBound(Double &val)
{
    int nrow{ 0 };
    if (GRBgetintattr(relaxedModel, "NumConstrs", &nrow))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    int ncol{ 0 };
    if (GRBgetintattr(relaxedModel, "NumVars", &ncol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    auto* reducedcost = new double[ncol];
    fill_n(reducedcost, ncol, 0);
    for (size_t i = 0; i < ncol; i++)
        bapcodInit().check(GRBgetdblattrelement(relaxedModel, "RC", i, &reducedcost[i]), " could not get reduced cost");


    auto * x = new double[ncol];
    if (GRBgetdblattrarray(relaxedModel, "X", 0, ncol, x))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    auto * dualsol = new double[nrow];
    if(GRBgetdblattrarray(relaxedModel, "Pi", 0, nrow, dualsol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    double *rhs = new double[nrow];
    if (GRBgetdblattrarray(relaxedModel, "RHS", 0, nrow, rhs))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    double dualval = 0.0;

    for (int i = 0; i < ncol; i++)
        dualval += x[i] * reducedcost[i];

    for (int i = 0; i < nrow; i++)
        dualval += dualsol[i] * rhs[i];

    val = zero(dualval, grbPrecision);

    delete[] rhs;
    delete[] dualsol;
    delete[] x;
    delete[] reducedcost;
    rhs = nullptr;
    dualsol = nullptr;
    x = nullptr;
    reducedcost = nullptr;

}

void LpGRBInterface::getPrimalBound(Double &val)
{
    double primalVal = 0.0;
    if (GRBgetdblattr(model, "ObjVal", &primalVal))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    val = zero(primalVal, grbPrecision);

}

bool LpGRBInterface::getOptimStatus(BcSolutionStatus &lpStatus, BcSolutionStatus &mipStatus)
{

    int status;

    if(_lastSolveIsLp)
        if (GRBgetintattr(relaxedModel, "Status", &status))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
        else
        if (GRBgetintattr(model, "Status", &status))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    if (status == GRB_OPTIMAL)

    {
        lpStatus = BcSolutionStatus::Optimum;
        mipStatus = BcSolutionStatus::Optimum;

        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: LP optimal"
                      << std::endl;

        return (true);
    }

    if (printL(4)) MPSwrite();

    if (status == GRB_INFEASIBLE)
    {
        lpStatus = BcSolutionStatus::Infeasible;
        mipStatus = BcSolutionStatus::Infeasible;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: LP infeasible"
                      << std::endl;

        return false;
    }

    if (status == GRB_UNBOUNDED)
    {
        lpStatus = BcSolutionStatus::Unbounded;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: LP unbounded" << std::endl;

        return false;
    }

    if (status == GRB_INF_OR_UNBD)
    {
        lpStatus = BcSolutionStatus::Unbounded;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: Model was proven to be either infeasible "
                         "or unbounded"
                      << std::endl;

        return false;
    }

    if (status == GRB_LOADED)
    {
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: Model is loaded, but no solution "
                         "information is available"
                      << std::endl;

        return false;
    }

    if (status == GRB_ITERATION_LIMIT)
    {
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: the total number of simplex iterations "
                         "performed exceeded"
                      << std::endl;

        return false;
    }

    if (status == GRB_TIME_LIMIT)
    {
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: the time expended exceeded" << std::endl;

        return false;
    }

    if (status == GRB_INTERRUPTED)
    {
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: Optimization was terminated by the user"
                      << std::endl;

        return false;
    }

    if (status == GRB_NUMERIC)
    {
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "LpGRBInterface::getOptimStatus: Optimization was terminated due to "
                         "unrecoverable numerical difficulties"
                      << std::endl;

        return false;
    }

    std::cout << "LpGRBInterface::getOptimStatus: undefined status" << std::endl;

    return false;
}

void LpGRBInterface::getSol(std::map<int, Double> &primSol, const bool &ifPrint)
{
    primSol.clear();
    int readNcol = 0;
    if (GRBgetintattr( _lastSolveIsLp ? relaxedModel : model, "NumVars", &readNcol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    bapcodInit().require(readNcol <= _ncol, "LpGRBInterface::getSol: readNcol > _ncol");

    auto *x = new double[_ncol];
    fill_n(x, _ncol, 0);

    if (GRBgetdblattrarray(_lastSolveIsLp ? relaxedModel : model, "X", 0, _ncol, x))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (printL(6)) std::cout << "readNcol = " << readNcol << "  _ncol = " << _ncol << std::endl;

    for (size_t jcol = 0; jcol < _ncol; jcol++)
        if (zero(x[jcol], grbPrecision) != 0)
        {
            if (printL(6)) std::cout << "primSol[" << jcol << "] = " << x[jcol] << std::endl;
            primSol[jcol] = x[jcol];
        }

    delete[] x;
    x = nullptr;
}

void LpGRBInterface::getSol(std::map<int, Double> &primSol, std::map<int, Double> &dualSol,
                            const int &minmaxStatus, const bool &ifPrint)
{
    getSol(primSol, ifPrint);
    dualSol.clear();
    int readNrow(0);
    if (GRBgetintattr(_lastSolveIsLp ? relaxedModel : model, "NumConstrs", &readNrow))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    bapcodInit().require(readNrow <= _nrow, "LpGRBInterface::getSol: readNrow > _nrow");

    int flipsign = -1;
    auto *dual = new double[_nrow];
    fill_n(dual, _nrow, 0);

    auto *rsense = new char[_nrow];
    fill_n(rsense, _nrow, ' ');

    if (GRBgetdblattrarray(relaxedModel, "Pi", 0, _nrow, dual))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBgetcharattrarray(relaxedModel, "Sense", 0, _nrow, rsense))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    for (int irow = 0; irow < _nrow; irow++)
        if (zero(dual[irow], grbPrecision) != 0)
        {
            if (rsense[irow] == '<')
                dualSol[irow] = minmaxStatus * flipsign * dual[irow];
            else if (rsense[irow] == '>')
                dualSol[irow] = minmaxStatus * flipsign * dual[irow];
            else
                ///@internal == 'E'
                dualSol[irow] = flipsign * dual[irow];

            if (printL(6))
            {
                std::cout << "dual[" << irow << "] = " << dual[irow] << std::endl;

                std::cout << " dualSol[" << irow << "] = " << dualSol[irow] << std::endl;
            }
        }

    delete[] dual;
    dual = nullptr;
    delete[] rsense;
    rsense = nullptr;


}

void LpGRBInterface::getSolPool(std::vector<std::map<int, Double>>& primSolPool, const bool& ifPrint)
{
}

void LpGRBInterface::getReducedCost(std::map<int, Double> & redCost,
                                    const bool & ifPrint)
{

    redCost.clear();
    int readNcol = 0;
    if (GRBgetintattr(relaxedModel, "NumVars", &readNcol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


    bapcodInit().require(readNcol <= _ncol, "LpGRBInterface::getSol: readNcol > _ncol");

    cout << readNcol << " " << _ncol;

    auto* dj = new double[_ncol];
    fill_n(dj, _ncol, 0);
    for(size_t i=0;i< readNcol;i++)
        bapcodInit().check(GRBgetdblattrelement(relaxedModel,"RC",i,&dj[i]), " could not get reduced cost");

    if (printL(6))
        std::cout << "readNcol = " << readNcol << "  _ncol = " << _ncol << std::endl;

    for (size_t jcol = 0; jcol < _ncol; jcol++)
        if (zero(dj[jcol], grbPrecision) != 0)
        {
            if (printL(6))
                std::cout << "redCost[" << jcol << "] = " << dj[jcol] << std::endl;
            redCost[jcol] = dj[jcol];
        }

    delete[] dj;
    dj = nullptr;


}

void LpGRBInterface::resetUpperCutOffValue()
{

    if (GRBsetdblparam(env, "CutOff", 1e+75))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }
}

void LpGRBInterface::getBasis(std::vector<int> &colStatus, std::vector<int> &rowStatus)
{
    // GRB
    // variable status
    // 0 (basic), -1 (non-basic at lower bound), -2 (non-basic at upper bound), and -3 (super-basic)
    // constraint status
    // 0 (basic) or -1 (non-basic), A constraint is basic when its slack variable is in the simplex
    // basis
    if (_isMaster)
    {
        int readNrow(0);
        int readNcol(0);
// You can also set parameters on the model
        auto error = GRBsetdblparam(GRBgetenv(relaxedModel), "IterationLimit", 1);
        if (GRBupdatemodel(relaxedModel))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
        if (GRBoptimize(relaxedModel))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }

        GRBgetintattr(relaxedModel , "NumConstrs", &readNrow);
        GRBgetintattr(relaxedModel, "NumVars", &readNcol);

        colStatus.resize(readNcol);
        rowStatus.resize(readNrow);

        int vbasis;
        int cbasis;

        for (int i = 0; i < readNcol; i++)
        {
            if (GRBgetintattrelement(relaxedModel, "VBasis", i, &vbasis))
            {
                continue;
            }
            if (vbasis == 0)
                colStatus[i] = 1;
            else if (vbasis == -1)
                colStatus[i] = 0;
            else if (vbasis == -2)
                colStatus[i] = 2;
            else if (vbasis == -3)
                colStatus[i] = 3;
        }

        for (int i = 0; i < readNrow; i++)
        {
            if (GRBgetintattrelement(relaxedModel, "CBasis", i, &cbasis))
            {
                continue;
            }
            if (cbasis == 0)
                rowStatus[i] = 1;
            else if (cbasis == -1)
                rowStatus[i] = 0;
            else if (cbasis == -2)
                rowStatus[i] = 0;
        }
    }


    auto error = GRBsetdblparam(GRBgetenv(relaxedModel), "IterationLimit", BapcodInfinity);
    if (GRBupdatemodel(model) || GRBupdatemodel(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }
    return;
}


void LpGRBInterface::setBasis(std::vector<int> & colStatus, std::vector<int> & rowStatus)
{
    int readNrow(0);
    int readNcol(0);

    if (GRBgetintattr(relaxedModel, "NumConstrs", &readNrow))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBgetintattr(relaxedModel, "NumVars", &readNcol))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    for (int ic = 0; ic < readNcol; ic++)
    {
        if (colStatus[ic] == 0) {
            if (GRBsetintattrelement(relaxedModel, "VBasis", ic, -1)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
        else if (colStatus[ic] == 1) {
            if (GRBsetintattrelement(relaxedModel, "VBasis", ic, 0)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
        else if (colStatus[ic] == 2) {
            if (GRBsetintattrelement(relaxedModel, "VBasis", ic, -2)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
        else if (colStatus[ic] == 3) {
            if (GRBsetintattrelement(relaxedModel, "VBasis", ic, -3)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
    }

    for (int ir = 0; ir < readNrow; ir++)
    {
        if (rowStatus[ir] == 0) {
            if (GRBsetintattrelement(relaxedModel, "CBasis", ir, -1)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
        else if (rowStatus[ir] == 1) {
            if (GRBsetintattrelement(relaxedModel, "CBasis", ir, 0)) {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
        else if (rowStatus[ir] == 2){
            if (GRBsetintattrelement(relaxedModel, "CBasis", ir, -1))
            {
                printf("ERROR: %s\n", GRBgeterrormsg(env));
                exit(0);
            }
        }
    }


}

void LpGRBInterface::LPwrite(const int&minmaxStatus, std::ostream &os)
{
    int nRow, nCol, nchar;
    GRBgetintattr(model, "NumVars", &nCol);
    GRBgetintattr(model, "NumConstrs", &nRow);

    char* probName;//, str; //Commented by Romain: variable not used.
    auto* obj = new double[nCol];
    auto* colLower = new double[nCol];
    auto* colUpper = new double[nCol];
    double* rhs = new double[nRow];
    char* sense = new char[nRow];
    char** colNames = new char* [nCol];
    char** rowNames = new char* [nRow];


    GRBgetstrattr(model, "ModelName", &probName);
    GRBgetdblattrarray(model, "Obj", 0, nCol, obj);
    GRBgetdblattrarray(model, "LB", 0, nCol, colLower);
    GRBgetdblattrarray(model, "UB", 0, nCol, colUpper);
    GRBgetdblattrarray(model, "RHS", 0, nRow, rhs);
    GRBgetcharattrarray(model, "Sense", 0, nRow, sense);

    if (param().MipSolverRecordNamesInFormulation)
    {
        GRBgetstrattrarray(model, "VarName", 0, nCol, colNames);
        GRBgetstrattrarray(model, "ConstrName", 0, nRow, rowNames);
    }

    os << "PROBLEM: " << probName << " whose formulation ref number is " << ref() << endl;

    if (minmaxStatus == 1) os << "Minimize" << endl;
    else os << "Maximize" << endl;

    nchar = printf(" Objective:");
    for (int ic = 0; ic < nCol; ic++)
    {
        if (Double(obj[ic]) != 0)
        {
            string s = colNames[ic];
            nchar += printf(" %+.9g %s", obj[ic], s.c_str());
            if (nchar >= 80 - 9 - 13)
            {
                printf("\n");
                nchar = 0;
            }
        }
    }

    os << endl << "Subject To" << endl;

    for (int ir = 0; ir < nRow; ir++)
    {
        nchar = printf(" %s:", rowNames[ir]);
        for (int ic = 0; ic < nCol; ic++)
        {
            double coef;
            GRBgetcoeff(model, ir, ic, &coef);

            if (Double(coef) != 0)
            {
                nchar += printf(" %+.9g %s", coef, colNames[ic]);
                if (nchar >= 80 - 9 - 13)
                {
                    printf("\n");
                    nchar = 0;
                }
            }
        }
        if (sense[ir] == '=')
            printf(" %s %.9g", "=", rhs[ir]);
        else if (sense[ir] == '>')
            printf(" %s %.9g", ">=", rhs[ir]);
        else
            printf(" %s %.9g", "<=", rhs[ir]);

        os << endl;
    }

    os << "Bounds" << endl;

    for (int ic = 0; ic < nCol; ic++)
    {
        os << " " << colLower[ic] << " <= " << colNames[ic] << " <= " << colUpper[ic] << endl;
    }

    if (_pureLP)
        os << "END" << endl;

}

void LpGRBInterface::MPSwrite()
{
    if (GRBwrite(model, "curprob.lp"))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (GRBwrite(model, "curprob.mps"))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

}

void LpGRBInterface::printRow(int irow, const int &readNcol, int *readMclind, double *readDmatval,
                              char *readCnames)
{}


void LpGRBInterface::optimise(const int& minmaxStatus,
                              const double& BarrierConvergenceTolerance,
                              const double& rightHAndSideZeroTol,
                              const double& reducedCostTolerance,
                              const bool& preprocessorOn = true,
                              const bool& probingOn = true,
                              const bool& automaticCuttingPlanesOn = false,
                              const char& solverSelection = 'p')
{
    _lastSolveIsLp = true;
    bapcodInit().require(_formCurrentlyLoaded, "Form not Currently Loaded",
                         ProgStatus::quit,
                         3);
    if (printL(8)) {

        MPSwrite();
    }


    bapcodInit().check(GRBsetdblparam(GRBgetenv(relaxedModel), "FeasibilityTol", rightHAndSideZeroTol),
                       "Failure to turn on rightHAndSideZeroTol ");

    if (printL(1))
        std::cout << "LpGRBInterface::optimise setting param reducedCostTolerance to " << reducedCostTolerance
                  << std::endl;

    bapcodInit().check(GRBsetdblparam(GRBgetenv(relaxedModel), "OptimalityTol", reducedCostTolerance),
                       "Failure to turn on reducedCostTolerance ");

    if (preprocessorOn)
        bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Presolve", 1),
                           "Failure to turn on presolve ");
    else
        bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Presolve", 0),
                           "Failure to turn off presolve ");


    switch (solverSelection)
    {
        case 'p':
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", 0), //Primal
                               "Failure to change the LP method");
            break;
        case 'd':
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", 1), //Dual
                               "Failure to change the LP method");
            break;
        case 'n':
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", -1), //Quadratic put to automatic
                               "Failure to change the LP method");
            break;
        case 'b':
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", 2),
                               "Failure to change the LP method to Barrier");

            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Crossover", 0),
                               "Failure to turn off cross-over");

            break;
        case 'c':
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", 2),
                               "Failure to change the LP method");
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Crossover", -1),
                               "Failure to change crossover mode in LP method");
            break;
        case 'a':
        default:
            bapcodInit().check(GRBsetintparam(GRBgetenv(relaxedModel), "Method", 1), // By default dual simplex to get basis
                               "Failure to change the LP method");
            break;
    }

    GRBsetdblattr(relaxedModel, "SAObjLow", -1e+75);
    GRBsetdblattr(relaxedModel, "SAObjUp", 1e+75);

   GRBupdatemodel(relaxedModel);
    if (GRBoptimize(relaxedModel))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

}


void LpGRBInterface::makeSpaceForLoadingForm()
{
    _formCurrentlyLoaded = true;
    if (printL(6)) std::cout << " _formCurrentlyLoaded = " << _formCurrentlyLoaded << std::endl;
    return;
}

void LpGRBInterface::saveCopyOfCurForm()
{
    /// Save loaded form if any
    if (printL(6))
        std::cout << "LpGRBInterface::saveCopyOfCurForm(): formCurrentlyLoaded = "
                  << _formCurrentlyLoaded << std::endl;
}

void LpGRBInterface::load()
{
    if (printL(6))
        std::cout << "LpGRBInterface::load(): formCurrentlyLoaded = " << _formCurrentlyLoaded
                  << std::endl;
}

void LpGRBInterface::unload(const bool &deleteMat)
{

}

void LpGRBInterface::reset()
{}




void LpGRBInterface::setScreenOutput(const bool& flag)
{
    if (flag)
    {
        if (GRBsetintparam(env, "OutputFlag", 1))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }


    }
    else
    {
        if (GRBsetintparam(env, "OutputFlag", 0))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }


    }
}



void LpGRBInterface::setPresolve(const bool &flag)
{
    // Controls the presolve level.
    // A value of -1 corresponds to an automatic setting.
    // Other options are off (0), conservative (1), or aggressive (2).
    if (flag)
    {
        if (GRBsetintparam(env, "Presolve", -1))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    }
    else
    {
        if (GRBsetintparam(env, "Presolve", 0))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    }


}

void LpGRBInterface::setLPoptimalityTolerance(const double& tolerance)
{
    if(GRBsetdblparam(env, "OptimalityTol", tolerance))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }



}

void LpGRBInterface::setLPfeasibilityTolerance(const double& tolerance)
{

    if(GRBsetdblparam(env, "FeasibilityTol", tolerance))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::setMaxBBNodes(const int& maxBBNodes)
{
    if (GRBsetdblparam(env, "NodeLimit", maxBBNodes))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }



}



void LpGRBInterface::setTimeLimit(const double &seconds)
{
    if (GRBsetdblparam(env, "TimeLimit", seconds))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::setMultiThread(const int &maxNbThread)
{
    if (GRBsetintparam(env, "Threads", maxNbThread))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::setRelativeMipGapLimit(const double &relativeGap)
{
    if (GRBsetdblparam(env, "MIPGap", relativeGap))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

void LpGRBInterface::setSearchPriority(const int &flag)
{
    switch (flag)
    {
        case 0:
        {
            // default, balanced
            GRBsetintparam(env, "MIPFocus", 0);
            break;
        }
        case 1:
        {
            // If you are more interested in finding feasible solution quickly
            GRBsetintparam(env, "MIPFocus", 1);
            break;
        }
        case 2:
        {
            // if you wish to focus more attention on proving optimality
            GRBsetintparam(env, "MIPFocus", 2);
            break;
        }
        case 3:
        {
            // If the best objective bound is moving very slowly, try to focus on the bound
            GRBsetintparam(env, "MIPFocus", 3);
            break;
        }
        case 4:
        {
            throw MathProgSolverException("failure to set mipemphasis indicator 4", true);
            break;
        }
    }


}

void LpGRBInterface::setWorkingMemorySpace(const double &sizeInMB)
{
    // measured in GBytes
    if (GRBsetdblparam(env, "NodefileStart", sizeInMB / 1000))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}


// ************************************
// ***** Class MipGRBInterface ******
// ************************************


MipGRBInterface::MipGRBInterface(BapcodInit* bapcodInit, const int& ref, const std::string& name)
        : LpGRBInterface(bapcodInit, ref, name), _lazyCallbackStruct(nullptr, 0)
{
    _pureLP = false;
    _isMaster = name.find("master") != std::string::npos;
    if (printL(1))
    {
        int major, minor, technical;
        GRBversion(&major, &minor, &technical);
        printf("Gurobi library version %d.%d.%d\n", major, minor, technical);

        if (GRBsetintparam(env, "LogToConsole", 1))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    }
    else if (GRBsetintparam(env, "LogToConsole", 0))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


}

MipGRBInterface::~MipGRBInterface()
{

}

void MipGRBInterface::loadFormulation(const std::string& name,
                                      const int& minmaxStatus,
                                      const int& ncol,
                                      const int& nrow,
                                      const std::map<int, std::string>& mapSeqnb2Cname,
                                      const std::map<int, std::string>& mapSeqnb2Rname,
                                      const ProbCoefContainer& objectRow,
                                      ProbColMatrixContainer& colMatrix,
                                      const ProbRhsContainer& rhsv,
                                      const ProbBoundContainer& bounds,
                                      const std::set<ProbType>& types,
                                      const std::set<ProbIntC>& directs,
                                      const std::set<ProbSetCoef>& sets) {
    if (printL(5))
        std::cout << "MipGRBInterface::loadFormulation() ncol = " << ncol << " , nrow = " << nrow
                  << std::endl;

    _isMaster = name.find("master") != std::string::npos;

    _ncol = ncol;
    _nrow = nrow;

    /// Free space for loading problem
    makeSpaceForLoadingForm();
    _pureLP = false;

    /// Assumes sorted colMatrix
#if defined(PROBMATRIXCONTAINERVECTOR) || defined(PROBMATRIXCONTAINERDEQUE)
    std::sort(colMatrix.begin(), colMatrix.end());
#endif

    double *obj = new double[ncol];
    fill_n(obj, ncol, 0);
    for (ProbCoefContainer::const_iterator oPtr = objectRow.begin();
         oPtr != objectRow.end(); oPtr++)
        obj[oPtr->colRef] = zero(oPtr->coef);

    double *rhs = new double[nrow];
    fill_n(rhs, nrow, 0);
    char *rsense = new char[nrow];
    fill_n(rsense, nrow, ' ');

    for (ProbRhsContainer::const_iterator rvPtr = rhsv.begin(); rvPtr != rhsv.end(); rvPtr++) {
        rhs[rvPtr->ref] = zero(rvPtr->bound);
        if (rvPtr->sense == 'E')
            rsense[rvPtr->ref] = '=';
        else if (rvPtr->sense == 'L')
            rsense[rvPtr->ref] = '<';
        else if (rvPtr->sense == 'G')
            rsense[rvPtr->ref] = '>';
        else {
            printf("ERROR: %s\n", "the sense of constraint should be one of 'E','L' and 'G'");
            exit(0);
        }
    }

    int *matbeg = new int[ncol + 1];
    fill_n(matbeg, ncol + 1, 0);
    int *matcnt = new int[ncol + 1];
    fill_n(matcnt, ncol + 1, 0);
    int nnze = colMatrix.size();
    int *matind = new int[nnze];
    fill_n(matind, nnze, -1);
    double *matval = new double[nnze];
    fill_n(matval, nnze, 0);

    int cntNbNz(0);
    ProbColMatrixContainer::const_iterator mPtr = colMatrix.begin();
    int curCol(0);
    for (; curCol < ncol; curCol++) {
        matbeg[curCol] = cntNbNz;
        matcnt[curCol] = 0;

        while ((mPtr != colMatrix.end()) && (mPtr->colRef == curCol)) {
            matind[cntNbNz] = mPtr->rowRef;
            matval[cntNbNz] = zero(mPtr->coef);
            cntNbNz++;
            matcnt[curCol]++;
            mPtr++;
        }
    }
    /// For dummy element ncol + 1
    matbeg[curCol] = cntNbNz;
    matcnt[curCol] = 0;

    double *dlb = new double[ncol];
    fill_n(dlb, ncol, 0);
    double *dub = new double[ncol];
    fill_n(dub, ncol, BapcodInfinity);

    for (ProbBoundContainer::const_iterator bPtr = bounds.begin();
         bPtr != bounds.end(); bPtr++) {
        if (bPtr->sense == 'U')
            dub[bPtr->ref] = zero(bPtr->bound);
        else if (bPtr->sense == 'L')
            dlb[bPtr->ref] = zero(bPtr->bound);
        else if (bPtr->sense == 'F') {
            dlb[bPtr->ref] = zero(bPtr->bound);
            dub[bPtr->ref] = dlb[bPtr->ref];
        }
    }

    char *vtype = new char[ncol];
    char *vtypeRelaxedModel = new char[ncol];
    fill_n(vtype, ncol, GRB_CONTINUOUS);
    fill_n(vtypeRelaxedModel, ncol, GRB_CONTINUOUS);
    for (set<ProbType>::const_iterator typePt = types.begin(); typePt != types.end(); typePt++) {
        if (typePt->type == 'I') vtype[typePt->ref] = GRB_INTEGER;
        if (typePt->type == 'B') vtype[typePt->ref] = GRB_BINARY;
        if (typePt->type == 'S') vtype[typePt->ref] = GRB_SEMICONT;
        if (typePt->type == 'N') vtype[typePt->ref] = GRB_SEMIINT;
    }

    std::string curName;
    char *colnamestore = nullptr;
    char **colnames = nullptr;
    char *rownamestore = nullptr;
    char **rownames = nullptr;

    if (param().MipSolverRecordNamesInFormulation) {
        colnamestore = new char[ncol * placeSize];
        fill_n(colnamestore, ncol * placeSize, endOfWord);
        colnames = new char *[ncol];
        fill_n(colnames, ncol, static_cast<char *>(nullptr));

        rownamestore = new char[nrow * placeSize];
        fill_n(rownamestore, nrow * placeSize, endOfWord);
        rownames = new char *[nrow];
        fill_n(rownames, nrow, static_cast<char *>(nullptr));

        for (int ic = 0; ic < ncol; ic++) {
            auto it = mapSeqnb2Cname.find(ic);
            if (it != mapSeqnb2Cname.end())
                curName = (it->second) + filling;
            else
                curName = filling;

            strncpy(&(colnamestore[ic * placeSize]), curName.c_str(), wordSize);
            colnamestore[(ic + 1) * placeSize - 1] = endOfWord;
            colnames[ic] = &(colnamestore[ic * placeSize]);
        }

        for (int ir = 0; ir < nrow; ir++) {
            auto it = mapSeqnb2Rname.find(ir);
            if (it != mapSeqnb2Rname.end())
                curName = (it->second) + filling;
            else
                curName = filling;

            strncpy(&(rownamestore[ir * placeSize]), curName.c_str(), wordSize);
            rownamestore[(ir + 1) * placeSize - 1] = endOfWord;
            rownames[ir] = &(rownamestore[ir * placeSize]);
        }

        if (GRBloadmodel(env, &model, name.c_str(), ncol, nrow, minmaxStatus, 0.0, obj, rsense,
                         rhs, matbeg, matcnt, matind, matval, dlb, dub, vtype, colnames, rownames)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            GRBfreemodel(model);
            GRBfreeenv(env);
            exit(0);
        }

        if (GRBloadmodel(env, &relaxedModel, name.c_str(), ncol, nrow, minmaxStatus, 0.0, obj, rsense,
                         rhs, matbeg, matcnt, matind, matval, dlb, dub, vtypeRelaxedModel, colnames, rownames)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            GRBfreemodel(model);
            GRBfreeenv(env);
            exit(0);
        }

    } else {
        if (GRBloadmodel(env, &model, name.c_str(), ncol, nrow, minmaxStatus, 0.0, obj, rsense,
                         rhs, matbeg, matcnt, matind, matval, dlb, dub, vtype, nullptr, nullptr)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            GRBfreemodel(model);
            GRBfreeenv(env);
            exit(0);
        }

        if (GRBloadmodel(env, &relaxedModel, name.c_str(), ncol, nrow, minmaxStatus, 0.0, obj, rsense,
                         rhs, matbeg, matcnt, matind, matval, dlb, dub, vtypeRelaxedModel, nullptr, nullptr)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            GRBfreemodel(model);
            GRBfreeenv(env);
            exit(0);
        }
    }

    // Set branching priorities
    if (!directs.empty()) {
        for (set<ProbIntC>::const_iterator dPtr = directs.begin(); dPtr != directs.end(); dPtr++) {
            if (dPtr->ref >= 0) {


                int direction = 0; // neutral
                if (dPtr->type == 'D')
                    direction = -1; // prefer down
                else if (dPtr->type == 'U')
                    direction = 1;  // prefer up

                // Set branching priority
                if (GRBsetintattrelement(model, GRB_INT_ATTR_BRANCHPRIORITY, dPtr->ref, direction)) {
                    printf("ERROR setting branch priority: %s\n", GRBgeterrormsg(env));
                    exit(0);
                }
            }
        }
    }

    // Handle SOS constraints
    if (!sets.empty()) {
        int numsos = 0;
        int numsosnz = 0;
        int *sostype = NULL;
        int *sosbeg = NULL;
        int *sosind = NULL;
        double *sosref = NULL;

        std::set<int> setNbs;
        for (set<ProbSetCoef>::const_iterator sPtr = sets.begin(); sPtr != sets.end(); sPtr++)
            setNbs.insert(sPtr->setRef);

        numsos = setNbs.size();
        sostype = new int[numsos];
        fill_n(sostype, numsos, 0);
        sosbeg = new int[numsos];
        fill_n(sosbeg, numsos, 0);
        sosind = new int[sets.size()];
        fill_n(sosind, sets.size(), -1);
        sosref = new double[sets.size()];
        fill_n(sosref, sets.size(), 0);

        set<ProbSetCoef>::const_iterator sPtr = sets.begin();
        while (sPtr != sets.end()) {
            int curSet = sPtr->setRef;
            if (sPtr->setType == '1')
                sostype[curSet] = GRB_SOS_TYPE1;
            else if (sPtr->setType == '2')
                sostype[curSet] = GRB_SOS_TYPE2;

            sosbeg[curSet] = numsosnz;
            do {
                sosind[numsosnz] = sPtr->colRef;
                sosref[numsosnz] = sPtr->coef;
                numsosnz++;
                sPtr++;
            } while ((sPtr != sets.end()) && (sPtr->setRef == curSet));
        }

        if (GRBaddsos(model, numsos, numsosnz, sostype, sosbeg, sosind, sosref)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }

        if (GRBupdatemodel(model)) {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }

        delete[] sostype;
        sostype = NULL;
        delete[] sosbeg;
        sosbeg = NULL;
        delete[] sosind;
        sosind = NULL;
        delete[] sosref;
        sosref = NULL;
    }

    // Clean up memory
    delete[] obj;
    obj = NULL;
    delete[] rhs;
    rhs = NULL;
    delete[] rsense;
    rsense = NULL;
    delete[] matbeg;
    matbeg = NULL;
    delete[] matcnt;
    matcnt = NULL;
    delete[] matind;
    matind = NULL;
    delete[] matval;
    matval = NULL;
    delete[] dlb;
    dlb = NULL;
    delete[] dub;
    dub = NULL;
    delete[] vtype;
    vtype = NULL;
    delete[] vtypeRelaxedModel;
    vtypeRelaxedModel = NULL;
    delete[] colnames;
    colnames = NULL;
    delete[] rownames;
    rownames = NULL;
    delete[] colnamestore;
    colnamestore = NULL;
    delete[] rownamestore;
    rownamestore = NULL;



}
void MipGRBInterface::setLazyConstraintsCallback(MasterConf* mastConfPtr)
{
}
void MipGRBInterface::removeLazyConstraintsCallback()
{
}
void MipGRBInterface::resetUpperCutOffValue()
{

    GRBsetdblparam(GRBgetenv(model), "Cuttoff", 1e+75);

}
void LpGRBInterface::setUpperCutOffValue(const Double& cutOff)
{

    GRBsetdblparam(GRBgetenv(model), "Cuttoff", cutOff);

}
void MipGRBInterface::setSolveFromScratch(const bool exactSolution)
{
}

void MipGRBInterface::resetSolveFromScratch()
{
}

void MipGRBInterface::addDirectives(const std::set<ProbIntC> &varBrDirection)
{
    for (set<ProbIntC>::const_iterator dPtr = varBrDirection.begin(); dPtr != varBrDirection.end();
         dPtr++)
    {
        if (printL(6)) std::cout << *dPtr;

        GRBsetintattrelement(model, "BranchPriority", dPtr->ref, (int)dPtr->val);

        throw MathProgSolverException(
                "GRB does not allow to assign branch direction for each variable", true);
    }
}

void MipGRBInterface::chgColType(const std::set<ProbType> &newTypes)
{
    int Lnels = 0;
    int *Lmindex = new int[newTypes.size()];
    fill_n(Lmindex, newTypes.size(), 0);
    char *Lqctype = new char[newTypes.size()];
    fill_n(Lqctype, newTypes.size(), ' ');
    char *LqctypeRelaxed = new char[newTypes.size()];
    fill_n(LqctypeRelaxed, newTypes.size(), GRB_CONTINUOUS);

    for (set<ProbType>::const_iterator bPtr = newTypes.begin(); bPtr != newTypes.end(); bPtr++)
    {
        /// Set data structure for changing column types
        Lmindex[Lnels] = bPtr->ref;

        char gurobiType = GRB_CONTINUOUS; // default
        if (bPtr->type == 'I')
            gurobiType = GRB_INTEGER;
        else if (bPtr->type == 'B')
            gurobiType = GRB_BINARY;
        else if (bPtr->type == 'C')
            gurobiType = GRB_CONTINUOUS;

        Lqctype[Lnels] = gurobiType;
        Lnels++;
    }

    // Change variable types
    for (int i = 0; i < Lnels; i++)
    {
        if (GRBsetcharattrelement(model, GRB_CHAR_ATTR_VTYPE, Lmindex[i], Lqctype[i]))
        {
            printf("ERROR changing variable type for variable %d: %s\n",
                   Lmindex[i], GRBgeterrormsg(env));
            // Clean up before exit
            delete[] Lmindex;
            delete[] Lqctype;
            exit(0);
        }
    }

    // Update model to apply changes
    if (GRBupdatemodel(model))
    {
        printf("ERROR updating model after changing variable types: %s\n", GRBgeterrormsg(env));
        // Clean up before exit
        delete[] Lmindex;
        delete[] Lqctype;
        exit(0);
    }

    /// Delete extra arrays
    delete[] Lmindex;
    Lmindex = NULL;
    delete[] Lqctype;
    Lqctype = NULL;
    delete[] LqctypeRelaxed;
    LqctypeRelaxed = NULL;


}

void MipGRBInterface::getObjVal(Double &objV)
{
    double objVal;
    if (GRBgetdblattr(_lastSolveIsLp ? relaxedModel : model, "ObjVal", &objVal))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    objV = zero(objVal, grbPrecision);


}

void MipGRBInterface::getDualBound(Double &val)
{

    double dualval = 0.0;
    if (statusMIP == GRB_OPTIMAL) //optimal
    {
        bapcodInit().require(1, "MIP optimal");
        if (GRBgetdblattr(model, "ObjVal", &dualval))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    }
    else
        GRBgetdblattr(model, "ObjBoundC", &dualval);

    val = zero(dualval, grbPrecision);

}

void MipGRBInterface::getPrimalBound(Double &val)
{
    double primalval = 0.0;
    if (GRBgetdblattr(model, "ObjVal", &primalval))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }
    val = zero(primalval, grbPrecision);

}

bool MipGRBInterface::getOptimStatus(BcSolutionStatus &lpStatus, BcSolutionStatus &mipStatus)
{
    int status;
    if(_lastSolveIsLp)
    {
        if (GRBgetintattr(relaxedModel, "Status", &status))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }
    }
    else
    {
        if (GRBgetintattr(model, "Status", &status))
        {
            printf("ERROR: %s\n", GRBgeterrormsg(env));
            exit(0);
        }

    }


    if (status == GRB_OPTIMAL)
    {
        mipStatus = BcSolutionStatus::Optimum;
        lpStatus = BcSolutionStatus::Optimum;
        if (printL(3))
            std::cout << "MipGRBInterface::getOptimStatus: global search complete and an integer "
                         "solution has been found"
                      << std::endl;
        return true;
    }

    if (printL(4)) MPSwrite();

    if (status == GRB_INFEASIBLE)
    {
        mipStatus = BcSolutionStatus::Infeasible;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "MipGRBInterface::getOptimStatus: MIP infeasible" << std::endl;

        return false;
    }

    if (status == GRB_INF_OR_UNBD)
    {
        mipStatus = BcSolutionStatus::Infeasible;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "MipGRBInterface::getOptimStatus: MIP infeasible" << std::endl;

        return false;
    }

    if (status == GRB_CUTOFF)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3)) std::cout << "MipGRBInterface::getOptimStatus: cut off" << std::endl;
        return false;
    }

    if (status == GRB_ITERATION_LIMIT)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3)) std::cout << "MipGRBInterface::getOptimStatus: iteration limit";
        return false;
    }

    if (status == GRB_NODE_LIMIT)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout <<
                      "MipGRBInterface::getOptimStatus: node limit";
        return false;
    }

    if (status == GRB_TIME_LIMIT)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3)) std::cout << "MipGRBInterface::getOptimStatus: time limit";
        return false;
    }

    if (status == GRB_SOLUTION_LIMIT)
    {
        mipStatus = BcSolutionStatus::PrimalFeasSolFound;
        lpStatus = BcSolutionStatus::Optimum;
        if (printL(3)) std::cout << "MipGRBInterface::getOptimStatus: solution limit";
        return false;
    }

    if (status == GRB_INTERRUPTED)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3)) std::cout << "MipGRBInterface::getOptimStatus: interrupted by the user";
        return false;
    }

    if (status == GRB_NUMERIC)
    {
        mipStatus = BcSolutionStatus::UnSolved;
        lpStatus = BcSolutionStatus::UnSolved;
        if (printL(3))
            std::cout << "MipGRBInterface::getOptimStatus: unrecoverable numerical difficulty";
        return false;
    }

    if (status == GRB_SUBOPTIMAL)
    {
        mipStatus = BcSolutionStatus::PrimalFeasSolFound;
        lpStatus = BcSolutionStatus::Optimum;
        if (printL(3))
            std::cout << "MipGRBInterface::getOptimStatus: suboptimal solution is available";
        return false;
    }

    return LpGRBInterface::getOptimStatus(lpStatus, mipStatus);
}

void MipGRBInterface::optimise(const int& minmaxStatus,
                               const double& BarrierConvergenceTolerance,
                               const double& rightHAndSideZeroTol,
                               const double& reducedCostTolerance,
                               const bool& preprocessorOn,
                               const bool& probingOn,
                               const bool& automaticCuttingPlanesOn,
                               const char& solverSelection)
{
    _lastSolveIsLp = false;
    bapcodInit().require(_formCurrentlyLoaded,
                         "Form not Currently Loaded/2",
                         ProgStatus::quit,
                         3);
    if (printL(8))
    {
        MPSwrite();
    }

    int status;
    if (GRBgetintattr(model, "Status", &status))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }

    if (preprocessorOn)
        bapcodInit().check(GRBsetintparam(GRBgetenv(model), "Presolve", 1),
                           "Failure to turn on presolve ");
    else
        bapcodInit().check(GRBsetintparam(GRBgetenv(model), "Presolve", 0),
                           "Failure to turn off presolve ");

    if (probingOn)
        bapcodInit().check(GRBsetintparam(GRBgetenv(model), "VarBranch",2),
                           "Failure to change probing ");
    else
        bapcodInit().check(GRBsetintparam(GRBgetenv(model), "VarBranch",0),
                           "Failure to change probing ");

    int currentStartAlgo = -1;

    GRBgetintparam(env, "Method", &currentStartAlgo);
    if (printL(5))
        cout << "MIP Start algo = " << currentStartAlgo << endl;

    bapcodInit().check(GRBsetintparam(GRBgetenv(model), "Threads",
                                      bapcodInit().param().MipSolverMultiThread()),
                       "Failure to set number of threads ");


    GRBsetdblattr(model, "SAObjLow", -1e+75);
    GRBsetdblattr(model, "SAObjUp", 1e+75);

    GRBupdatemodel(model);
    if (GRBoptimize(model))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


    if (GRBgetintattr(model, "Status", &status))
    {
        printf("ERROR: %s\n", GRBgeterrormsg(env));
        exit(0);
    }


    statusMIP = status;

}

void MipGRBInterface::optimiseLp(const int& minmaxStatus, const double& BarrierConvergenceTolerance, const double& rightHAndSideZeroTol, const double& reducedCostTolerance, const bool& preprocessorOn, const bool& probingOn, const bool& automaticCuttingPlanesOn, const char& solverSelection)
{

    LpGRBInterface::optimise(minmaxStatus, BarrierConvergenceTolerance, rightHAndSideZeroTol, reducedCostTolerance,
                             preprocessorOn, probingOn, automaticCuttingPlanesOn, solverSelection);
}

void MipGRBInterface::getSol(std::map<int, Double> &primSol, const bool &ifPrint)
{
    primSol.clear();
    LpGRBInterface::getSol(primSol, ifPrint);
}

void MipGRBInterface::reset()
{}

#endif

