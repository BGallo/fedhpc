/// This file exists in order to make continuous integration work, it should be deleted as soon as
/// possible