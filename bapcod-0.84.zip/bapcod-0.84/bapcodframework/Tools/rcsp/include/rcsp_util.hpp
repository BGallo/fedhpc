/**
 * Resource Constrained Shortest Path Solver
 * Designed to be used by Branch-Cut-and-Price algorithms
 *
 * @author Ruslan Sadykov <Ruslan.Sadykov@inria.fr>,
 * @author Isaac Balster <Isaac.Balster@inria.fr>
 *
 * Inria, France, All Rights Reserved. [LICENCE]
 */

#ifndef _RCSP_UTIL_H_
#define _RCSP_UTIL_H_

#define TOLERANCE +1e-6
#define EDGE_BIG_M +99

#include <vector>
#include <algorithm>
#include <iostream>
#include <cstdio>
#include <fstream>
#include <string>
#include <chrono>
#include <bitset>
#include "rcsp_parameters.hpp"

namespace bcp_rcsp
{
class MinCutDigraph
{
   private:
    int _sourceNode;
    int _sinkNode;
    int _activeNode;
    int _admissibleArcTail;
    int _admissibleArcHead;

    std::vector<int> _blankNodes;
    std::vector<double> _aux;

    std::vector<int> _dormantNodes;
    std::bitset<MAX_NUMBER_OF_ELEMENTARITY_SETS> _dormantBitset;

    std::vector<int> _awakeNodes;
    std::bitset<MAX_NUMBER_OF_ELEMENTARITY_SETS> _awakeBitset;

    std::vector<int> _activeNodes;
    std::bitset<MAX_NUMBER_OF_ELEMENTARITY_SETS> _activeBitset;

    std::vector<int> _distanceLabel;
    std::vector<double> _excess;
    std::vector<std::vector<int>> _adjacencyList;
    std::vector<std::vector<double>> _digraphMatrix;
    std::vector<std::vector<double>> _residualNetwork;
    std::vector<std::vector<double>> _flowMatrix;

    void initialize();
    void getAdmissibleArc();
    void relabel();

   public:
    /// Constructors.
    MinCutDigraph(const std::vector<std::vector<double>>& digraphMatrix);

    MinCutDigraph(const std::vector<std::vector<double>>& digraphMatrix, const int& sourceIndex,
                  const int& sinkIndex);

    MinCutDigraph(const std::vector<std::vector<double>>& digraphMatrix,
                  const std::vector<std::vector<int>>& digraphAdjacencyList);

    /// Destructor(s).
    ~MinCutDigraph() = default;

    /// Methods.
    void findMinCut(const int& sourceNode, const int& sinkNode);

    void printSubsets();

    /// Getters.
    inline std::vector<int> dormantNodes() const { return _dormantNodes; }
    inline std::vector<int> awakeNodes() const { return _awakeNodes; }
    inline double getMaxFlow() const { return _excess[_sinkNode]; }
    inline double getArcFlow(const int& tail, const int& head) const
    {
        return _flowMatrix[tail][head];
    }

    /// Setters.
    void setArcValue(const int& indexI, const int& indexJ, const double& arcValue);
    void setArc(const int& indexI, const int& indexJ, const double& arcValue);
};
} // namespace bcp_rcsp

#endif /* _RCSP_UTIL_h */
