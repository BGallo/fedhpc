#!/bin/bash
# Usage: standalone_test_vrpsolver.sh <mode> <logdir>
# mode: performance | easy
set -e

MODE=$1
LOGDIR=$2

if [ -z "$MODE" ] || [ -z "$LOGDIR" ]; then
  echo "Usage: $0 <mode> <logdir>"
  echo "  mode: performance | easy"
  exit 1
fi

# Save script directory for later use (before we change directories)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

source "$SCRIPT_DIR/ci_utils.sh"

# Convert LOGDIR to absolute path
LOGDIR="$(cd "$(dirname "$LOGDIR")" 2>/dev/null && pwd)/$(basename "$LOGDIR")" || LOGDIR="$(pwd)/$LOGDIR"
mkdir -p "$LOGDIR"

if [ "$MODE" = "performance" ]; then
  log_section "VRPSolver Performance Tests (Regression)"
  
  FULL_LOG="$LOGDIR/vrpsolver_performance_full.log"
  echo "==== VRPSolver Performance Tests ====" > "$FULL_LOG"
  date >> "$FULL_LOG"
  echo "" >> "$FULL_LOG"
  
  # Setup coverage if enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    GCOV_DATA_DIR="$LOGDIR/gcov_data"
    mkdir -p "$GCOV_DATA_DIR"
    source "$SCRIPT_DIR/setup_coverage_env.sh" "$GCOV_DATA_DIR"
  fi
  
  # Clone VRPSolverTests
  echo "==== CLONE OUTPUT ====" >> "$FULL_LOG"
  log_info "Cloning VRPSolverTests..."
  if ! git clone https://ci-bapcodframework-readonly:${VRPSolverTestsToken}@gitlab.inria.fr/edge/VRPSolverTests.git $LOGDIR/VRPSolverTests 2>&1 | tee -a "$FULL_LOG"; then
    log_error "Clone failed"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  
  # Build test applications
  cd $LOGDIR/VRPSolverTests
  echo "" >> "$FULL_LOG"
  echo "==== CMAKE OUTPUT ====" >> "$FULL_LOG"
  log_info "Building VRPSolver test applications..."
  mkdir build && cd build
  
  # Add coverage flag to CMake if COVERAGE is enabled
  CMAKE_ARGS="-DCMAKE_BUILD_TYPE=Release"
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    CMAKE_ARGS="$CMAKE_ARGS -DCOVERAGE=ON"
  fi
  
  if ! cmake $CMAKE_ARGS .. 2>&1 | tee -a "$FULL_LOG"; then
    log_error "CMake failed"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  
  echo "" >> "$FULL_LOG"
  echo "==== BUILD OUTPUT ====" >> "$FULL_LOG"
  if ! make -j$(getconf _NPROCESSORS_ONLN) CapacitatedVehicleRoutingTest VehicleRoutingWithTimeWindowsTest HeterogeneousFleetVehicleRoutingTest SplitDeliveryVehicleRoutingTest 2>&1 | tee -a "$FULL_LOG"; then
    log_error "Build failed"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  log_success "Build succeeded for VRPSolver test applications"
  
  # Run regression tests
  cd ..
  echo "" >> "$FULL_LOG"
  echo "==== TEST OUTPUT ====" >> "$FULL_LOG"
  log_info "Running regression tests..."
  if python3 regressionTest.py --meta 1 --quick 2>&1 | tee -a "$FULL_LOG"; then
    log_success "VRPSolver regression tests passed"
    echo -e "\n${GREEN}✓ PASSED${NC}" | tee -a "$FULL_LOG"
  else
    log_error "VRPSolver regression tests failed"
    echo -e "\n${RED}✗ FAILED${NC}" | tee -a "$FULL_LOG"
    exit 1
  fi
  
# bash
  shopt -s nullglob
  rlogs_dirs=(rlogs_*)
  if [ ${#rlogs_dirs[@]} -gt 0 ]; then
    mkdir -p "$LOGDIR/test_logs"
    copied=0
    skipped=0
    for d in "${rlogs_dirs[@]}"; do
      [ -d "$d" ] || continue
      while IFS= read -r -d '' f; do
        base=$(basename "$f")
        dest="$LOGDIR/test_logs/$base"
        if [ -e "$dest" ]; then
          skipped=$((skipped+1))
        else
          if cp -a -- "$f" "$dest"; then
            copied=$((copied+1))
          else
            log_warning "Failed to copy $f"
          fi
        fi
      done < <(find "$d" -type f -print0)
    done
    log_info "Copied $copied files into $LOGDIR/test_logs (skipped $skipped existing files)"

    # Rename *.out -> *.log without overwriting existing .log files
    renamed=0
    rename_skipped=0
    while IFS= read -r -d '' outf; do
      logf="${outf%\.out}.log"
      if [ -e "$logf" ]; then
        log_warning "Skipping rename $outf -> $logf (destination exists)"
        rename_skipped=$((rename_skipped+1))
      else
        if mv -- "$outf" "$logf"; then
          renamed=$((renamed+1))
        else
          log_warning "Failed to rename $outf"
        fi
      fi
    done < <(find "$LOGDIR/test_logs" -type f -name '*.out' -print0)

    log_info "Renamed $renamed \*.out files to \*.log (skipped $rename_skipped due to existing .log)"
  fi
  shopt -u nullglob



  
  # Collect coverage data if enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    log_info "Collecting coverage data for VRPSolver performance tests"
    bash "$SCRIPT_DIR/collect_coverage.sh" "$LOGDIR" "$GCOV_DATA_DIR"
  fi
  
  log_success "VRPSolver performance tests completed"

elif [ "$MODE" = "easy" ]; then
  log_section "VRPSolver Easy Tests (VRPSolverPython Unit Tests)"
  
  FULL_LOG="$LOGDIR/vrpsolver_easy_full.log"
  echo "==== VRPSolver Easy Tests ====" > "$FULL_LOG"
  date >> "$FULL_LOG"
  echo "" >> "$FULL_LOG"
  
  # Setup coverage if enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    GCOV_DATA_DIR="$LOGDIR/gcov_data"
    mkdir -p "$GCOV_DATA_DIR"
    source "$SCRIPT_DIR/setup_coverage_env.sh" "$GCOV_DATA_DIR"
  fi
  
  # Copy unit tests
  echo "==== SETUP OUTPUT ====" >> "$FULL_LOG"
  log_info "Copying VRPSolverPython unit tests..."
  if ! cp -r Tests/UnitTestsVRPSolverPython $LOGDIR/ 2>&1 | tee -a "$FULL_LOG"; then
    log_error "Failed to copy unit tests"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  
  # Build unit tests
  cd $LOGDIR/UnitTestsVRPSolverPython
  echo "" >> "$FULL_LOG"
  echo "==== CMAKE OUTPUT ====" >> "$FULL_LOG"
  log_info "Building VRPSolverPython unit tests..."
  mkdir build && cd build
  
  # Add coverage flag to CMake if COVERAGE is enabled
  CMAKE_ARGS="-DCMAKE_BUILD_TYPE=Release -DUSE_RCSP_METASOLVER=ON"
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    CMAKE_ARGS="$CMAKE_ARGS -DCOVERAGE=ON"
  fi
  
  if ! cmake $CMAKE_ARGS .. 2>&1 | tee -a "$FULL_LOG"; then
    log_error "CMake failed"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  
  echo "" >> "$FULL_LOG"
  echo "==== BUILD OUTPUT ====" >> "$FULL_LOG"
  if ! make -j$(getconf _NPROCESSORS_ONLN) 2>&1 | tee -a "$FULL_LOG"; then
    log_error "Build failed"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  log_success "Build succeeded for VRPSolverPython unit tests"
  
  # Run unit tests
  cd bin
  chmod +x UnitTestsVRPSolverPython
  echo "" >> "$FULL_LOG"
  echo "==== TEST OUTPUT ====" >> "$FULL_LOG"
  log_info "Running unit tests..."
  if ./UnitTestsVRPSolverPython >> "$FULL_LOG" 2>&1; then
    log_success "VRPSolver Python unit tests passed"
    echo -e "\n${GREEN}✓ PASSED${NC}" | tee -a "$FULL_LOG"
    
    # Display test summary (last 2 lines)
    log_info "Test summary (last 2 lines):"
    tail -n 5 "$FULL_LOG"
  else
    log_error "VRPSolver Python unit tests failed"
    echo -e "\n${RED}✗ FAILED${NC}" | tee -a "$FULL_LOG"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    exit 1
  fi
  
  # Collect coverage data if enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    log_info "Collecting coverage data for VRPSolver easy tests"
    bash "$SCRIPT_DIR/collect_coverage.sh" "$LOGDIR" "$GCOV_DATA_DIR"
  fi
  
  log_success "VRPSolver easy tests completed"

else
  echo "ERROR: Invalid mode '$MODE'. Must be 'performance' or 'easy'"
  exit 1
fi
