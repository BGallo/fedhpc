#!/bin/bash
# Script to install BaPCod library and headers for standalone application development
# 
# Usage: 
#   install_bapcod.sh <BAPCOD_SOURCE_DIR> <BUILD_DIR> <INSTALL_DIR>
#
# Parameters:
#   BAPCOD_SOURCE_DIR - Path to BaPCod source directory (REQUIRED)
#   BUILD_DIR         - Path to build directory with compiled libraries (REQUIRED)
#   INSTALL_DIR       - Where to install BaPCod (REQUIRED)
#
# Examples:
#   install_bapcod.sh /home/user/Code/bapcodMaster build /tmp/bapcod_install
#   install_bapcod.sh ~/bapcodMaster /home/user/Code/bapcodMaster/build2 ~/my_bapcod

set -e

# Check arguments
if [ $# -ne 3 ]; then
    echo "❌ ERROR: Missing required arguments"
    echo ""
    echo "Usage: $0 <BAPCOD_SOURCE_DIR> <BUILD_DIR> <INSTALL_DIR>"
    echo ""
    echo "  BAPCOD_SOURCE_DIR - Path to BaPCod source directory"
    echo "  BUILD_DIR         - Path to build directory with compiled libraries"
    echo "  INSTALL_DIR       - Where to install BaPCod"
    echo ""
    echo "Examples:"
    echo "  $0 /home/user/bapcodMaster /home/user/bapcodMaster/build /tmp/bapcod"
    echo "  $0 . build /tmp/bapcod  # If running from BaPCod source directory"
    echo ""
    exit 1
fi

BAPCOD_SOURCE_DIR="$1"
BUILD_DIR="$2"
INSTALL_DIR="$3"
BAPCOD_DIR="${INSTALL_DIR}/BaPCod"

echo "========================================"
echo "BaPCod Installation Script"
echo "========================================"
echo ""

# Convert all paths to absolute
BAPCOD_SOURCE_DIR="$(cd "$BAPCOD_SOURCE_DIR" && pwd)"
if [[ "$BUILD_DIR" != /* ]]; then
    BUILD_DIR="${BAPCOD_SOURCE_DIR}/${BUILD_DIR}"
fi
INSTALL_DIR="$(mkdir -p "$INSTALL_DIR" && cd "$INSTALL_DIR" && pwd)"
BAPCOD_DIR="${INSTALL_DIR}/BaPCod"

echo "BaPCod source location: ${BAPCOD_SOURCE_DIR}"
echo "Build directory: ${BUILD_DIR}"
echo "Installation target: ${INSTALL_DIR}"
echo ""

# Verify BaPCod source directory exists
if [ ! -d "${BAPCOD_SOURCE_DIR}/Bapcod" ]; then
    echo "❌ ERROR: Cannot find Bapcod directory at ${BAPCOD_SOURCE_DIR}/Bapcod"
    echo "   Please provide the correct path to BaPCod source directory"
    exit 1
fi

# Verify build directory exists
if [ ! -d "${BUILD_DIR}" ]; then
    echo "❌ ERROR: Build directory does not exist: ${BUILD_DIR}"
    exit 1
fi

# Verify compiled library exists
if [ ! -f "${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_release.a" ]; then
    echo "❌ ERROR: Cannot find compiled library at:"
    echo "   ${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_release.a"
    echo ""
    echo "Please build BaPCod first:"
    echo "  cd ${BAPCOD_SOURCE_DIR}"
    echo "  mkdir -p build && cd build"
    echo "  cmake -DCMAKE_BUILD_TYPE=Release .."
    echo "  make"
    echo ""
    exit 1
fi

echo "✓ Found compiled library: ${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_release.a"
echo ""

# Check if we have sudo if installing to /opt
if [[ "$INSTALL_DIR" == /opt/* ]]; then
    if ! sudo -n true 2>/dev/null; then
        echo "Note: Installing to /opt requires sudo privileges"
    fi
    SUDO="sudo"
else
    SUDO=""
fi

# Create directory structure
echo "Creating directory structure..."
$SUDO mkdir -p "${BAPCOD_DIR}"/{include,include_dev,include_solverInterfaces,lib,tools,CMake}

# Copy headers
echo "Copying header files..."
$SUDO cp -r "${BAPCOD_SOURCE_DIR}/Bapcod/include"/* "${BAPCOD_DIR}/include/"
$SUDO cp -r "${BAPCOD_SOURCE_DIR}/Bapcod/include_dev"/* "${BAPCOD_DIR}/include_dev/"
$SUDO cp -r "${BAPCOD_SOURCE_DIR}/Bapcod/include_solverInterfaces"/* "${BAPCOD_DIR}/include_solverInterfaces/"

# Copy tools
echo "Copying tools..."
$SUDO cp -r "${BAPCOD_SOURCE_DIR}/Bapcod/tools"/* "${BAPCOD_DIR}/tools/"

# Copy CMake modules
echo "Copying CMake modules..."
$SUDO cp -r "${BAPCOD_SOURCE_DIR}/Bapcod/CMake"/* "${BAPCOD_DIR}/CMake/"

# Copy the compiled library
if [ -f "${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_release.a" ]; then
    echo "Copying release library..."
    $SUDO cp "${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_release.a" "${BAPCOD_DIR}/lib/"
fi

if [ -f "${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_debug.a" ]; then
    echo "Copying debug library..."
    $SUDO cp "${BUILD_DIR}/Bapcod/lib/Linux-x64/libbapcod_debug.a" "${BAPCOD_DIR}/lib/"
fi

# Copy coverage data files (.gcno) if they exist
GCNO_COUNT=$(find "${BUILD_DIR}" -name "*.gcno" 2>/dev/null | wc -l)
if [ "$GCNO_COUNT" -gt 0 ]; then
    echo ""
    echo "Copying coverage data files (.gcno)..."
    echo "  ✓ Found $GCNO_COUNT .gcno files"
    
    # Extract build directory name (e.g., build_rel or build_rel_rcsp)
    BUILD_DIR_NAME=$(basename "${BUILD_DIR}")
    
    $SUDO mkdir -p "${BAPCOD_DIR}/coverage/${BUILD_DIR_NAME}"
    
    # Copy .gcno files preserving directory structure under build directory name
    cd "${BUILD_DIR}"
    find . -name "*.gcno" -type f | while IFS= read -r gcno_file; do
        # Clean the path to remove './' prefix and keep meaningful structure
        clean_path=$(echo "$gcno_file" | sed 's|^\./||')
        dest_dir="${BAPCOD_DIR}/coverage/${BUILD_DIR_NAME}/$(dirname "$clean_path")"
        $SUDO mkdir -p "$dest_dir"
        $SUDO cp "$gcno_file" "$dest_dir/"
    done
    cd - > /dev/null
    echo "  → Coverage data files copied to ${BAPCOD_DIR}/coverage/${BUILD_DIR_NAME}/"
fi

# Handle RCSP installation based on what's available
if [ -d "${BAPCOD_SOURCE_DIR}/Tools/rcsp" ] || [ -d "${BUILD_DIR}/Tools/rcsp" ]; then
    echo ""
    echo "Checking for RCSP installation..."
    
    # Case 1: RCSP built in BaPCod source directory (Tools/rcsp/build/lib/librcsp.a)
    if [ -f "${BAPCOD_SOURCE_DIR}/Tools/rcsp/build/lib/librcsp.a" ]; then
        echo "  ✓ Found RCSP library in source Tools/rcsp/build/lib/"
        echo "  → Copying RCSP library..."
        $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/lib"
        $SUDO cp "${BAPCOD_SOURCE_DIR}/Tools/rcsp/build/lib/librcsp.a" "${INSTALL_DIR}/Tools/rcsp/lib/"
        
        # Copy only rcsp_* headers from include_dev
        if [ -d "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include_dev" ]; then
            echo "  → Copying RCSP headers (rcsp_* files from include_dev)..."
            $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/include"
            
            # Copy only files that start with rcsp_
            for file in "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include_dev"/rcsp_*; do
                if [ -f "$file" ]; then
                    $SUDO cp "$file" "${INSTALL_DIR}/Tools/rcsp/include/"
                fi
            done
        fi
        
        # Copy FindBcpRcsp.cmake
        if [ -f "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" ]; then
            echo "  → Copying FindBcpRcsp.cmake..."
            $SUDO cp "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" "${BAPCOD_DIR}/CMake/Packages/"
        fi
    
    # Case 2: RCSP built in BaPCod build directory (BUILD_DIR/Tools/rcsp/lib/librcsp.a)
    elif [ -f "${BUILD_DIR}/Tools/rcsp/lib/librcsp.a" ]; then
        echo "  ✓ Found RCSP library in build directory Tools/rcsp/lib/"
        echo "  → Copying RCSP library..."
        $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/lib"
        $SUDO cp "${BUILD_DIR}/Tools/rcsp/lib/librcsp.a" "${INSTALL_DIR}/Tools/rcsp/lib/"
        
        # Copy only rcsp_* headers from include_dev in source directory
        if [ -d "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include_dev" ]; then
            echo "  → Copying RCSP headers (rcsp_* files from include_dev)..."
            $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/include"
            
            # Copy only files that start with rcsp_
            for file in "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include_dev"/rcsp_*; do
                if [ -f "$file" ]; then
                    $SUDO cp "$file" "${INSTALL_DIR}/Tools/rcsp/include/"
                fi
            done
        fi
        
        # Copy FindBcpRcsp.cmake
        if [ -f "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" ]; then
            echo "  → Copying FindBcpRcsp.cmake..."
            $SUDO cp "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" "${BAPCOD_DIR}/CMake/Packages/"
        fi
        
    # Case 3: RCSP installed separately with include/ and lib/ folders in source directory
    elif [ -d "${BAPCOD_SOURCE_DIR}/Tools/rcsp/lib" ] && [ -f "${BAPCOD_SOURCE_DIR}/Tools/rcsp/lib/librcsp.a" ] && [ -d "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include" ]; then
        echo "  ✓ Found RCSP installation in source Tools/rcsp/lib/ and Tools/rcsp/include/"
        echo "  → Copying RCSP library..."
        $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/lib"
        $SUDO cp "${BAPCOD_SOURCE_DIR}/Tools/rcsp/lib/librcsp.a" "${INSTALL_DIR}/Tools/rcsp/lib/"
        
        echo "  → Copying RCSP headers..."
        $SUDO mkdir -p "${INSTALL_DIR}/Tools/rcsp/include"
        $SUDO cp -r "${BAPCOD_SOURCE_DIR}/Tools/rcsp/include"/* "${INSTALL_DIR}/Tools/rcsp/include/"
        
        # Copy FindBcpRcsp.cmake
        if [ -f "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" ]; then
            echo "  → Copying FindBcpRcsp.cmake..."
            $SUDO cp "${BAPCOD_SOURCE_DIR}/Bapcod/CMake/Packages/FindBcpRcsp.cmake" "${BAPCOD_DIR}/CMake/Packages/"
        fi
        
    else
        echo "  ⚠ RCSP directory found but no valid library/headers - skipping RCSP installation"
    fi
fi

# Handle rapidjson installation if it exists
if [ -d "${BAPCOD_SOURCE_DIR}/Tools/rapidjson" ]; then
    echo ""
    echo "Checking for rapidjson installation..."
    echo "  ✓ Found rapidjson in Tools/rapidjson/"
    echo "  → Copying rapidjson..."
    $SUDO mkdir -p "${INSTALL_DIR}/Tools"
    $SUDO cp -r "${BAPCOD_SOURCE_DIR}/Tools/rapidjson" "${INSTALL_DIR}/Tools/"
fi

echo ""
echo "========================================"
echo "✅ BaPCod installed successfully!"
echo "========================================"
echo ""
echo "Installation location: ${INSTALL_DIR}"
echo ""
echo "To build applications in STANDALONE MODE:"
echo ""
echo "  1. Set the environment variable:"
echo "     export BAPCOD_ROOT=${INSTALL_DIR}"
echo ""
echo "  2. Build your application:"
echo "     cd /path/to/your/demo"
echo "     mkdir build && cd build"
echo "     cmake .."
echo "     make"
echo ""
echo "Note: Demos already support both source and standalone modes!"
echo ""
