#!/bin/bash
# Usage: standalone_test.sh <type> <logdir> <name1> [<name2> ...]
# Example: standalone_test.sh Demos logs VehicleRoutingWithTimeWindowsDemo SplitDeliveryVehicleRoutingDemo
# Example: standalone_test.sh Applications logs CapacitatedVehicleRouting (will clone if needed)
set -e

TYPE=$1
LOGDIR=$2
shift 2
NAMES="$@"

if [ -z "$TYPE" ] || [ -z "$LOGDIR" ] || [ -z "$NAMES" ]; then
  echo "Usage: $0 <type> <logdir> <name1> [<name2> ...]"
  exit 1
fi

# Save script directory for later use
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

source "$SCRIPT_DIR/ci_utils.sh"



extract_archives() {
  mkdir -p "$LOGDIR"
  find tests -name "*.log.tar.gz" -type f | while IFS= read -r archive; do
    test_name=$(basename "$(dirname "$archive")")
    dest="$LOGDIR/${NAME}_${test_name}.log"
    marker="$dest.done"

    # Skip if already extracted
    if [ -f "$marker" ] || [ -f "$dest" ]; then
      rm -f "$archive"
      continue
    fi

    # List plausible entries, excluding macOS metadata and resource forks
    mapfile -t entries < <(tar -tzf "$archive" 2>/dev/null | grep -Ev '^(__MACOSX/|.*/\._|^._)' || true)

    if [ ${#entries[@]} -eq 0 ]; then
      rm -f "$archive"
      continue
    fi

    # Prefer .log.out, then .log
    candidates=()
    for e in "${entries[@]}"; do
      case "$e" in
        *.log.out) candidates+=("$e") ;;
      esac
    done
    for e in "${entries[@]}"; do
      case "$e" in
        *.log) candidates+=("$e") ;;
      esac
    done

    extracted=0
    for out_file in "${candidates[@]}"; do
      tmpdest="${dest}.$$.$RANDOM"
      if tar -xOzf "$archive" "$out_file" > "$tmpdest" 2>/dev/null; then
        # check it's text (fallback: file -> grep)
        if grep -Iq . "$tmpdest" 2>/dev/null; then
          # try to normalise/strip invalid UTF-8 if iconv present
          if command -v iconv >/dev/null 2>&1; then
            if iconv -f utf-8 -t utf-8 -c "$tmpdest" > "${tmpdest}.u" 2>/dev/null; then
              mv "${tmpdest}.u" "$tmpdest"
            fi
          fi
          mv "$tmpdest" "$dest"
          : > "$marker"
          log_info "Extracted: $(basename "$dest")"
          extracted=1
          break
        else
          rm -f "$tmpdest"
          log_warning "Skipped binary/non-text entry $out_file in $archive"
        fi
      else
        rm -f "$tmpdest" 2>/dev/null
      fi
    done

    if [ $extracted -eq 0 ]; then
      log_warning "No usable log found in $archive — archive removed"
    fi

    rm -f "$archive"
  done
}


# Save the original directory
ORIGINAL_DIR=$(pwd)

# Create log directory structure with absolute path
LOGDIR="$(cd "$(dirname "$LOGDIR")" 2>/dev/null && pwd)/$(basename "$LOGDIR")" || LOGDIR="$(pwd)/$LOGDIR"
mkdir -p "$LOGDIR"

for NAME in $NAMES; do
  log_section "Processing $TYPE/$NAME"

  # Single log file for everything (use absolute path)
  FULL_LOG="$LOGDIR/${NAME}_full.log"

  # Start logging
  echo "==== Processing $TYPE/$NAME ====" > "$FULL_LOG"
  date >> "$FULL_LOG"
  echo "" >> "$FULL_LOG"

  # Clone application if needed (only for Applications type)
  if [ "$TYPE" = "Applications" ]; then
    if [ ! -d Applications ]; then
      log_error "Must be run from the project root (where Applications/ exists)"
      exit 1
    fi

    if [ ! -d "Applications/$NAME" ]; then
      echo "==== CLONE OUTPUT ====" >> "$FULL_LOG"
      log_info "Cloning $NAME..."
      token_var="${NAME}Token"
      token_value="${!token_var}"
      if [ -z "$token_value" ]; then
        log_error "Token variable $token_var is not set for $NAME. Aborting."
        exit 1
      fi

      cd Applications
      errfile=$(init_error_file "err-file-sub")
      clone_application "$NAME" "$token_var" "$errfile"
      wait_and_check_errors "$errfile" || {
        log_error "Error detected cloning $NAME"
        cat *.log >> "$FULL_LOG" 2>/dev/null
        cat *.log 2>/dev/null
        cd "$ORIGINAL_DIR"
        exit 1
      }
      cd "$ORIGINAL_DIR"
      log_success "$NAME cloned successfully"
      echo "" >> "$FULL_LOG"
    else
      log_info "$NAME already exists, skipping clone."
    fi
  fi

  # Build and test (work in temporary directory)
  log_info "Building $TYPE/$NAME"

  # Create a temporary build directory with proper structure
  # Tests expect to run from demo root with ../../Scripts/ pointing to project Scripts
  BUILD_WORK_DIR=$(mktemp -d)
  mkdir -p "$BUILD_WORK_DIR/$TYPE"
  cp -r "$TYPE/$NAME" "$BUILD_WORK_DIR/$TYPE/"
  cp -r Scripts "$BUILD_WORK_DIR/"

  # Setup coverage data collection directory if coverage is enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    GCOV_DATA_DIR="$BUILD_WORK_DIR/gcov_data"
    mkdir -p "$GCOV_DATA_DIR"
    source "$SCRIPT_DIR/setup_coverage_env.sh" "$GCOV_DATA_DIR"
  fi

  cd "$BUILD_WORK_DIR/$TYPE/$NAME"

  # Continue using the same log file (don't recreate it)
  echo "" >> "$FULL_LOG"
  echo "==== CMAKE OUTPUT ====" >> "$FULL_LOG"
  mkdir -p build
  cd build
  
  # Add coverage flag to CMake if COVERAGE is enabled
  CMAKE_ARGS=""
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    CMAKE_ARGS="-DCOVERAGE=ON"
  fi
  
  if ! cmake $CMAKE_ARGS .. >> "$FULL_LOG" 2>&1; then
    log_error "CMake failed for $NAME"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    cd "$ORIGINAL_DIR"
    rm -rf "$BUILD_WORK_DIR"
    exit 1
  fi

  echo "" >> "$FULL_LOG"
  echo "==== BUILD OUTPUT ====" >> "$FULL_LOG"
  if ! make -j$(getconf _NPROCESSORS_ONLN) >> "$FULL_LOG" 2>&1; then
    log_error "Build failed for $NAME"
    log_warning "Last 25 lines from $FULL_LOG:"
    tail -25 "$FULL_LOG"
    cd "$ORIGINAL_DIR"
    rm -rf "$BUILD_WORK_DIR"
    exit 1
  fi
  log_success "Build succeeded for $NAME"
  cd ..

  # Copy built executables to expected location (tests expect ./bin/)
  if [ -d build/bin ]; then
    mkdir -p bin
    cp -r build/bin/* bin/
  fi

  # Test
  if [ -d tests ]; then
    log_info "Running tests for $NAME"
    echo "" >> "$FULL_LOG"
    echo "==== TEST OUTPUT ====" >> "$FULL_LOG"

    if sh tests/runTests.sh 1 >> "$FULL_LOG" 2>&1; then
      log_success "Tests passed for $NAME"
      echo -e "\n${GREEN}✓ PASSED${NC}" | tee -a "$FULL_LOG"

      # Extraction centralisée
      extract_archives
    else
      log_error "Tests failed for $NAME"
      echo -e "\n${RED}✗ FAILED${NC}" | tee -a "$FULL_LOG"

      # Extraction centralisée même en cas d'échec
      extract_archives

      # Show error details in terminal
      log_warning "Last 25 lines from $FULL_LOG:"
      tail -25 "$FULL_LOG"

      # Cleanup and exit
      cd "$ORIGINAL_DIR"
      rm -rf "$BUILD_WORK_DIR"
      exit 1
    fi
  else
    log_info "No tests directory found for $NAME, skipping tests"
    echo -e "\n${YELLOW}⊘ NO_TESTS${NC}" | tee -a "$FULL_LOG"
  fi

  # Collect coverage data if enabled
  if [ -n "$COVERAGE" ] && [ "$COVERAGE" = "ON" ]; then
    log_info "Collecting coverage data for $NAME"
    cd "$BUILD_WORK_DIR"
    bash "$ORIGINAL_DIR/Scripts/shell/collect_coverage.sh" "$LOGDIR" "$GCOV_DATA_DIR"
    cd "$ORIGINAL_DIR"
  fi

  # Cleanup
  cd "$ORIGINAL_DIR"
  rm -rf "$BUILD_WORK_DIR"
done
