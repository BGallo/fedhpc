#!/bin/bash
# Script to automatically set up GCOV environment variables
# This calculates the correct GCOV_PREFIX_STRIP value based on the current working directory
# Usage: source setup_coverage_env.sh <gcov_data_dir>

if [ $# -lt 1 ]; then
  echo "Usage: source $0 <gcov_data_dir>"
  return 1 2>/dev/null || exit 1
fi

GCOV_DATA_DIR="$1"

# Get the absolute path of the current working directory
CURRENT_DIR="$(pwd)"

# Calculate GCOV_PREFIX_STRIP by counting directory levels until we reach a recognizable pattern
# We want to strip everything before the project-specific part
# For example: /beegfs/gitlab-edge/builds/XYZ/0/realopt/bapcodframework
# We want to keep: bapcodframework (or potentially realopt/bapcodframework)

# Count the number of directory components in the current path
# We'll look for 'bapcodframework' or similar project identifiers
STRIP_COUNT=0

# Split path into components
IFS='/' read -ra PATH_PARTS <<< "$CURRENT_DIR"

# Find the index of 'bapcodframework' (or the main project directory)
PROJECT_INDEX=-1
for i in "${!PATH_PARTS[@]}"; do
  if [[ "${PATH_PARTS[$i]}" == "bapcodframework" ]]; then
    PROJECT_INDEX=$i
    break
  fi
done

if [ $PROJECT_INDEX -gt 0 ]; then
  # Strip everything INCLUDING the project directory (bapcodframework)
  # We want to keep only the relative path like Bapcod/src/file.cpp
  STRIP_COUNT=$((PROJECT_INDEX + 1))
  echo "[INFO] Detected project at level $PROJECT_INDEX in path: $CURRENT_DIR"
  echo "[INFO] Will strip $STRIP_COUNT directory levels (including project root)"
else
  # Fallback: if we can't find the project name, preserve full paths
  STRIP_COUNT=0
  echo "[WARNING] Could not detect project directory in path: $CURRENT_DIR"
  echo "[WARNING] Using GCOV_PREFIX_STRIP=0 (preserving full paths)"
fi

# Export GCOV environment variables
export GCOV_PREFIX="$GCOV_DATA_DIR"
export GCOV_PREFIX_STRIP=$STRIP_COUNT

echo "[INFO] Coverage environment configured:"
echo "[INFO]   GCOV_PREFIX=$GCOV_PREFIX"
echo "[INFO]   GCOV_PREFIX_STRIP=$GCOV_PREFIX_STRIP"
