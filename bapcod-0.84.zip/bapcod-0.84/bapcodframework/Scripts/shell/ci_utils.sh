#!/bin/bash

# ==============================================================================
# CI Utility Functions
# ==============================================================================
# This file contains shared functions used across CI scripts to reduce
# redundancy and improve maintainability.
# ==============================================================================

# Color codes for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m' # No Color

# ==============================================================================
# Logging Functions
# ==============================================================================

log_info() {
    echo -e "[INFO] $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS] $1${NC}"
}

log_error() {
    echo -e "${RED}[ERROR] $1${NC}" >&2
}

log_warning() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

log_section() {
    echo ""
    echo -e "${BLUE}=== $1 ===${NC}"
    date
}

# ==============================================================================
# System Information Functions
# ==============================================================================

get_cpu_count() {
    getconf _NPROCESSORS_ONLN
}

print_env_info() {
    log_section "Environment Information"
    echo "Date: $(date)"
    echo "Hostname: $(hostname)"
    echo "Working directory: $(pwd)"
    echo "CPU cores: $(get_cpu_count)"
    echo "PATH: $PATH"
    if [ -n "${CI_COMMIT_REF_NAME}" ]; then
        echo "Branch: ${CI_COMMIT_REF_NAME}"
    fi
}

# ==============================================================================
# Log Directory Management
# ==============================================================================

# Global variable for log directory
LOG_DIR=""

setup_log_directory() {
    local base_name=${1:-"ci-logs"}
    # Use absolute path to ensure logs work from any directory
    LOG_DIR="$(pwd)/${base_name}"
    mkdir -p "$LOG_DIR"
    log_info "Log directory created: $LOG_DIR"
    echo "$LOG_DIR"
}

get_log_path() {
    local log_name=$1
    if [ -n "$LOG_DIR" ]; then
        echo "$LOG_DIR/$log_name"
    else
        echo "$log_name"
    fi
}

# ==============================================================================
# Error Handling Functions
# ==============================================================================

init_error_file() {
    local errfile=${1:-"err-file-main"}
    rm -f "$errfile"
    echo "$errfile"
}

wait_and_check_errors() {
    local errfile=${1:-"err-file-main"}
    
    log_info "Waiting for background processes..."
    wait
    
    if [ -e "$errfile" ]; then
        log_error "Error detected during execution"
        return 1
    fi
    
    log_info "All background processes completed successfully"
    return 0
}

# ==============================================================================
# Dependency Setup Functions
# ==============================================================================

setup_dependency() {
    local dep_name=$1
    local dep_root_var=$2
    local dep_path=$3
    local install_script=$4
    local errfile=${5:-"err-file-main"}
    local log_file=$(get_log_path "${dep_name}_install.log")
    
    # Check if environment variable is set and directory exists
    if [ -n "${!dep_root_var}" ] && [ -e "${!dep_root_var}" ]; then
        log_info "Using existing $dep_name with ${dep_root_var}=${!dep_root_var}"
        mkdir -p "$dep_path"
        ln -sf "${!dep_root_var}" "$dep_path/build"
        return 0
    fi
    
    # Check if already installed locally
    if [ -e "$dep_path" ]; then
        log_info "$dep_name already exists at $dep_path"
        return 0
    fi
    
    # Need to compile
    log_info "Need to compile $dep_name (log: $log_file)"
    (bash "$install_script" > "$log_file" 2>&1 || (
        echo
        log_error "Failed to install $dep_name"
        cat "$log_file"
        touch "$errfile"
        exit 1
    )) &
}

setup_boost() {
    local errfile=${1:-"err-file-main"}
    setup_dependency "Boost" "BOOST_ROOT" "Tools/boost_1_76_0" \
        "Scripts/shell/install_bc_boost.sh" "$errfile"
}

setup_lemon() {
    local errfile=${1:-"err-file-main"}
    setup_dependency "Lemon" "LEMON_ROOT" "Tools/lemon-1.3.1" \
        "Scripts/shell/install_bc_lemon.sh" "$errfile"
}

# ==============================================================================
# RCSP Functions
# ==============================================================================

setup_rcsp() {
    log_section "Setting up RCSP"
    
    cd Tools
    
    # Get current branch from BaPCod
    BAPCOD_BRANCH=${CI_COMMIT_REF_NAME:-$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "master")}
    log_info "Current BaPCod branch: $BAPCOD_BRANCH"
    
    # Try to clone RCSP from git with matching branch
    RCSP_CLONED=false
    if [ "$BAPCOD_BRANCH" != "master" ]; then
        log_info "Attempting to clone RCSP branch: $BAPCOD_BRANCH"
        if git clone -b "$BAPCOD_BRANCH" git@gitlab.inria.fr:edge/rcsp.git rcsp 2>/dev/null; then
            log_info "Successfully cloned RCSP branch: $BAPCOD_BRANCH"
            RCSP_CLONED=true
        else
            log_info "Branch $BAPCOD_BRANCH not found in RCSP repository"
        fi
    fi
    
    # Fall back to binary package if branch doesn't exist or on master
    if [ "$RCSP_CLONED" = false ]; then
        log_info "Downloading RCSP binary package..."
        wget -q https://gitlab.inria.fr/api/v4/projects/27629/packages/generic/rcsp-bin/0.0.2/rcsp.tgz
        tar xzf rcsp.tgz
        ln -sf librcsp-*-* rcsp
        log_info "RCSP binary package installed"
    fi
    
    cd ..
}

# ==============================================================================
# Build Functions
# ==============================================================================

build_bapcod() {
    local build_dir=$1
    local build_type=${2:-Release}
    local coverage_flag=$3
    local cpu=$(get_cpu_count)
    
    mkdir -p "$build_dir"
    cd "$build_dir"
    
    log_section "Running CMake in $build_dir"
    cmake -DCMAKE_BUILD_TYPE="$build_type" $coverage_flag ..
    
    log_section "Building bapcod with $cpu cores"
    make -j$cpu bapcod
    
    cd ..
}

# ==============================================================================
# Repository Functions
# ==============================================================================

clone_repo() {
    local repo_url=$1
    local target_dir=$2
    local repo_name=$(basename "$target_dir")
    
    log_info "Cloning $repo_name to $target_dir..."
    if git clone "$repo_url" "$target_dir"; then
        log_info "Successfully cloned $repo_name"
        return 0
    else
        log_error "Failed to clone $repo_name"
        return 1
    fi
}

clone_application() {
    local app_name=$1
    local token_var=$2
    local errfile=${3:-"err-file-sub"}
    
    if [ ! -e "$app_name" ]; then
        log_info "Cloning $app_name..."
        (
            git clone "https://bapcod:${!token_var}@gitlab.inria.fr/edge/${app_name}.git" "$app_name" || (
                echo
                log_error "Failed to clone $app_name"
                touch "$errfile"
                exit 1
            )
        ) &
    fi
}

