#!/bin/bash
set -e

# Source utility functions
source "$(dirname "$0")/ci_utils.sh"

# Print environment information
print_env_info

# Parse arguments
USE_RCSP=true
COVERAGE_FLAG=""

for arg in "$@"; do
    if [[ "$arg" == "--without-rcsp" ]] || [[ "$arg" == "-no-rcsp" ]]; then
        USE_RCSP=false
    elif [[ "$arg" == "--with-rcsp" ]]; then
        USE_RCSP=true
    elif [[ "$arg" == "-DCOVERAGE=ON" ]] || [[ "$arg" == "--coverage" ]]; then
        COVERAGE_FLAG="-DCOVERAGE=ON"
        log_info "Coverage enabled: adding -DCOVERAGE=ON"
    fi
done

# Setup build directory
if [ "$USE_RCSP" = true ]; then
    BUILD_DIR="build_rel_rcsp"
    log_info "Building Bapcod WITH RCSP"
else
    BUILD_DIR="build_rel"
    log_info "Building Bapcod WITHOUT RCSP"
fi

# Get branch name
BRANCH=${CI_COMMIT_REF_NAME:-"main"}
log_info "Current branch: $BRANCH"

# Initialize error tracking
errfile=$(init_error_file "err-file-main")

# Setup dependencies in background
log_section "Setting up dependencies"
setup_boost "$errfile"
setup_lemon "$errfile"

# Wait for all background jobs
wait_and_check_errors "$errfile" || exit 1

# Setup RCSP if needed
if [ "$USE_RCSP" = true ]; then
    # Clone rapidjson
    log_section "Cloning rapidjson"
    if [ ! -d "Tools/rapidjson" ]; then
        clone_repo "https://github.com/Tencent/rapidjson.git" "Tools/rapidjson"
    else
        log_info "rapidjson already exists at Tools/rapidjson"
    fi
    
    setup_rcsp
fi

# Build Bapcod
log_section "Building Bapcod"
build_bapcod "$BUILD_DIR" "Release" "$COVERAGE_FLAG"

log_section "Bapcod Build Complete"
log_info "Build directory: $BUILD_DIR"
exit 0
