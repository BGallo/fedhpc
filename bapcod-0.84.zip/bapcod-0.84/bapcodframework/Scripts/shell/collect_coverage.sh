#!/bin/bash
# Script to collect coverage data from test runs
# This script collects .gcda files generated when tests execute code
# from the instrumented libbapcod library
#
# Usage: collect_coverage.sh <logdir> <gcov_prefix_dir>
set -e

source $(dirname "$0")/ci_utils.sh

LOGDIR=$1
GCOV_PREFIX_DIR=${2:-""}

if [ -z "$LOGDIR" ]; then
  echo "Usage: $0 <logdir> [<gcov_prefix_dir>]"
  echo ""
  echo "  logdir          : Directory to store collected coverage data"
  echo "  gcov_prefix_dir : Directory where GCOV_PREFIX pointed during test execution"
  echo "                    (default: search in current directory and subdirs)"
  exit 1
fi

# Convert to absolute path
LOGDIR="$(cd "$(dirname "$LOGDIR")" 2>/dev/null && pwd)/$(basename "$LOGDIR")" || LOGDIR="$(pwd)/$LOGDIR"
mkdir -p "$LOGDIR"

log_section "Collecting Coverage Data"

# Search for .gcda files
# They can be in GCOV_PREFIX_DIR or scattered in build directories
SEARCH_DIRS="."
if [ -n "$GCOV_PREFIX_DIR" ] && [ -d "$GCOV_PREFIX_DIR" ]; then
  SEARCH_DIRS="$GCOV_PREFIX_DIR"
  log_info "Searching in GCOV_PREFIX directory: $GCOV_PREFIX_DIR"
fi

GCDA_FILES=$(find $SEARCH_DIRS -name "*.gcda" -type f 2>/dev/null || true)

if [ -z "$GCDA_FILES" ]; then
  log_warning "No coverage data files (.gcda) found"
  log_info "This might mean:"
  log_info "  1. Tests didn't execute any instrumented code"
  log_info "  2. GCOV_PREFIX not set correctly"
  log_info "  3. Coverage not enabled during compilation"
  exit 0
fi

# Count files
GCDA_COUNT=$(echo "$GCDA_FILES" | grep -c . || echo 0)
log_info "Found $GCDA_COUNT coverage data files (.gcda)"

# Copy .gcda files to coverage directory, preserving structure
COVERAGE_DIR="$LOGDIR/coverage_data"
mkdir -p "$COVERAGE_DIR"

# Prepare file for logging ignored files
IGNORED_LOG="$COVERAGE_DIR/ignored_files.log"
> "$IGNORED_LOG"  # Clear/create log file

ignored_count=0
collected_count=0

while IFS= read -r gcda_file; do
  if [ -n "$gcda_file" ] && [ -f "$gcda_file" ]; then
    # With GCOV_PREFIX_STRIP properly set, the files are already in a relative structure
    # under GCOV_PREFIX. We need to preserve this structure when copying.
    
    # Get the path relative to GCOV_PREFIX_DIR (if specified)
    if [ -n "$GCOV_PREFIX_DIR" ] && [ -d "$GCOV_PREFIX_DIR" ]; then
      # Make both paths absolute for reliable comparison
      abs_gcda=$(cd "$(dirname "$gcda_file")" && pwd)/$(basename "$gcda_file")
      abs_prefix=$(cd "$GCOV_PREFIX_DIR" && pwd)
      
      # Extract relative path from GCOV_PREFIX_DIR
      if [[ "$abs_gcda" == "$abs_prefix"* ]]; then
        rel_path="${abs_gcda#$abs_prefix/}"
      else
        # File is not under GCOV_PREFIX_DIR, likely shouldn't happen
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Warning: File not under GCOV_PREFIX: $gcda_file" >> "$IGNORED_LOG"
        ignored_count=$((ignored_count + 1))
        continue
      fi
    else
      # No GCOV_PREFIX_DIR specified, try to extract meaningful path
      # Look for build_rel patterns as fallback
      if echo "$gcda_file" | grep -q "/build_rel_rcsp/"; then
        rel_path=$(echo "$gcda_file" | sed 's|.*/build_rel_rcsp/|build_rel_rcsp/|')
      elif echo "$gcda_file" | grep -q "/build_rel/" && ! echo "$gcda_file" | grep -q "/build_rel_rcsp/"; then
        rel_path=$(echo "$gcda_file" | sed 's|.*/build_rel/|build_rel/|')
      else
        # Use the full path relative to current directory
        rel_path=$(realpath --relative-to="$PWD" "$gcda_file" 2>/dev/null || echo "$gcda_file")
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Using relative path: $rel_path for $gcda_file" >> "$IGNORED_LOG"
      fi
    fi
    
    # Keep ONLY files under Bapcod/ (library coverage). Exclude all root-level
    # demo/application .gcda files and any gitlab-edge or improperly stripped paths.
    if [[ "$rel_path" == Bapcod/* ]]; then
      # Valid libbapcod file with matching .gcno available in the build artifact
      dest="$COVERAGE_DIR/$rel_path"
      dest_dir=$(dirname "$dest")
      mkdir -p "$dest_dir"
      cp "$gcda_file" "$dest"
      collected_count=$((collected_count + 1))
    else
      # Ignore everything else (demo .gcda, gitlab-edge, etc.)
      echo "$(date '+%Y-%m-%d %H:%M:%S') - Filtered out (not in Bapcod/): $rel_path" >> "$IGNORED_LOG"
      ignored_count=$((ignored_count + 1))
    fi
  fi
done <<< "$GCDA_FILES"

log_success "Coverage data collected: $collected_count files in $COVERAGE_DIR"
if [ "$ignored_count" -gt 0 ]; then
  log_warning "Files ignored (no build_rel path): $ignored_count (details in $IGNORED_LOG)"
fi

# Create a manifest file with metadata
MANIFEST="$COVERAGE_DIR/manifest.txt"
{
  echo "# Coverage data manifest"
  echo "# Generated at: $(date)"
  echo "# Hostname: $(hostname)"
  echo "# Working directory: $(pwd)"
  echo "# File count: $GCDA_COUNT"
  echo "# Search directory: $SEARCH_DIRS"
  echo ""
  echo "# List of .gcda files:"
  echo "$GCDA_FILES"
} > "$MANIFEST"

log_info "Manifest created: $MANIFEST"
log_info "Total files collected: $GCDA_COUNT"
