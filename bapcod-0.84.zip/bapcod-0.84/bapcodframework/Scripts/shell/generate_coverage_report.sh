#!/bin/bash
# Script to generate unified coverage report from multiple test jobs
# Usage: generate_coverage_report.sh <output_dir> <source_dir> <coverage_data_dir1> [<coverage_data_dir2> ...]
set -e

source $(dirname "$0")/ci_utils.sh

if [ $# -lt 3 ]; then
  echo "Usage: $0 <output_dir> <source_dir> <coverage_data_dir1> [<coverage_data_dir2> ...]"
  exit 1
fi

OUTPUT_DIR=$1
SOURCE_DIR=$2
shift 2
COVERAGE_DIRS="$@"


log_section "Generating Coverage Report"

# Convert paths to absolute
OUTPUT_DIR="$(mkdir -p "$OUTPUT_DIR" && cd "$OUTPUT_DIR" && pwd)"
SOURCE_DIR="$(cd "$SOURCE_DIR" && pwd)"

# Create debug log file
DEBUG_LOG="$OUTPUT_DIR/coverage_debug.log"
echo "=== Coverage Generation Debug Log ===" > "$DEBUG_LOG"
echo "Timestamp: $(date)" >> "$DEBUG_LOG"
echo "Working directory: $(pwd)" >> "$DEBUG_LOG"
echo "" >> "$DEBUG_LOG"

log_info "Output directory: $OUTPUT_DIR"
log_info "Source directory: $SOURCE_DIR"
log_info "Coverage data directories: $COVERAGE_DIRS"
log_info "Debug log: $DEBUG_LOG"

echo "Output directory: $OUTPUT_DIR" >> "$DEBUG_LOG"
echo "Source directory: $SOURCE_DIR" >> "$DEBUG_LOG"
echo "Coverage data directories: $COVERAGE_DIRS" >> "$DEBUG_LOG"
echo "" >> "$DEBUG_LOG"

# Check for gcovr (Python-based alternative to lcov)
if ! command -v gcovr &> /dev/null; then
  log_warning "gcovr is not installed. Installing it now..."
  
  # Try to use Python 3.10 if available
  if command -v python3.10 &> /dev/null; then
    PYTHON_CMD="python3.10"
  elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
  else
    log_error "Python 3 is not available. Cannot install gcovr."
    exit 1
  fi
  
  log_info "Creating virtual environment..."
  VENV_DIR="$OUTPUT_DIR/covenv"
  $PYTHON_CMD -m venv "$VENV_DIR"
  source "$VENV_DIR/bin/activate"
  
  log_info "Installing gcovr..."
  python3 -m pip install --upgrade pip --quiet
  python3 -m pip install gcovr --quiet
  
  log_success "gcovr installed successfully"
fi

# Set locale to avoid encoding issues with gcovr
export LC_ALL=C
export LANG=C

# Initialize counters
TOTAL_GCDA=0
TOTAL_GCNO=0

# Array to store JSON report paths from each coverage directory
JSON_REPORTS=()

log_info "Scanning coverage data directories..."

# Process each coverage data directory separately
# After CI flattening, each directory has structure: coverage_coverage-*/coverage_data/
COVERAGE_DIR_INDEX=0
for COVERAGE_DATA_DIR in $COVERAGE_DIRS; do
  echo "=== Processing directory: $COVERAGE_DATA_DIR ===" >> "$DEBUG_LOG"
  
  if [ ! -d "$COVERAGE_DATA_DIR" ]; then
    log_warning "Directory not found: $COVERAGE_DATA_DIR"
    echo "ERROR: Directory not found!" >> "$DEBUG_LOG"
    continue
  fi
  
  log_info "Processing: $COVERAGE_DATA_DIR"
  
  # Log directory structure
  echo "Directory structure:" >> "$DEBUG_LOG"
  ls -la "$COVERAGE_DATA_DIR" >> "$DEBUG_LOG" 2>&1
  echo "" >> "$DEBUG_LOG"
  
  # Check for coverage_data subdirectory (flattened structure after CI processing)
  if [ -d "$COVERAGE_DATA_DIR/coverage_data" ]; then
    GCDA_COUNT=$(find "$COVERAGE_DATA_DIR/coverage_data" -name "*.gcda" 2>/dev/null | wc -l)
    GCNO_COUNT=$(find "$COVERAGE_DATA_DIR/coverage_data" -name "*.gcno" 2>/dev/null | wc -l)
    
    if [ $GCDA_COUNT -eq 0 ]; then
      log_warning "  → No .gcda files found in $COVERAGE_DATA_DIR/coverage_data"
      echo "No .gcda files found" >> "$DEBUG_LOG"
      continue
    fi
    
    TOTAL_GCDA=$((TOTAL_GCDA + GCDA_COUNT))
    TOTAL_GCNO=$((TOTAL_GCNO + GCNO_COUNT))
    log_info "  → Found $GCNO_COUNT .gcno files, $GCDA_COUNT .gcda files"
    
    echo "Found $GCNO_COUNT .gcno files, $GCDA_COUNT .gcda files" >> "$DEBUG_LOG"
    
    # List sample files
    echo "Sample .gcda files (first 10):" >> "$DEBUG_LOG"
    find "$COVERAGE_DATA_DIR/coverage_data" -name "*.gcda" 2>/dev/null | head -10 >> "$DEBUG_LOG"
    echo "" >> "$DEBUG_LOG"
    echo "Sample .gcno files (first 10):" >> "$DEBUG_LOG"
    find "$COVERAGE_DATA_DIR/coverage_data" -name "*.gcno" 2>/dev/null | head -10 >> "$DEBUG_LOG"
    echo "" >> "$DEBUG_LOG"
    
    # Rename .gcda and .gcno files by removing .cpp extension
    echo "Renaming coverage files..." >> "$DEBUG_LOG"
    GCDA_FILES=$(find "$COVERAGE_DATA_DIR/coverage_data" -name "*.cpp.gcda" 2>/dev/null)
    for GCDA_FILE in $GCDA_FILES; do
      GCDA_DIR=$(dirname "$GCDA_FILE")
      GCDA_BASE=$(basename "$GCDA_FILE" .gcda)
      NEW_BASE="${GCDA_BASE%.cpp}"
      
      # Rename .gcda file
      if [ -f "$GCDA_DIR/$GCDA_BASE.gcda" ]; then
        mv "$GCDA_DIR/$GCDA_BASE.gcda" "$GCDA_DIR/$NEW_BASE.gcda" 2>> "$DEBUG_LOG"
        echo "Renamed: $GCDA_BASE.gcda -> $NEW_BASE.gcda" >> "$DEBUG_LOG"
      fi
      
      # Rename corresponding .gcno file
      if [ -f "$GCDA_DIR/$GCDA_BASE.gcno" ]; then
        mv "$GCDA_DIR/$GCDA_BASE.gcno" "$GCDA_DIR/$NEW_BASE.gcno" 2>> "$DEBUG_LOG"
        echo "Renamed: $GCDA_BASE.gcno -> $NEW_BASE.gcno" >> "$DEBUG_LOG"
      fi
      if [ -f "$GCDA_DIR/$GCDA_BASE.cpp.gcno" ]; then
        mv "$GCDA_DIR/$GCDA_BASE.cpp.gcno" "$GCDA_DIR/$NEW_BASE.gcno" 2>> "$DEBUG_LOG"
        echo "Renamed: $GCDA_BASE.cpp.gcno -> $NEW_BASE.gcno" >> "$DEBUG_LOG"
      fi
    done
    echo "Finished renaming coverage files" >> "$DEBUG_LOG"
    
    # Generate JSON report for this coverage directory
    COVERAGE_DIR_INDEX=$((COVERAGE_DIR_INDEX + 1))
    JSON_OUTPUT="$OUTPUT_DIR/coverage_${COVERAGE_DIR_INDEX}.json"
    
    log_info "  → Generating JSON report: $JSON_OUTPUT"
    echo "=== Generating JSON report for $COVERAGE_DATA_DIR ===" >> "$DEBUG_LOG"
    
    OBJ_DIR="$(cd "$COVERAGE_DATA_DIR/coverage_data" && pwd)"
    echo "Object directory: $OBJ_DIR" >> "$DEBUG_LOG"
    
    # Generate .gcov files
    GCOV_DIR="$OUTPUT_DIR/gcov_files_${COVERAGE_DIR_INDEX}"
    mkdir -p "$GCOV_DIR"
    
    SOURCE_FILES=$(find "$SOURCE_DIR/Bapcod/src" "$SOURCE_DIR/Bapcod/src_solverInterfaces" -name "*.cpp" 2>/dev/null)
    SOURCE_COUNT_PROCESSED=0
    
    for SOURCE_FILE in $SOURCE_FILES; do
      SOURCE_BASE=$(basename "$SOURCE_FILE" .cpp)
      GCDA_FILE=$(find "$OBJ_DIR" -name "${SOURCE_BASE}.gcda" 2>/dev/null | head -1)
      
      if [ -n "$GCDA_FILE" ]; then
        GCDA_DIR=$(dirname "$GCDA_FILE")
        (
          cd "$SOURCE_DIR"
          gcov -o "$GCDA_DIR" -l -p -b "$SOURCE_FILE" >> "$DEBUG_LOG" 2>&1 || true
          mv *.gcov "$GCOV_DIR/" 2>/dev/null || true
        )
        SOURCE_COUNT_PROCESSED=$((SOURCE_COUNT_PROCESSED + 1))
      fi
    done
    
    log_info "     Processed $SOURCE_COUNT_PROCESSED source files"
    echo "Processed $SOURCE_COUNT_PROCESSED source files" >> "$DEBUG_LOG"
    
    # Generate JSON report with gcovr
    cd "$SOURCE_DIR"
    gcovr "$GCOV_DIR" \
      --root . \
      --use-gcov-files \
      --filter "Bapcod/src/.*" \
      --filter "Bapcod/src_solverInterfaces/.*" \
      --exclude ".*/Tests/.*" \
      --exclude ".*/tests/.*" \
      --exclude ".*/Tools/.*" \
      --exclude ".*/tools/.*" \
      --exclude ".*/build/.*" \
      --exclude ".*/CMakeFiles/.*" \
      --exclude "/cm/shared/.*" \
      --exclude "/usr/.*" \
      --exclude ".*/\.cache/.*" \
      --json "$JSON_OUTPUT" \
      --verbose >> "$DEBUG_LOG" 2>&1
    
    if [ -f "$JSON_OUTPUT" ]; then
      JSON_REPORTS+=("$JSON_OUTPUT")
      log_success "  → JSON report generated successfully"
      echo "JSON file size: $(wc -c < "$JSON_OUTPUT") bytes" >> "$DEBUG_LOG"
    else
      log_error "  → Failed to generate JSON report"
      echo "ERROR: JSON report not generated" >> "$DEBUG_LOG"
    fi
    
  else
    log_warning "  → coverage_data subdirectory not found"
    echo "coverage_data subdirectory NOT found" >> "$DEBUG_LOG"
  fi
  
  echo "" >> "$DEBUG_LOG"
done

log_info "Total coverage data: $TOTAL_GCNO .gcno files, $TOTAL_GCDA .gcda files"
log_info "Generated ${#JSON_REPORTS[@]} JSON reports"

echo "=== Summary ===" >> "$DEBUG_LOG"
echo "Total .gcno files: $TOTAL_GCNO" >> "$DEBUG_LOG"
echo "Total .gcda files: $TOTAL_GCDA" >> "$DEBUG_LOG"
echo "JSON reports generated: ${#JSON_REPORTS[@]}" >> "$DEBUG_LOG"
for JSON_REPORT in "${JSON_REPORTS[@]}"; do
  echo "  - $JSON_REPORT" >> "$DEBUG_LOG"
done
echo "" >> "$DEBUG_LOG"

if [ $TOTAL_GCDA -eq 0 ]; then
  log_error "No coverage data (.gcda files) found!"
  echo "ERROR: No coverage data (.gcda files) found!" >> "$DEBUG_LOG"
  exit 1
fi

if [ ${#JSON_REPORTS[@]} -eq 0 ]; then
  log_error "No JSON reports were generated!"
  echo "ERROR: No JSON reports were generated!" >> "$DEBUG_LOG"
  exit 1
fi

export LC_ALL=C
export LANG=C

# Generate coverage report with gcovr
HTML_DIR="$OUTPUT_DIR/html"
mkdir -p "$HTML_DIR"

# Merge all JSON reports
log_info "Merging ${#JSON_REPORTS[@]} coverage reports..."
echo "=== Merging coverage reports ===" >> "$DEBUG_LOG"

# Build gcovr command with all JSON reports
GCOVR_CMD="gcovr"
for JSON_REPORT in "${JSON_REPORTS[@]}"; do
  GCOVR_CMD="$GCOVR_CMD --add-tracefile \"$JSON_REPORT\""
  echo "Adding tracefile: $JSON_REPORT" >> "$DEBUG_LOG"
done
GCOVR_CMD="$GCOVR_CMD --html-details \"$HTML_DIR/index.html\" --txt \"$OUTPUT_DIR/coverage_summary.txt\" --print-summary"

echo "Running: $GCOVR_CMD" >> "$DEBUG_LOG"
eval "$GCOVR_CMD" 2>&1 | tee "$OUTPUT_DIR/coverage_metrics.txt" >> "$DEBUG_LOG"

echo "" >> "$DEBUG_LOG"

log_success "Coverage report generated successfully!"
log_info "HTML report: $HTML_DIR/index.html"
log_info "Text summary: $OUTPUT_DIR/coverage_summary.txt"

echo "=== Final output files ===" >> "$DEBUG_LOG"
echo "HTML report: $HTML_DIR/index.html" >> "$DEBUG_LOG"
echo "Text summary: $OUTPUT_DIR/coverage_summary.txt" >> "$DEBUG_LOG"
echo "" >> "$DEBUG_LOG"

# Log the detailed coverage table to debug log
if [ -f "$OUTPUT_DIR/coverage_summary.txt" ]; then
  echo "=== Detailed Coverage Table ===" >> "$DEBUG_LOG"
  cat "$OUTPUT_DIR/coverage_summary.txt" >> "$DEBUG_LOG"
  echo "" >> "$DEBUG_LOG"
fi

# Display summary metrics (not the detailed table)
echo ""
log_section "Coverage Summary"

# Extract percentages from the --print-summary output (saved in coverage_metrics.txt)
# gcovr --print-summary format: "lines: XX.X% (nnn of mmm lines)"
LINES_PERCENT=$(grep -oP "lines:\s+\K[\d\.]+" "$OUTPUT_DIR/coverage_metrics.txt" 2>/dev/null || echo "0.0")
FUNCTIONS_PERCENT=$(grep -oP "functions:\s+\K[\d\.]+" "$OUTPUT_DIR/coverage_metrics.txt" 2>/dev/null || echo "0.0")
BRANCHES_PERCENT=$(grep -oP "branches:\s+\K[\d\.]+" "$OUTPUT_DIR/coverage_metrics.txt" 2>/dev/null || echo "0.0")

# If extraction failed, try to get from TOTAL line in coverage_summary.txt as fallback
if [ "$LINES_PERCENT" = "0.0" ]; then
  LINES_PERCENT=$(grep "^TOTAL" "$OUTPUT_DIR/coverage_summary.txt" | awk '{print $4}' | sed 's/%//' || echo "0.0")
fi

echo ""
log_info "Line coverage: ${LINES_PERCENT}%"
log_info "Function coverage: ${FUNCTIONS_PERCENT}%"
log_info "Branch coverage: ${BRANCHES_PERCENT}%"

# Create a badge-friendly output
echo "COVERAGE_LINES=$LINES_PERCENT" > "$OUTPUT_DIR/coverage_metrics.env"
echo "COVERAGE_FUNCTIONS=$FUNCTIONS_PERCENT" >> "$OUTPUT_DIR/coverage_metrics.env"
echo "COVERAGE_BRANCHES=$BRANCHES_PERCENT" >> "$OUTPUT_DIR/coverage_metrics.env"

echo "=== Final Metrics ===" >> "$DEBUG_LOG"
echo "Line coverage: ${LINES_PERCENT}%" >> "$DEBUG_LOG"
echo "Function coverage: ${FUNCTIONS_PERCENT}%" >> "$DEBUG_LOG"
echo "Branch coverage: ${BRANCHES_PERCENT}%" >> "$DEBUG_LOG"
echo "" >> "$DEBUG_LOG"
echo "Debug log completed at: $(date)" >> "$DEBUG_LOG"

log_info "Debug log saved to: $DEBUG_LOG"
log_info "Include this file in your artifacts for debugging"
